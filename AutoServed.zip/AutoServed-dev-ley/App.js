/**
 * Sample React Native App
 * https://github.com/facebook/react-native
 *
 * @format
 * @flow strict-local
 */
import React, { useEffect } from "react";
import { Provider } from "mobx-react";
import AppStore from "./src/Services/Store/AppStore";

import { create } from "mobx-persist";
import AsyncStorage from "@react-native-community/async-storage";
import { MainNav } from "./src/Navigators";

// const hydrate = create({ storage: AsyncStorage });
const store = (window.store = new AppStore());
// hydrate("store", store).then((val) => console.log("Hydrated BLEStore: ", val));

const App = () => {
  return (
    <Provider store={store}>
      <MainNav />
    </Provider>
  );
};

export default App;
