const year = [];
var min = 1980,
  max = new Date().getFullYear();

for (var i = max; i >= min; i--) {
  year.push({ label: i.toString(), value: i.toString() });
}

const model = [
  { label: "Vios", value: "Vios" },
  { label: "Yaris", value: "Yaris" },
  { label: "Camry", value: "Camry" },
  { label: "Fortuner", value: "Fortuner" }
];
const brand = [
  { label: "Toyota", value: "Toyota" },
  { label: "BMW", value: "BMW" },
  { label: "Nissan", value: "Nissan" },
  { label: "Honda", value: "Honda" }
];

const engine = [
  { label: "Diesel", value: "Diesel" },
  { label: "Gasoline", value: "Gasoline" },
  { label: "Hybrid", value: "Hybrid" }
];

const transmission = [
  { label: "Automatic", value: "Automatic" },
  { label: "Manual", value: "Manual" }
  // { label: "Hybrid", value: "Hybrid" }
];

export default {
  year,
  model,
  brand,
  engine,
  transmission
};
