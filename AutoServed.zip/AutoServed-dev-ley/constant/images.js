const card_signin_one = require("../assets/images/card_signin_one.png");
const ads = require("../assets/images/ads.png");
const card_signin_two = require("../assets/images/card_signin_two.png");
const card_signin_three = require("../assets/images/card_signin_three.png");
const card_signin_four = require("../assets/images/card_signin_four.png");
const card_signin_five = require("../assets/images/card_signin_five.png");
const card_home = require("../assets/images/card_home.png");
const card_shop = require("../assets/images/card_shop.png");
const visamastercard = require("../assets/images/visamastercard.png");
export default {
  card_signin_one,
  ads,
  card_signin_two,
  card_signin_three,
  card_signin_four,
  card_signin_five,
  card_home,
  card_shop,
  visamastercard
};
