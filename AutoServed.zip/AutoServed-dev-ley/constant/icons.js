const logo_with_text = require("../assets/icon/logo_with_text.png");
const car = require("../assets/icon/car.png");
const calendar = require("../assets/icon/calendar.png");
const calendar2 = require("../assets/icon/calendar2.png");
const deferred = require("../assets/icon/deferred.png");
const history = require("../assets/icon/history.png");
const history2 = require("../assets/icon/history2.png");
const wallet = require("../assets/icon/wallet.png");
const pms = require("../assets/icon/pms.png");
const change_oil = require("../assets/icon/change_oil.png");
const car_def = require("../assets/icon/car_def.png");
const battery = require("../assets/icon/battery.png");
const bodypaint = require("../assets/icon/bodypaint.png");
const cardiag = require("../assets/icon/cardiag.png");
const chat = require("../assets/icon/chat.png");
const generalrepair = require("../assets/icon/generalrepair.png");
const roadside = require("../assets/icon/roadside.png");
const schedule = require("../assets/icon/schedule.png");
const tires = require("../assets/icon/tires.png");
const loading_logo = require("../assets/icon/loading_logo.png");
const google = require("../assets/icon/google.png");
const facebook = require("../assets/icon/facebook.png");
const price_setup = require("../assets/icon/price_setup.png");
const services_offered = require("../assets/icon/services_offered.png");
const customer_messages = require("../assets/icon/customer_messages.png");
const quatation = require("../assets/icon/quatation.png");
const myshop = require("../assets/icon/myshop.png");
const home = require("../assets/icon/home.png");
const party_pop = require("../assets/icon/party_pop.png");
const backjob = require("../assets/icon/backjob.png");
const car_shop = require("../assets/icon/car_shop.png");
const reminders = require("../assets/icon/reminders.png");
const sales = require("../assets/icon/sales.png");
const shop_management = require("../assets/icon/shop_management.png");
const warranty = require("../assets/icon/warranty.png");

export default {
  logo_with_text,
  car,
  deferred,
  wallet,
  pms,
  change_oil,
  calendar,
  calendar2,
  car_def,
  battery,
  bodypaint,
  cardiag,
  deferred,
  history,
  history2,
  chat,
  generalrepair,
  roadside,
  schedule,
  tires,
  loading_logo,
  google,
  facebook,
  price_setup,
  services_offered,
  customer_messages,
  quatation,
  myshop,
  home,
  party_pop,
  backjob,
  car_shop,
  reminders,
  sales,
  shop_management,
  warranty
};
