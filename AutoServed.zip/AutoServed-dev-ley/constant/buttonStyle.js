import { StyleSheet } from "react-native";
import { colors, screen } from "../constant";
const btn = StyleSheet.create({
  btnDarkBlue: {
    backgroundColor: colors.dark_blue,
    width: 0.8 * screen.width,
    height: 48,
    borderRadius: 50,
    alignItems: "center",
    justifyContent: "center",
    top: -40,
    zIndex: 200
  },
  lblBtnDarkBlue: {
    fontFamily: "OpenSans-Regular",
    fontSize: 30,
    color: "white"
  },
  btnTwoEdit: {
    width: 140,
    height: 40,
    backgroundColor: colors.dark_blue,
    borderTopLeftRadius: 20,
    borderBottomLeftRadius: 20,
    alignItems: "center",
    justifyContent: "center"
  },
  btnTwoDelete: {
    width: 140,
    height: 40,
    backgroundColor: "red",
    borderTopRightRadius: 20,
    borderBottomRightRadius: 20,
    alignItems: "center",
    justifyContent: "center"
  },
  lblTwoBtn: {
    fontFamily: "OpenSans-Regular",
    color: "white",
    fontSize: 16
  }
});

export default {
  btn
};
