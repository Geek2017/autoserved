const blue_backgroud = "#86C2F2";
const dark_blue = "#111E3A";
const font_text_color = "#2699FB";
const blue_backgroud_secondary = "#1076C1";
const blue_backgroud_shop = "#1076C1";
const another_blue = "#3476C1";
export default {
  blue_backgroud,
  dark_blue,
  font_text_color,
  blue_backgroud_secondary,
  blue_backgroud_shop,
  another_blue
};
