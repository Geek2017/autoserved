import { StyleSheet } from "react-native";

const main = StyleSheet.create({
  Header2: {
    fontFamily: "OpenSans-Regular",
    fontWeight: "bold",
    fontSize: 40
  },
  Header3: {
    fontFamily: "OpenSans-Regular",
    fontWeight: "bold",
    fontSize: 24,
    letterSpacing: -2
  },
  Body: {
    fontFamily: "OpenSans-Regular",
    fontWeight: "normal",
    fontSize: 16
    // lineHeight: lineHeight(140)
  },
  PreTitle: {
    fontFamily: "OpenSans-Regular",
    fontWeight: "bold",
    fontSize: 10
  },
  Button: {
    fontFamily: "OpenSans-Regular",
    fontWeight: "bold",
    fontSize: 16,
    letterSpacing: 1
  },
  subtleText: {
    fontFamily: "OpenSans-Regular",
    fontSize: 24
  },
  small: {
    fontFamily: "OpenSans-Regular",
    fontSize: 14
  },
  linkText: {
    fontFamily: "OpenSans-Bold",
    fontSize: 16,
    textDecorationStyle: "solid"
  },
  Bold: {
    fontFamily: "OpenSans-Bold"
  }
});

export default {
  main
};
