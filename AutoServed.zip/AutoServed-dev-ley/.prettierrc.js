// prettier.config.js or .prettierrc.js
module.exports = {
  trailingComma: "none",
  semi: true,
  jsxBracketSameLine: true
};
