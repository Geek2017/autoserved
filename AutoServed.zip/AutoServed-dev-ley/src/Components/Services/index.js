//import liraries
import React, { useState } from "react";
import { View, Text, StyleSheet, TouchableOpacity } from "react-native";
import { CheckBox, Button } from "react-native-elements";
import { colors, screen } from "../../../constant";
import buttonStyle from "../../../constant/buttonStyle";
// create a component
export const PMS1 = ({ setPage }) => {
  const [check, setCheck] = useState(false);
  const onHadler = () => {
    if (check) {
      setPage(2);
    } else {
      alert("Please agree to terms and condition.");
    }
  };
  return (
    <View>
      <View style={styles.container}>
        <Text
          style={{
            color: colors.font_text_color,
            fontFamily: "OpenSans-Regular",
            fontSize: 0.02 * screen.height,
            padding: 10
          }}>
          MINOR PMS (every 5K, 10K, 15K, 25K,
          30K,35k45K,50K,55K,65K,70K,75K,85K,90K,95K) Kilometers)
        </Text>
        <View
          style={{
            justifyContent: "center",
            alignItems: "center",
            flexDirection: "row"
          }}>
          <View style={styles.data_content}>
            <View>
              <Text style={styles.headerLbl}>Change</Text>
              <Text style={styles.lbl}>1. Engine Oil</Text>
              <Text style={styles.lbl}>2. Oil Filter</Text>
              <Text style={styles.lbl}>3. Flushing (optional)</Text>
            </View>

            <View>
              <Text style={styles.headerLbl}>Inspect/Clean/Adjust</Text>
              <Text style={styles.lbl}>1. INSPECT ALL Filters</Text>
              <Text style={styles.lbl}>- Air Filter</Text>
              <Text style={styles.lbl}>- Cabin/AC filter</Text>
              <Text style={styles.lbl}>- Fuel filter</Text>
              <Text style={styles.lbl}>2. Inspect All Fluids</Text>
              <Text style={styles.lbl}>- Power steering</Text>
              <Text style={styles.lbl}>- ATF or Gear oil</Text>
              <Text style={styles.lbl}>- Break fluid</Text>
              <Text style={styles.lbl}>
                3. INSPECT AND CLEAN Spark Plugs (if applicable)
              </Text>
              <Text style={styles.lbl}>4. INSPECT AND Radiator Coolant</Text>
              <Text style={styles.lbl}>5. INSPECT All Belts</Text>
              <Text style={styles.lbl}>- Alternator belt</Text>
              <Text style={styles.lbl}>- Ac belt</Text>
              <Text style={styles.lbl}>
                6. INSPECT Tires Condition, Inflation, Wear
              </Text>
              <Text style={styles.lbl}>
                7. INSPECT/ADJUST Hand / Foot Brake clearances
              </Text>
              <Text style={styles.lbl}>8. INSPECT AND TEST Battery</Text>
              <Text style={styles.lbl}>9. INSPECT Horn</Text>
              <Text style={styles.lbl}>10. INSPECT All Lights</Text>
              <Text style={styles.lbl}>
                - Exterior; head, signal, tail, parking, clearance
              </Text>
              <Text style={styles.lbl}>
                - Interior; reading, dome, high-mount/brake light
              </Text>
              <Text style={styles.lbl}>11. INSPECT Wiper Blades</Text>
              <Text style={styles.lbl}>12. INSPECT Windshield Wash system</Text>
              <Text style={styles.lbl}>13. INSPECT AC System</Text>
              <Text style={styles.lbl}>
                14. INSPECT Steering and Underchassis
              </Text>
              <Text style={styles.lbl}>
                15. REMOVE/INSPECT, Adjust Brake Pads/Shoes
              </Text>
              <Text style={styles.lbl}>16. PERFORM Brake Cleaning</Text>
              <Text style={styles.lbl}>17. PERFORM Tire Rotation</Text>
            </View>
            {/* Checkbox */}
            <CheckBox
              title="I agree with the Terms & Conditions 
            and Warrant policy by AutoServed"
              checked={check}
              onIconPress={() => setCheck(!check)}
              textStyle={{ color: colors.font_text_color }}
            />
          </View>
        </View>
        <Button
          onPressIn={() => onHadler()}
          title="Next"
          containerStyle={{
            borderRadius: 70,
            top: 20,
            width: 0.8 * screen.width,
            alignSelf: "center"
          }}
          buttonStyle={{
            backgroundColor: colors.dark_blue,
            height: 40
          }}
        />
      </View>
      <View style={{ paddingBottom: 100 }}></View>
    </View>
  );
};

export const PMS2 = ({ setPage }) => {
  const [check, setCheck] = useState(false);
  const onHadler = () => {
    if (check) {
      setPage(3);
    } else {
      alert("Please agree to terms and condition.");
    }
  };
  return (
    <View>
      <View
        style={[
          styles.container,
          {
            backgroundColor: colors.font_text_color
          }
        ]}>
        <Text
          style={{
            color: "white",
            fontFamily: "OpenSans-Regular",
            fontSize: 0.02 * screen.height,
            padding: 10
          }}>
          MAJOR PMS (every 20K, 40K, 60K, 80K, 100K Kilometers)
        </Text>
        <View
          style={{
            justifyContent: "center",
            alignItems: "center",
            flexDirection: "row"
          }}>
          <View style={styles.data_content}>
            <View>
              <Text style={[styles.headerLbl, { color: "white" }]}>Change</Text>
              <Text style={[styles.lbl, { color: "white" }]}>
                1. Engine Oil
              </Text>
              <Text style={[styles.lbl, { color: "white" }]}>
                2. Oil Filter
              </Text>
              <Text style={[styles.lbl, { color: "white" }]}>
                3. Flushing (optional)
              </Text>
              <Text style={[styles.lbl, { color: "white" }]}>
                4. Air Filter
              </Text>
              <Text style={[styles.lbl, { color: "white" }]}>
                5. Cabin Filter
              </Text>
              <Text style={[styles.lbl, { color: "white" }]}>6. Coolant</Text>
              <Text style={[styles.lbl, { color: "white" }]}>
                7. Brake Fluid
              </Text>
              <Text style={[styles.lbl, { color: "white" }]}>
                8. Power Steering Fluid
              </Text>
              <Text style={[styles.lbl, { color: "white" }]}>
                9. Brake Cleaner
              </Text>
            </View>

            <View>
              <Text style={[styles.headerLbl, { color: "white" }]}>
                Inspect/Clean/Adjust
              </Text>
              <Text style={[styles.lbl, { color: "white" }]}>
                1. INSPECT AND CLEAN Spark Plugs (If Applicable)
              </Text>
              <Text style={[styles.lbl, { color: "white" }]}>
                2. INSPECT Radiator Coolant
              </Text>
              <Text style={[styles.lbl, { color: "white" }]}>
                3. INSPECT All Belts
              </Text>
              <Text style={[styles.lbl, { color: "white" }]}>
                - Alternator belt
              </Text>
              <Text style={[styles.lbl, { color: "white" }]}>- AC belt</Text>
              <Text style={[styles.lbl, { color: "white" }]}>
                4. INSPECT Tires Condition, Inflation, Wear
              </Text>
              <Text style={[styles.lbl, { color: "white" }]}>
                5. INSPECT/ADJUST Hand / Foot Brake clearances
              </Text>
              <Text style={[styles.lbl, { color: "white" }]}>
                6. INSPECT AND TEST Battery
              </Text>
              <Text style={[styles.lbl, { color: "white" }]}>
                7. INSPECT Horn
              </Text>
              <Text style={[styles.lbl, { color: "white" }]}>
                8. INSPECT All Lights
              </Text>
              <Text style={[styles.lbl, { color: "white" }]}>
                - Exterior; head, signal, tail, parking, clearance
              </Text>
              <Text style={[styles.lbl, { color: "white" }]}>
                - Interior; reading, dome, high-mount/brake light
              </Text>
              <Text style={[styles.lbl, { color: "white" }]}>
                9. INSPECT Wiper Blades
              </Text>
              <Text style={[styles.lbl, { color: "white" }]}>
                10. INSPECT Windshield Wash system
              </Text>
              <Text style={[styles.lbl, { color: "white" }]}>
                11. INSPECT AC System
              </Text>
              <Text style={[styles.lbl, { color: "white" }]}>
                12. INSPECT Steering and Underchassis
              </Text>
              <Text style={[styles.lbl, { color: "white" }]}>
                13. REMOVE/INSPECT, Adjust Brake Pads/Shoes
              </Text>
              <Text style={[styles.lbl, { color: "white" }]}>
                14. PERFORM Brake Cleaning
              </Text>
              <Text style={[styles.lbl, { color: "white" }]}>
                15. PERFORM Tire Rotation
              </Text>
            </View>
            {/* Checkbox */}
            <CheckBox
              title="I agree with the Terms & Conditions 
              and Warrant policy by AutoServed"
              checked={check}
              onIconPress={() => setCheck(!check)}
              containerStyle={{ backgroundColor: colors.font_text_color }}
              textStyle={{ color: "white" }}
              checkedColor="black"
            />
          </View>
        </View>
        <Button
          onPressIn={() => onHadler()}
          title="Next"
          containerStyle={{
            borderRadius: 70,
            top: 20,
            width: 0.8 * screen.width,
            alignSelf: "center"
          }}
          buttonStyle={{
            backgroundColor: colors.dark_blue,
            height: 40
          }}
        />
      </View>
      <View style={{ paddingBottom: 100 }}></View>
    </View>
  );
};

export const PMS3 = ({ setPage, navigation }) => {
  const [check, setCheck] = useState(false);

  const onHadler = () => {
    if (check) {
      navigation.navigate("ShopScreen");
    } else {
      alert("Please agree to terms and condition.");
    }
  };
  return (
    <View>
      <View
        style={[
          styles.container,
          {
            backgroundColor: colors.font_text_color
          }
        ]}>
        <Text
          style={{
            color: "white",
            fontFamily: "OpenSans-Regular",
            fontSize: 0.02 * screen.height,
            padding: 10
          }}>
          Oil Types: Regular, Semi-Synthetic, Fully-Synthetic
        </Text>
        <View
          style={{
            justifyContent: "center",
            alignItems: "center",
            flexDirection: "row"
          }}>
          <View style={styles.data_content}>
            <View>
              <Text style={[styles.headerLbl, { color: "white" }]}>Change</Text>
              <Text style={[styles.lbl, { color: "white" }]}>
                1. Engine Oil
              </Text>
              <Text style={[styles.lbl, { color: "white" }]}>
                2. Oil Filter
              </Text>
              <Text style={[styles.lbl, { color: "white" }]}>
                3. Flushing (optional)
              </Text>
              <Text style={[styles.lbl, { color: "white" }]}>
                4. Drain plug (as needed)
              </Text>
              <Text style={[styles.lbl, { color: "white" }]}>
                5. Computer reset (as needed)
              </Text>
            </View>

            <View>
              <Text style={[styles.headerLbl, { color: "white" }]}>
                Inspection Only
              </Text>
              <Text style={[styles.lbl, { color: "white" }]}>
                1. INSPECT All Filters
              </Text>
              <Text style={[styles.lbl, { color: "white" }]}>- Air filter</Text>
              <Text style={[styles.lbl, { color: "white" }]}>
                - Cabin/ AC filter
              </Text>
              <Text style={[styles.lbl, { color: "white" }]}>
                - Fuel filter
              </Text>
              <Text style={[styles.lbl, { color: "white" }]}>
                2. INSPECT All Fluids
              </Text>
              <Text style={[styles.lbl, { color: "white" }]}>
                - Power steering
              </Text>
              <Text style={[styles.lbl, { color: "white" }]}>
                - ATF or Gear oil
              </Text>
              <Text style={[styles.lbl, { color: "white" }]}>
                - Brake fluid
              </Text>
              <Text style={[styles.lbl, { color: "white" }]}>
                3. INSPECT Spark Plugs (If Applicable)
              </Text>
              <Text style={[styles.lbl, { color: "white" }]}>
                4. INSPECT Radiator Coolant
              </Text>
              <Text style={[styles.lbl, { color: "white" }]}>
                5. INSPECT All Belts
              </Text>
              <Text style={[styles.lbl, { color: "white" }]}>
                - Alternator belt
              </Text>
              <Text style={[styles.lbl, { color: "white" }]}>- AC belt</Text>
              <Text style={[styles.lbl, { color: "white" }]}>
                6. INSPECT Tires Condition, Inflation, Wear
              </Text>
              <Text style={[styles.lbl, { color: "white" }]}>
                7. INSPECT/ADJUST Hand / Foot Brake clearances
              </Text>
              <Text style={[styles.lbl, { color: "white" }]}>
                8. INSPECT AND TEST Battery
              </Text>
              <Text style={[styles.lbl, { color: "white" }]}>
                9. INSPECT Horn
              </Text>
              <Text style={[styles.lbl, { color: "white" }]}>
                10. INSPECT All Lights
              </Text>
              <Text style={[styles.lbl, { color: "white" }]}>
                - Exterior; head, signal, tail, parking, clearance
              </Text>
              <Text style={[styles.lbl, { color: "white" }]}>
                - Interior; reading, dome, high-mount/brake light
              </Text>
              <Text style={[styles.lbl, { color: "white" }]}>
                11. INSPECT Wiper Blades
              </Text>
              <Text style={[styles.lbl, { color: "white" }]}>
                12. INSPECT Windshield Wash system
              </Text>
              <Text style={[styles.lbl, { color: "white" }]}>
                13. INSPECT AC System
              </Text>
              <Text style={[styles.lbl, { color: "white" }]}>
                14. INSPECT Steering and Underchassis
              </Text>
              <Text style={[styles.lbl, { color: "white" }]}>
                15. INSPECT Brake Pads/Shoes
              </Text>
            </View>
            {/* Checkbox */}
            <CheckBox
              title="I agree with the Terms & Conditions 
                and Warrant policy by AutoServed"
              checked={check}
              onIconPress={() => setCheck(!check)}
              containerStyle={{ backgroundColor: colors.font_text_color }}
              textStyle={{ color: "white" }}
              checkedColor="black"
            />
          </View>
        </View>
        <Button
          onPressIn={() => onHadler()}
          title="Next"
          containerStyle={{
            borderRadius: 70,
            top: 20,
            width: 0.8 * screen.width,
            alignSelf: "center"
          }}
          buttonStyle={{
            backgroundColor: colors.dark_blue,
            height: 40
          }}
        />
      </View>
      <View style={{ paddingBottom: 100 }}></View>
    </View>
  );
};
// define your styles
const styles = StyleSheet.create({
  container: {
    marginHorizontal: 16,
    backgroundColor: "white",
    alignItems: "center",
    paddingTop: 10,
    borderRadius: 15,
    shadowColor: "#000",
    shadowOffset: {
      width: 0,
      height: 2
    },
    shadowOpacity: 0.25,
    shadowRadius: 3.84,
    elevation: 5
  },
  data_content: {
    width: 0.9 * screen.width,
    height: "100%",
    padding: 10
  },
  headerLbl: {
    fontFamily: "OpenSans-Bold",
    color: colors.font_text_color
  },
  lbl: {
    fontFamily: "OpenSans-Regular",
    color: colors.font_text_color
  }
});
export default {
  PMS1,
  PMS2,
  PMS3
};
