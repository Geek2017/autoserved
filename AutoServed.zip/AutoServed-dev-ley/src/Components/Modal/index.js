import React from "react";
import {
  View,
  Text,
  StyleSheet,
  Dimensions,
  TouchableOpacity
} from "react-native";
import Modal from "react-native-modal";
import { colors, mainStyle, screen } from "../../../constant";
const index = ({
  modalShow,
  setModalShow,
  title,
  content,
  type,
  btnTitle,
  handle,
  cancelHide,
  isShopCreation
}) => {
  return (
    <View>
      <Modal
        animationIn="bounceInUp"
        style={{ backgroundColor: "transparent" }}
        isVisible={modalShow}>
        <View style={styles.container}>
          <View style={styles.card}>
            <Text
              style={[
                mainStyle.main.Header3,
                {
                  color: "white",
                  paddingHorizontal: 32,
                  paddingTop: 32
                }
              ]}>
              {title}
            </Text>
            <Text
              style={[
                mainStyle.main.Body,
                {
                  color: "white",
                  paddingHorizontal: 32,
                  paddingTop: 16
                }
              ]}>
              {content}
            </Text>
            <View style={{ flexDirection: "row" }}>
              {!cancelHide ? (
                <TouchableOpacity
                  style={[
                    mainStyle.main.Button,
                    {
                      paddingLeft: 95,
                      paddingTop: 44
                    }
                  ]}
                  onPress={() => setModalShow(false)}>
                  <Text
                    style={{
                      fontFamily: "OpenSans-Bold",
                      color: "white"
                    }}>
                    Cancel
                  </Text>
                </TouchableOpacity>
              ) : (
                <View />
              )}
              <TouchableOpacity
                style={{
                  borderRadius: 20,
                  marginTop: 32,
                  marginLeft: 32,
                  backgroundColor:
                    type == "accept"
                      ? "#31D0AA"
                      : type == "decline"
                      ? "#D03131"
                      : "#0461B1",
                  width: 117,
                  height: 43,
                  left: isShopCreation ? 80 : 0,
                  alignItems: "center",
                  justifyContent: "center"
                }}
                onPress={handle}>
                <Text style={{ color: "white", fontFamily: "OpenSans-Bold" }}>
                  {btnTitle}
                </Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>
    </View>
  );
};
const { height, width } = Dimensions.get("screen");
const styles = StyleSheet.create({
  container: {
    height: "100%",
    width: "100%",
    alignItems: "center",
    justifyContent: "flex-end"
  },
  card: {
    backgroundColor: colors.blue_backgroud,
    borderRadius: 32,
    height: 227,
    width: 343,
    bottom: (screen.height / 2) * 0.8,
    shadowColor: "#000",
    shadowOffset: {
      width: 0,
      height: 1
    },
    shadowOpacity: 0.22,
    shadowRadius: 2.22,
    elevation: 3
  }
});
export default index;
