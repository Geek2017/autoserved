//import liraries
import React, { useState } from "react";
import { View, Text, StyleSheet, Image, Linking, Platform } from "react-native";
import { screen, images, colors, mainStyle } from "../../../constant";
import IconF from "react-native-vector-icons/FontAwesome5";
import { ButtonGroup, Icon } from "react-native-elements";
// create a component
import { inject, observer } from "mobx-react";
function thousands_separators(num) {
  var newNstr = num.toString().replace(",", "");
  var num_parts = newNstr.toString().split(".");
  num_parts[0] = num_parts[0].replace(/\B(?=(\d{3})+(?!\d))/g, ",");
  return num_parts.join(".");
}
const index = ({ arrData, threeBtn, navigation, qoutesData, priceData }) => {
  const [selectedIndex, setSelectedIndex] = useState();

  let total;
  let pricingCheck = priceData ? priceData : [];
  pricingCheck.map((item) => {
    total =
      parseInt(item.airfilter ? item.airfilter : 0) +
      parseInt(item.cabinfilter ? item.cabinfilter : 0) +
      parseInt(item.coolant ? item.coolant : 0) +
      parseInt(item.engineoil ? item.engineoil : 0) +
      parseInt(item.flushing ? item.flushing : 0) +
      parseInt(item.labor ? item.labor : 0) +
      parseInt(item.oilfilter ? item.oilfilter : 0) +
      parseInt(item.bsf ? item.bsf : 0) +
      parseInt(item.sparkplug ? item.sparkplug : 0) +
      parseInt(item.breakfluid ? item.breakfluid : 0) +
      parseInt(item.psf ? item.psf : 0);
  });
  const callIcon = () => <IconF name="facebook-messenger" size={20} />;
  const messageIcon = () => <IconF name="phone" size={20} />;
  const booknow = () => <IconF name="comment" size={20} />;
  const buttons = [
    { element: callIcon },
    { element: messageIcon },
    { element: booknow }
  ];

  const updateIndex = async (selectedIndex) => {
    setSelectedIndex(selectedIndex);
    if (selectedIndex == 0) {
      await Linking.openURL("https://m.me/" + arrData.fb_messenger);
    }
    if (selectedIndex == 1) {
      const separator = Platform.OS === "ios" ? "tel://" : "tel:";
      const url = `${separator}${arrData.biz_no}`;
      await Linking.openURL(url);
    }
    if (selectedIndex == 2) {
      const separator = Platform.OS === "ios" ? "tel://" : "tel:";
      const url = `sms:${arrData.biz_no}${separator}`;
      await Linking.openURL(url);
    }
  };
  return (
    <View style={styles.container}>
      {/* First View with image */}
      <View style={styles.firstContentOne}>
        {/* shop img */}
        <View
          style={{ width: "40%", paddingLeft: 8, justifyContent: "center" }}>
          <Image
            source={
              !arrData
                ? null
                : arrData.shop_frontimg
                ? { uri: arrData.shop_frontimg }
                : images.card_home
            }
            style={styles.img}
          />
        </View>
        {/* Vertical Line */}
        <View style={{ borderWidth: 1, borderColor: "white" }}></View>

        {/* details */}
        <View style={{ paddingHorizontal: 8 }}>
          <Text
            style={[mainStyle.main.Header2, { color: "white", fontSize: 16 }]}>
            {arrData ? arrData.shop_name.toUpperCase() : ""}
          </Text>
          <Text
            style={[
              mainStyle.main.subtleText,
              {
                fontSize: 10,
                color: "white",
                width: screen.width * 0.55
              }
            ]}>
            {arrData
              ? (arrData.city,
                +" " +
                  arrData.brgy +
                  " " +
                  arrData.province +
                  " " +
                  arrData.region)
              : ""}
          </Text>
          <Text style={[mainStyle.main.Bold, { color: "white", fontSize: 10 }]}>
            CONTACT :{" "}
            {`${arrData ? arrData.owner_contactperson.toUpperCase() : ""}\n${
              arrData ? arrData.owner_contactperson_no : ""
            }\n${arrData ? arrData.email : ""}`}
          </Text>
        </View>
      </View>
      {/* second view details */}
      <View
        style={{
          flexDirection: "row",
          paddingVertical: 8
        }}>
        {/* Left Side */}
        <View style={{ width: "50%" }}>
          <Text
            style={[
              mainStyle.main.Header2,
              { color: colors.another_blue, fontSize: 16 }
            ]}>
            Quote: ₱{" "}
            <Text
              style={{
                color: colors.another_blue,
                fontSize: 16,
                fontWeight: "normal"
              }}>
              {total ? thousands_separators(total) : 0}
            </Text>
          </Text>
          <Text
            style={[
              mainStyle.main.Header2,
              { color: colors.another_blue, fontSize: 16 }
            ]}>
            Job: PMS
          </Text>
          <Text
            style={[
              mainStyle.main.Header2,
              { color: colors.another_blue, fontSize: 16 }
            ]}>
            Note:{" "}
            <Text
              style={{
                color: colors.another_blue,
                fontSize: 14,
                fontWeight: "normal"
              }}>
              Price may change during actual inspection of the car
            </Text>
          </Text>
        </View>
        {/* Right Side */}
        <View style={{ width: "50%" }}>
          <Text
            style={[
              mainStyle.main.Header2,
              { color: colors.another_blue, fontSize: 16 }
            ]}>
            See details:
            <Text
              style={{
                fontSize: 16,
                textDecorationStyle: "solid",
                fontWeight: "normal"
              }}>
              HERE
            </Text>
          </Text>

          <Text
            style={[
              mainStyle.main.Header2,
              { color: colors.another_blue, fontSize: 16 }
            ]}>
            Schedule:{" "}
            <Text
              style={{
                fontSize: 16,
                fontWeight: "normal"
              }}>
              {qoutesData.requestdate}
            </Text>
          </Text>

          {threeBtn ? (
            <ButtonGroup
              onPress={(index) => updateIndex(index)}
              selectedIndex={selectedIndex}
              buttons={buttons}
              containerStyle={{
                height: 0.04 * screen.height,
                width: 0.4 * screen.width,
                borderRadius: 75,
                borderWidth: 2,
                borderColor: colors.blue_backgroud_secondary
              }}
              selectedButtonStyle={{ backgroundColor: colors.font_text_color }}
            />
          ) : (
            <View />
          )}
        </View>
      </View>
    </View>
  );
};

// define your styles
const styles = StyleSheet.create({
  container: {
    width: screen.width * 0.9,
    paddingVertical: 8,
    paddingHorizontal: 8
  },
  firstContentOne: {
    flexDirection: "row",
    backgroundColor: colors.another_blue,
    borderRadius: 15
  },
  img: {
    height: 75,
    width: "90%",
    borderRadius: 15,
    marginVertical: 8
  },
  lblHeader: {
    color: colors.font_text_color,
    fontFamily: "OpenSans-Regular"
  },
  lbl2: {
    color: colors.font_text_color,
    fontFamily: "OpenSans-Regular",
    fontSize: 0.018 * screen.height
  }
});

//make this component available to the app
export default inject("store")(observer(index));
