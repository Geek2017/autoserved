//import liraries
import React, { useReducer, useState } from "react";
import { View, Text, StyleSheet, TouchableOpacity } from "react-native";
import { colors, screen } from "../../../../constant";
// create a component
const initialState = { name: "" };

const index = ({
  one,
  two,
  three,
  title,
  setDataReplacement,
  dataReplacement
}) => {
  function reducer(state, action) {
    switch (action.type) {
      case "one":
        return { name: "one" };
      case "two":
        return { name: "two" };
      case "three":
        return { name: "three" };
      default:
        throw new Error();
    }
  }

  const [state, dispatch] = useReducer(reducer, initialState);
  const jsonHandlerReplacement = (val) => {
    let json = { title: title, value: val };
    setDataReplacement((prev) => [...prev, json]);
  };

  return (
    <View style={styles.threeBtnStyle}>
      <TouchableOpacity
        style={[
          styles.left,
          {
            backgroundColor: state.name == "one" ? colors.dark_blue : "white"
          }
        ]}
        onPress={() => {
          dispatch({ type: "one" }), jsonHandlerReplacement(one);
        }}>
        <Text
          style={{
            fontFamily: "OpenSans-Regular",
            color: state.name == "one" ? "white" : colors.blue_backgroud,
            fontSize: 0.015 * screen.height
          }}>
          {one}
        </Text>
      </TouchableOpacity>
      <TouchableOpacity
        style={[
          styles.center,
          {
            backgroundColor: state.name == "two" ? colors.dark_blue : "white",
            alignItems: "center",
            justifyContent: "center"
          }
        ]}
        onPress={() => {
          dispatch({ type: "two" }), jsonHandlerReplacement(two);
        }}>
        <Text
          style={{
            flexShrink: 1,
            fontFamily: "OpenSans-Regular",
            color: state.name == "two" ? "white" : colors.blue_backgroud,
            textAlign: "center",
            fontSize: 0.013 * screen.height
          }}>
          {two}
        </Text>
      </TouchableOpacity>
      <TouchableOpacity
        style={[
          styles.right,
          {
            backgroundColor: state.name == "three" ? colors.dark_blue : "white",
            alignItems: "center",
            justifyContent: "center"
          }
        ]}
        onPress={() => {
          dispatch({ type: "three" }), jsonHandlerReplacement(three);
        }}>
        <Text
          style={{
            fontFamily: "OpenSans-Regular",
            color: state.name == "three" ? "white" : colors.blue_backgroud,
            textAlign: "center",
            fontSize: 0.013 * screen.height
          }}>
          {three}
        </Text>
      </TouchableOpacity>
    </View>
  );
};

// define your styles
const styles = StyleSheet.create({
  threeBtnStyle: {
    backgroundColor: "white",
    width: "80%",
    height: 50,
    borderRadius: 70,
    borderWidth: 1,
    borderColor: colors.blue_backgroud_secondary,
    color: colors.font_text_color,
    marginBottom: 20,
    flexDirection: "row"
  },
  left: {
    backgroundColor: colors.dark_blue,
    width: "33%",
    height: "100%",
    borderTopLeftRadius: 20,
    borderBottomLeftRadius: 20,
    alignItems: "center",
    justifyContent: "center",
    borderRightWidth: 1,
    borderRightColor: colors.blue_backgroud
  },
  center: {
    backgroundColor: colors.dark_blue,
    width: "33%",
    height: "100%",
    alignItems: "center",
    justifyContent: "center"
  },
  right: {
    backgroundColor: colors.dark_blue,
    width: "35%",
    height: "100%",
    borderTopRightRadius: 20,
    borderBottomRightRadius: 20,
    alignItems: "center",
    justifyContent: "center",
    borderLeftWidth: 1,
    borderLeftColor: colors.blue_backgroud
  }
});

//make this component available to the app
export default index;
