//import liraries
import React, { Component } from "react";
import { View, Text, StyleSheet, TouchableOpacity } from "react-native";
import { screen, colors } from "../../../../constant";
import { Button } from "react-native-elements";
import Icon from "react-native-vector-icons/FontAwesome";
// create a component
const index = ({ title, onPress, isCheck }) => {
  return (
    <TouchableOpacity style={styles.inputStyle} onPress={onPress}>
      <Text
        style={{
          fontFamily: "OpenSans-Regular",
          fontSize: 18,
          color: colors.font_text_color
        }}>
        {title}
      </Text>
      {isCheck ? (
        <Icon name="check" size={15} color="darkblue" style={{ zIndex: 20 }} />
      ) : (
        <View />
      )}
    </TouchableOpacity>
  );
};

// define your styles
const styles = StyleSheet.create({
  inputStyle: {
    backgroundColor: "#fafafa",
    borderRadius: 10,
    height: 40,
    width: 0.8 * screen.width,
    margin: 10,
    alignItems: "flex-start",
    justifyContent: "center",
    paddingLeft: 20,
    paddingRight: 20
  }
});

//make this component available to the app
export default index;
