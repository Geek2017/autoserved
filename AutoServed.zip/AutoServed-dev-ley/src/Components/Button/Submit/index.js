//import liraries
import React, { Component } from "react";
import { View, Text, StyleSheet, TouchableOpacity } from "react-native";
import { screen, colors } from "../../../../constant";
// create a component
const index = ({ title, onPress, inProfile }) => {
  return (
    <TouchableOpacity
      style={[
        styles.viewStyle,
        {
          width: inProfile ? 0.83 * screen.width : 0.85 * screen.width,
          zIndex: 10
        }
      ]}
      onPress={onPress}>
      <Text style={styles.lbl}>{title}</Text>
    </TouchableOpacity>
  );
};

// define your styles
const styles = StyleSheet.create({
  viewStyle: {
    backgroundColor: colors.dark_blue,
    width: 0.7 * screen.width,
    height: 50,
    borderRadius: 70,
    fontSize: 18,
    color: colors.font_text_color,
    alignItems: "center",
    justifyContent: "center"
  },
  lbl: {
    fontFamily: "OpenSans-Regular",
    fontSize: 20,
    color: "white"
  }
});

//make this component available to the app
export default index;
