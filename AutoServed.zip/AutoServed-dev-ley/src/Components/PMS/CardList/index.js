//import liraries
import React, { Component } from "react";
import { View, Text, StyleSheet, Image, TouchableOpacity } from "react-native";
import { screen, colors, icons } from "../../../../constant";
import Icon from "react-native-vector-icons/Feather";
function thousands_separators(num) {
  var newNstr = num.toString().replace(",", "");
  var num_parts = newNstr.toString().split(".");
  num_parts[0] = num_parts[0].replace(/\B(?=(\d{3})+(?!\d))/g, ",");
  return num_parts.join(".");
}
// create a component
const index = ({ arrData, navHandle }) => {
  return (
    <View style={styles.container}>
      <View
        style={{
          justifyContent: "center",
          alignItems: "center",
          flexDirection: "row"
        }}>
        <View style={styles.data_content}>
          <View style={{ flexDirection: "row" }}>
            <Text style={styles.lbl}>Plate Number : </Text>
            <Text style={styles.lbl}>
              {thousands_separators(arrData.plateno)}
            </Text>
          </View>
          <View style={{ flexDirection: "row" }}>
            <Text style={styles.lbl}>Year Model : </Text>
            <Text style={styles.lbl}>{arrData.year}</Text>
          </View>

          <View style={{ flexDirection: "row" }}>
            <Text style={styles.lbl}>Make : </Text>
            <Text style={styles.lbl}>{arrData.make}</Text>
          </View>

          <View style={{ flexDirection: "row" }}>
            <Text style={styles.lbl}>Model : </Text>
            <Text style={styles.lbl}>{arrData.model}</Text>
          </View>
          <View style={{ flexDirection: "row" }}>
            <Text style={styles.lbl}>Engine : </Text>
            <Text style={styles.lbl}>{arrData.engine}</Text>
          </View>
          <View style={{ flexDirection: "row" }}>
            <Text style={styles.lbl}>Transmission :</Text>
            <Text style={styles.lbl}>{arrData.transmission}</Text>
          </View>
          <View style={{ flexDirection: "row" }}>
            <Text style={styles.lbl}>DOP : </Text>
            <Text style={styles.lbl}>{arrData.purchasedate}</Text>
          </View>
          <View style={{ flexDirection: "row" }}>
            <Text style={styles.lbl}>CurrentMileage: </Text>
            <Text style={styles.lbl}>
              {thousands_separators(arrData.mileage)} KM
            </Text>
          </View>
        </View>
        {/* Icons */}
        <TouchableOpacity style={styles.icons_content} onPress={navHandle}>
          {/* <Image source={icons.calendar} />
          <Image source={icons.car_def} />
          <Image source={icons.history} /> */}
          <Icon name="chevron-right" size={30} color="white" />
        </TouchableOpacity>
      </View>
    </View>
  );
};

// define your styles
const styles = StyleSheet.create({
  container: {
    width: 0.8 * screen.width,
    height: 220,
    backgroundColor: colors.blue_backgroud_secondary,
    marginBottom: 30,
    borderTopEndRadius: 15,
    borderBottomEndRadius: 15,
    shadowColor: "#000",
    shadowOffset: {
      width: 0,
      height: 2
    },
    shadowOpacity: 0.25,
    shadowRadius: 3.84,
    elevation: 5
  },
  data_content: {
    width: "85%",
    height: "100%",
    paddingLeft: 20,
    // paddingTop: 20,
    paddingRight: 10,
    justifyContent: "center"
  },
  icons_content: {
    width: "15%",
    height: "100%",
    justifyContent: "space-evenly",
    alignItems: "center",
    backgroundColor: colors.dark_blue,
    borderTopEndRadius: 15,
    borderBottomEndRadius: 15
  },

  lbl: {
    fontFamily: "OpenSans-Regular",
    color: "white",
    fontSize: 16,
    width: "60%"
  },
  edit: {
    width: "45%",
    height: 40,
    backgroundColor: colors.dark_blue,
    borderTopLeftRadius: 20,
    borderBottomLeftRadius: 20,
    alignItems: "center",
    justifyContent: "center"
  },
  delete: {
    width: "45%",
    height: 40,
    backgroundColor: "red",
    borderTopRightRadius: 20,
    borderBottomRightRadius: 20,
    alignItems: "center",
    justifyContent: "center"
  },
  lblEditDelete: {
    fontFamily: "OpenSans-Regular",
    color: "white"
  }
});

//make this component available to the app
export default index;
