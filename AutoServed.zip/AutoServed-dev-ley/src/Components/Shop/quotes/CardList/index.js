//import liraries
import React, { useState, useEffect } from "react";
import { View, Text, StyleSheet, Image } from "react-native";
import { screen, colors, icons, mainStyle } from "../../../../../constant";
import { TouchableOpacity } from "react-native-gesture-handler";
import moment from "moment";
import buttonStyle from "../../../../../constant/buttonStyle";
import { capitalizeFirstLetter, titleCase } from "../../../../Helper";
function thousands_separators(num) {
  var num_parts = num.toString().split(".");
  num_parts[0] = num_parts[0].replace(/\B(?=(\d{3})+(?!\d))/g, ",");
  return num_parts.join(".");
}
// create a component
const index = ({ arrData, onPressQuote, isDelete, status }) => {
  let arrDateLetter = ["1st", "2nd", "3rd"];
  const [individualInfo, setIndividualInfo] = useState({});

  useEffect(() => {
    fetch(
      `https://lj2e11f6r1.execute-api.ap-southeast-1.amazonaws.com/autoserved/users/${arrData.iqr_from}`
    )
      .then(fetch.throwErrors)
      .then((res) => res.json())
      .then((json) => {
        setIndividualInfo(json);
      })
      .catch();
  }, []);

  return (
    <View style={styles.container}>
      <View
        style={{
          justifyContent: "center",
          alignItems: "center",
          flexDirection: "row"
        }}>
        <View style={styles.data_content}>
          <View style={styles.header}>
            <Text
              style={[
                mainStyle.main.Header2,
                { color: "white", fontSize: 16, width: "50%", paddingLeft: 16 }
              ]}>
              Name :{" "}
              {capitalizeFirstLetter(
                individualInfo.fullname
                  ? individualInfo.fullname.split(/(\s+)/)[0].replace(",", "")
                  : ""
              )}
            </Text>
            <View
              style={{
                borderWidth: 1,
                borderColor: "white",
                height: 25,
                marginHorizontal: 8
              }}></View>
            <Text
              style={[
                mainStyle.main.Header2,
                { color: "white", fontSize: 16, width: "50%", paddingRight: 16 }
              ]}>
              {individualInfo.mobileno}
            </Text>
          </View>

          <View style={{ flexDirection: "row" }}>
            <Text style={styles.lbl}>Plate Number : </Text>
            <Text style={styles.lbl}>
              {thousands_separators(arrData.plateno)}
            </Text>
          </View>
          <View style={{ flexDirection: "row" }}>
            <Text style={styles.lbl}>Year Model : </Text>
            <Text style={styles.lbl}>{arrData.yrmodel}</Text>
          </View>

          <View style={{ flexDirection: "row" }}>
            <Text style={styles.lbl}>Make : </Text>
            <Text style={styles.lbl}>{arrData.make}</Text>
          </View>

          <View style={{ flexDirection: "row" }}>
            <Text style={styles.lbl}>Model : </Text>
            <Text style={styles.lbl}>{arrData.model}</Text>
          </View>
          <View style={{ flexDirection: "row" }}>
            <Text style={styles.lbl}>Engine : </Text>
            <Text style={styles.lbl}>{arrData.engine}</Text>
          </View>
          <View style={{ flexDirection: "row" }}>
            <Text style={styles.lbl}>Transmission :</Text>
            <Text style={styles.lbl}>{arrData.transmission}</Text>
          </View>
          <View style={{ flexDirection: "row" }}>
            <Text style={styles.lbl}>DOP : </Text>
            <Text style={styles.lbl}>{arrData.purchasedate}</Text>
          </View>
          <View style={{ flexDirection: "row" }}>
            <Text style={styles.lbl}>Current Mileage: </Text>
            <Text style={styles.lbl}>
              {thousands_separators(arrData.mileage)} KM
            </Text>
          </View>
          {/* Second Page */}
          <View style={{ flexDirection: "row", paddingTop: 8 }}>
            <Text style={styles.lbl}>DATE OF REQUEST: </Text>
            <Text style={styles.lbl}>{arrData.requestdate}</Text>
          </View>

          <View style={{ paddingTop: 8 }}>
            <Text style={[styles.lbl, { width: "100%" }]}>
              FOR REPLACEMENT{" "}
            </Text>
            <Text style={[styles.lbl, { width: "100%" }]}>
              - {arrData.for_replacement.split(",").join("\n- ")}
            </Text>
          </View>

          <View style={{ paddingTop: 8 }}>
            <Text style={[styles.lbl, { width: "100%" }]}>
              DATE OF REQUEST{" "}
            </Text>
            <Text style={[styles.lbl, { width: "100%" }]}>
              {arrData.preferedschedules.split(",").map((item, index) => {
                return `${arrDateLetter[index]} ${moment(item).format(
                  "MMMM DD, YYYY"
                )} ${"\n"}`;
              })}
            </Text>
          </View>

          {/* <View style={{ paddingTop: 20 }}>
            <Text style={styles.lbl}>PREFERRED TYPE OF SHOPS: </Text>
            <Text style={styles.lbl}></Text>
          </View> */}
        </View>
      </View>
      {/* Buttons */}
      <View
        style={{
          zIndex: 20,
          flexDirection: "row",
          justifyContent: "center",
          bottom: -0.015 * screen.height,
          width: "100%"
        }}>
        {/* <TouchableOpacity style={styles.edit} onPress={onPressQuote}>
          <Text style={styles.lblEditDelete}>Quote</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.delete}>
          <Text style={styles.lblEditDelete}>Decline</Text>
        </TouchableOpacity> */}
        {/* Not chosen */}
        {status == 0 ? (
          <TouchableOpacity style={[buttonStyle.btn.btnDarkBlue, { top: 10 }]}>
            <Text style={buttonStyle.btn.lblBtnDarkBlue}>PENDING</Text>
          </TouchableOpacity>
        ) : status == 1 ? (
          <TouchableOpacity
            style={[
              buttonStyle.btn.btnDarkBlue,
              { top: 10, backgroundColor: "#DEC714" }
            ]}>
            <Text style={buttonStyle.btn.lblBtnDarkBlue}>NOT CHOSEN</Text>
          </TouchableOpacity>
        ) : status == 2 ? (
          <View style={{ flexDirection: "row", justifyContent: "center" }}>
            <TouchableOpacity
              style={buttonStyle.btn.btnTwoEdit}
              onPress={onPressQuote}>
              <Text style={buttonStyle.btn.lblTwoBtn}>Quote</Text>
            </TouchableOpacity>
            <TouchableOpacity style={buttonStyle.btn.btnTwoDelete}>
              <Text style={buttonStyle.btn.lblTwoBtn}>Decline</Text>
            </TouchableOpacity>
          </View>
        ) : (
          <View />
        )}

        {/* Accepted */}
        {/* <TouchableOpacity
          style={[styles.notChosen, { backgroundColor: "#2EDE17" }]}>
          <Text style={styles.lblBtn}>Accepted</Text>
        </TouchableOpacity> */}
        {/* pending */}
        {/* <TouchableOpacity
          style={[styles.notChosen, { backgroundColor: colors.dark_blue }]}>
          <Text style={styles.lblBtn}>Pending</Text>
        </TouchableOpacity> */}
      </View>
    </View>
  );
};

// define your styles
const styles = StyleSheet.create({
  container: {
    backgroundColor: "white",
    marginBottom: 30,
    borderRadius: 15,
    shadowColor: "#000",
    shadowOffset: {
      width: 0,
      height: 2
    },
    shadowOpacity: 0.25,
    shadowRadius: 3.84,
    elevation: 6,
    width: screen.width * 0.9
  },
  header: {
    flexDirection: "row",
    backgroundColor: colors.another_blue,
    marginBottom: 16,
    height: 60,
    borderRadius: 15,
    alignItems: "center"
  },
  data_content: {
    height: "100%",
    paddingTop: 16,
    paddingHorizontal: 32
  },
  icons_content: {
    width: "15%",
    height: "100%",
    justifyContent: "space-evenly",
    alignItems: "center"
  },
  lbl: {
    fontFamily: "OpenSans-Regular",
    color: colors.another_blue,
    fontSize: 16,
    lineHeight: 16,
    width: "45%"
  },
  edit: {
    width: 0.35 * screen.width,
    height: 40,
    backgroundColor: colors.dark_blue,
    borderTopLeftRadius: 20,
    borderBottomLeftRadius: 20,
    alignItems: "center",
    justifyContent: "center"
  },
  delete: {
    width: 0.35 * screen.width,
    height: 40,
    backgroundColor: "red",
    borderTopRightRadius: 20,
    borderBottomRightRadius: 20,
    alignItems: "center",
    justifyContent: "center"
  },
  lblEditDelete: {
    fontFamily: "OpenSans-Regular",
    color: "white"
  },
  notChosen: {
    width: 0.8 * screen.width,
    height: 40,
    backgroundColor: "#DEC714",
    borderRadius: 75,
    alignItems: "center",
    justifyContent: "center"
  },
  lblBtn: {
    fontFamily: "OpenSans-Bold",
    fontSize: 0.035 * screen.height,
    color: "white"
  }
});

//make this component available to the app
export default index;
