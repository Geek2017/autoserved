//import liraries
import React, { useState } from "react";
import { View, Text, StyleSheet, Image } from "react-native";
import { screen, colors, icons, buttonStyle } from "../../../../../constant";
import { TouchableOpacity } from "react-native-gesture-handler";
import moment from "moment";
import _ from "lodash";
import { inject, observer } from "mobx-react";
import { Modal } from "../../..";

function thousands_separators(num) {
  var num_parts = num.toString().split(".");
  num_parts[0] = num_parts[0].replace(/\B(?=(\d{3})+(?!\d))/g, ",");
  return num_parts.join(".");
}
// create a component
const index = ({
  arrData,
  onPressQuote,
  onPressDecline,
  status,
  priceData,
  store
}) => {
  const [isModal, setModalShow] = useState(false);

  let arrDateLetter = ["1st", "2nd", "3rd"];

  let jsonReplacement = {};
  const pricingCheck = priceData ? priceData : [];
  pricingCheck.map((item) => {
    jsonReplacement["Engine Oil"] = item.engineoil ? item.engineoil : 0;
    jsonReplacement["Oil Filter"] = item.oilfilter ? item.oilfilter : 0;
    jsonReplacement["Flushing"] = item.flushing ? item.flushing : 0;
    jsonReplacement["Air Filter"] = item.airfilter ? item.airfilter : 0;
    jsonReplacement["Spark plugs"] = item.sparkplug ? item.sparkplug : 0;
    jsonReplacement["Cabin Filter"] = item.cabinfilter ? item.cabinfilter : 0;
    jsonReplacement["Coolant"] = item.coolant ? item.coolant : 0;
    jsonReplacement["Brake Fluid"] = item.breakfluid ? item.breakfluid : 0;
    jsonReplacement["Power Steering Fluid"] = item.psf ? item.psf : 0;
    jsonReplacement["Brake Cleaner"] = item.bsf ? item.bsf : 0;
    jsonReplacement["Labor"] = item.labor ? item.labor : 0;
  });

  const priceConvertToInt = _.filter(jsonReplacement, (v) => v != 0);
  const priceConvertToIntWithoutLabor = _.filter(
    jsonReplacement,
    (v, k) => v != 0 && k != "Labor"
  );

  const grandTotal = _.sumBy(_.map(priceConvertToInt, _.parseInt));
  const materialTotal = _.sumBy(
    _.map(priceConvertToIntWithoutLabor, _.parseInt)
  );

  const labor = jsonReplacement.Labor;

  const jsonData = _.pickBy(
    jsonReplacement,
    (value, key) => value != 0 && key != "Labor"
  );

  const arrParts = Object.entries(jsonData).map(([key, value]) => ({
    key,
    value: jsonData[key]
  }));

  let sqrArr = arrData.sqr_by.split(",").indexOf(store.profile.mobileno);
  let index_sqr_state = arrData.sqr_state.split(",")[sqrArr];

  return (
    <View style={styles.container}>
      <Modal
        modalShow={isModal}
        title="BOOKED APPOINTMENT"
        btnTitle="confirm"
        setModalShow={setModalShow}
        content="Are you sure you want to proceed ?"
        handle={onPressQuote}
      />
      <View
        style={{
          justifyContent: "center",
          alignItems: "center",
          flexDirection: "row"
        }}>
        <View style={styles.data_content}>
          {/* ID */}
          <Text
            style={[
              styles.lbl,
              {
                width: "100%",
                fontSize: 0.014 * screen.height
              }
            ]}>
            {arrData.id}
          </Text>
          <View style={{ flexDirection: "row" }}>
            <Text style={styles.lbl}>Plate Number : </Text>
            <Text style={styles.lbl}>
              {thousands_separators(arrData.plateno)}
            </Text>
          </View>
          {index_sqr_state != 5 ? (
            <View>
              <View style={{ flexDirection: "row" }}>
                <Text style={styles.lbl}>Year Model : </Text>
                <Text style={styles.lbl}>{arrData.yrmodel}</Text>
              </View>

              <View style={{ flexDirection: "row" }}>
                <Text style={styles.lbl}>Make : </Text>
                <Text style={styles.lbl}>{arrData.make}</Text>
              </View>

              <View style={{ flexDirection: "row" }}>
                <Text style={styles.lbl}>Model : </Text>
                <Text style={styles.lbl}>{arrData.model}</Text>
              </View>
              <View style={{ flexDirection: "row" }}>
                <Text style={styles.lbl}>Engine : </Text>
                <Text style={styles.lbl}>{arrData.engine}</Text>
              </View>
              <View style={{ flexDirection: "row" }}>
                <Text style={styles.lbl}>Transmission :</Text>
                <Text style={styles.lbl}>{arrData.transmission}</Text>
              </View>
              <View style={{ flexDirection: "row" }}>
                <Text style={styles.lbl}>DOP : </Text>
                <Text style={styles.lbl}>{arrData.purchasedate}</Text>
              </View>
              <View style={{ flexDirection: "row" }}>
                <Text style={styles.lbl}>CurrentMileage: </Text>
                <Text style={styles.lbl}>
                  {thousands_separators(arrData.mileage)} KM
                </Text>
              </View>
            </View>
          ) : (
            <View />
          )}

          {/* Second Page */}
          <View
            style={{ flexDirection: "row", paddingTop: 20, flexWrap: "wrap" }}>
            <Text style={styles.lbl}>DATE OF APPOINTMENT: </Text>
            <Text style={styles.lbl2}>{arrData.requestdate}</Text>
            {index_sqr_state != 5 ? (
              <Text style={styles.lbl}>LABOR</Text>
            ) : (
              <View />
            )}
            {index_sqr_state != 5 ? (
              <Text style={styles.lbl}>{arrData.pms} PMS</Text>
            ) : (
              <View />
            )}
            <Text style={styles.lbl}>TOTAL LABOR: </Text>
            <Text style={styles.lbl2}>PHP. {labor}</Text>
          </View>
          {index_sqr_state != 5 ? (
            <View>
              <View style={{ paddingTop: 20 }}>
                <Text style={[styles.lbl, { width: "100%" }]}>
                  PARTS & MATERIALS:{" "}
                </Text>
              </View>
              {arrParts.map((item) => (
                <View style={{ flexDirection: "row" }}>
                  <Text style={styles.lbl}>{item.key}: </Text>
                  <Text style={styles.lbl2}>PHP: {item.value}</Text>
                </View>
              ))}
            </View>
          ) : (
            <View />
          )}
          <View style={{ flexDirection: "row" }}>
            <Text style={styles.lbl}>TOTAL PARTS & MATERIALS: </Text>
            <Text style={styles.lbl2}>PHP: {materialTotal} </Text>
          </View>
          <View style={{ flexDirection: "row", paddingTop: 20 }}>
            <Text style={styles.lbl}>GRAND TOTAL: </Text>
            <Text style={styles.lbl2}>PHP: {grandTotal} </Text>
          </View>
          <View style={{ paddingTop: 20 }}>
            <Text style={[styles.lbl, { width: "100%" }]}>
              PREFERRED SCHEDULE:{" "}
            </Text>
            <Text style={[styles.lbl, { width: "100%" }]}>
              {arrData.preferedschedules.split(",").map((item, index) => {
                return `${arrDateLetter[index]} ${moment(item).format(
                  "MMMM DD, YYYY"
                )} ${"\n"}`;
              })}
            </Text>
          </View>
        </View>
      </View>
      {/* Buttons */}
      {index_sqr_state == 3 ? (
        <View
          style={{
            zIndex: 20,
            flexDirection: "row",
            justifyContent: "center",
            top: 20,
            width: "100%"
          }}>
          <TouchableOpacity
            style={buttonStyle.btn.btnTwoEdit}
            onPress={() => setModalShow(true)}>
            <Text style={styles.lblEditDelete}>Confirm</Text>
          </TouchableOpacity>
          <TouchableOpacity style={styles.delete} onPress={onPressDecline}>
            <Text style={styles.lblEditDelete}>Reschedule</Text>
          </TouchableOpacity>
        </View>
      ) : index_sqr_state == 4 ? (
        <View>
          <TouchableOpacity
            style={[
              buttonStyle.btn.btnDarkBlue,
              {
                top: 20,
                alignSelf: "center"
              }
            ]}>
            <Text style={[buttonStyle.btn.lblBtnDarkBlue, { fontSize: 14 }]}>
              APPOINTMENT HAS BEEN RESCHEDULE
            </Text>
          </TouchableOpacity>
        </View>
      ) : (
        <View>
          {/* <TouchableOpacity
            style={[
              buttonStyle.btn.btnDarkBlue,
              {
                top: 20,
                alignSelf: "center",
                backgroundColor: "#B2BFDB"
              }
            ]}>
            <Text style={[buttonStyle.btn.lblBtnDarkBlue]}>CONFIRMED</Text>
          </TouchableOpacity> */}
        </View>
      )}
    </View>
  );
};

// define your styles
const styles = StyleSheet.create({
  container: {
    width: 0.9 * screen.width,
    backgroundColor: "white",
    marginBottom: 30,
    marginHorizontal: 16,
    borderRadius: 15,
    shadowColor: "#000",
    shadowOffset: {
      width: 0,
      height: 2
    },
    shadowOpacity: 0.25,
    shadowRadius: 3.84,
    elevation: 5
  },
  data_content: {
    width: "85%",
    height: "100%",
    paddingLeft: 20,
    paddingTop: 20,
    paddingRight: 10
  },
  icons_content: {
    width: "15%",
    height: "100%",
    justifyContent: "space-evenly",
    alignItems: "center"
  },
  lbl: {
    fontFamily: "OpenSans-Regular",
    color: colors.font_text_color,
    fontSize: 14,
    width: "60%",
    lineHeight: 20
  },
  lbl2: {
    fontFamily: "OpenSans-Regular",
    color: colors.font_text_color,
    fontSize: 14,
    width: "40%"
  },
  edit: {
    width: 0.35 * screen.width,
    height: 40,
    backgroundColor: colors.dark_blue,
    borderTopLeftRadius: 20,
    borderBottomLeftRadius: 20,
    alignItems: "center",
    justifyContent: "center"
  },
  delete: {
    width: 0.35 * screen.width,
    height: 40,
    backgroundColor: "red",
    borderTopRightRadius: 20,
    borderBottomRightRadius: 20,
    alignItems: "center",
    justifyContent: "center"
  },
  lblEditDelete: {
    fontFamily: "OpenSans-Regular",
    color: "white"
  },
  notChosen: {
    width: 0.8 * screen.width,
    height: 40,
    backgroundColor: "#DEC714",
    borderRadius: 75,
    alignItems: "center",
    justifyContent: "center"
  },
  lblBtn: {
    fontFamily: "OpenSans-Bold",
    fontSize: 0.035 * screen.height,
    color: "white"
  }
});

//make this component available to the app
export default inject("store")(observer(index));
