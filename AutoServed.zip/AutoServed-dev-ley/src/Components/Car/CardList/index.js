//import liraries
import React, { Component } from "react";
import { View, Text, StyleSheet, Image } from "react-native";
import { screen, colors, icons } from "../../../../constant";
import { TouchableOpacity } from "react-native-gesture-handler";
import buttonStyle from "../../../../constant/buttonStyle";
function thousands_separators(num) {
  var num_parts = num.toString().split(".");
  num_parts[0] = num_parts[0].replace(/\B(?=(\d{3})+(?!\d))/g, ",");
  return num_parts.join(".");
}
// create a component
const index = ({ arrData, navHandleEdit, navHandleDelete }) => {
  return (
    <View style={styles.container}>
      <View
        style={{
          justifyContent: "center",
          alignItems: "center",
          flexDirection: "row"
        }}>
        <View style={styles.data_content}>
          <View style={{ flexDirection: "row" }}>
            <Text style={styles.lbl}>Plate Number : </Text>
            <Text style={styles.lbl}>
              {thousands_separators(arrData.plateno)}
            </Text>
          </View>
          <View style={{ flexDirection: "row" }}>
            <Text style={styles.lbl}>Year Model : </Text>
            <Text style={styles.lbl}>{arrData.year}</Text>
          </View>

          <View style={{ flexDirection: "row" }}>
            <Text style={styles.lbl}>Make : </Text>
            <Text style={styles.lbl}>{arrData.make}</Text>
          </View>

          <View style={{ flexDirection: "row" }}>
            <Text style={styles.lbl}>Model : </Text>
            <Text style={styles.lbl}>{arrData.model}</Text>
          </View>
          <View style={{ flexDirection: "row" }}>
            <Text style={styles.lbl}>Engine : </Text>
            <Text style={styles.lbl}>{arrData.engine}</Text>
          </View>
          <View style={{ flexDirection: "row" }}>
            <Text style={styles.lbl}>Transmission :</Text>
            <Text style={styles.lbl}>{arrData.transmission}</Text>
          </View>
          <View style={{ flexDirection: "row" }}>
            <Text style={styles.lbl}>DOP : </Text>
            <Text style={styles.lbl}>{arrData.purchasedate}</Text>
          </View>
          <View style={{ flexDirection: "row" }}>
            <Text style={styles.lbl}>CurrentMileage: </Text>
            <Text style={styles.lbl}>
              {thousands_separators(arrData.mileage)} KM
            </Text>
          </View>
        </View>
        {/* Icons */}
        <View style={styles.icons_content}>
          <Image source={icons.calendar} />
          <Image source={icons.car_def} />
          <Image source={icons.history} />
        </View>
      </View>
      {/* Buttons */}
      <View
        style={{ flexDirection: "row", justifyContent: "center", top: -20 }}>
        <TouchableOpacity
          style={buttonStyle.btn.btnTwoEdit}
          onPress={navHandleEdit}>
          <Text style={buttonStyle.btn.lblTwoBtn}>EDIT</Text>
        </TouchableOpacity>
        <TouchableOpacity
          style={buttonStyle.btn.btnTwoDelete}
          onPress={navHandleDelete}>
          <Text style={buttonStyle.btn.lblTwoBtn}>DELETE</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
};

// define your styles
const styles = StyleSheet.create({
  container: {
    width: 0.8 * screen.width,
    height: 250,
    backgroundColor: colors.blue_backgroud_secondary,
    marginBottom: 30,
    borderRadius: 15,
    shadowColor: "#000",
    shadowOffset: {
      width: 0,
      height: 2
    },
    shadowOpacity: 0.25,
    shadowRadius: 3.84,
    elevation: 5
  },
  data_content: {
    width: "85%",
    height: "100%",
    paddingLeft: 20,
    top: -10,
    // paddingTop: 20,
    paddingRight: 10,
    justifyContent: "center"
  },
  icons_content: {
    width: "15%",
    height: "100%",
    justifyContent: "space-evenly",
    alignItems: "center"
  },
  lbl: {
    fontFamily: "OpenSans-Regular",
    color: "white",
    fontSize: 16,
    width: "60%"
  },
  edit: {
    width: 0.35 * screen.width,
    height: 40,
    backgroundColor: colors.dark_blue,
    borderTopLeftRadius: 20,
    borderBottomLeftRadius: 20,
    alignItems: "center",
    justifyContent: "center"
  },
  delete: {
    width: 0.35 * screen.width,
    height: 40,
    backgroundColor: "red",
    borderTopRightRadius: 20,
    borderBottomRightRadius: 20,
    alignItems: "center",
    justifyContent: "center"
  },
  lblEditDelete: {
    fontFamily: "OpenSans-Regular",
    color: "white"
  }
});

//make this component available to the app
export default index;
