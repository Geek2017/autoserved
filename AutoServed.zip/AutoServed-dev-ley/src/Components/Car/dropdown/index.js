//import liraries
import React, { Component } from "react";
import { View, Text, StyleSheet } from "react-native";
import { screen, colors } from "../../../../constant";
import DropDownPicker from "react-native-dropdown-picker";
// create a component
const index = ({ item, setData, placeholder, zIndex, value }) => {
  //   const [default, setDefault] = useState("");
  return (
    <DropDownPicker
      defaultValue={value}
      zIndex={zIndex}
      items={item}
      //   defaultValue={this.state.country}
      containerStyle={{
        height: 40,
        width: 0.8 * screen.width,
        margin: 10
      }}
      style={{
        backgroundColor: "#fafafa",
        borderTopLeftRadius: 10,
        borderTopRightRadius: 10,
        borderBottomLeftRadius: 10,
        borderBottomRightRadius: 10
      }}
      placeholder={placeholder}
      itemStyle={{
        justifyContent: "flex-start"
      }}
      labelStyle={{
        textAlign: "left",
        color: colors.blue_backgroud
      }}
      dropDownStyle={{
        backgroundColor: "#fafafa",
        borderBottomLeftRadius: 20,
        borderBottomRightRadius: 20
      }}
      onChangeItem={setData}
    />
  );
};

// define your styles
const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    backgroundColor: "#2c3e50"
  }
});

//make this component available to the app
export default index;
