import React, { useState, useEffect } from "react";
import {
  View,
  Text,
  StyleSheet,
  Dimensions,
  TouchableOpacity
} from "react-native";
import Modal from "react-native-modal";
import { colors, screen } from "../../../constant";
import { ListItem, Icon } from "react-native-elements";
import DatePicker from "react-native-date-picker";
import moment from "moment";
import { inject, observer } from "mobx-react";
import { ScrollView } from "react-native";
const index = ({ modalShow, setModalShow, handle, cancelHide, store }) => {
  const [timeAm, setTimeAm] = useState(new Date(2021, 0, 1, 7, 30, 0, 0));
  const [timePm, setTimePm] = useState(new Date(2021, 0, 1, 21, 30, 0, 0));
  const [check, setCheck] = useState([
    false,
    false,
    false,
    false,
    false,
    false,
    false
  ]);

  const list = [
    {
      title: "Monday ",
      icon: "schedule"
    },
    {
      title: "Tuesday",
      icon: "schedule"
    },
    {
      title: "Wednesday",
      icon: "schedule"
    },
    {
      title: "Thursday",
      icon: "schedule"
    },
    {
      title: "Friday",
      icon: "schedule"
    },
    {
      title: "Saturday",
      icon: "schedule"
    },
    {
      title: "Sunday",
      icon: "schedule"
    }
  ];

  useEffect(() => {
    store.shops.operationhrs = [];
    store.shops.daysopen = [];
  }, []);

  const checkHandler = (index) => {
    const arr = [...check];
    var arrDays = store.shops.daysopen ? store.shops.daysopen : [];
    arr[index] = !arr[index];
    setCheck(arr);
    if (arr[index]) {
      if (store.shops.daysopen.indexOf(list[index].title) !== -1) {
        // alert("Value exists!");
      } else {
        store.shops.daysopen = [...arrDays, list[index].title];
      }
    } else {
      var filtered = store.shops.daysopen.filter(
        (item) => item !== list[index].title
      );
      store.shops.daysopen = filtered;
    }
  };

  const submitHandler = () => {
    store.shops.daysopen = store.shops["daysopen"].toString();
    store.shops.operationhrs = [
      moment(timeAm).format("hh:mm A"),
      moment(timePm).format("hh:mm A")
    ].toString();
  };

  return (
    <View>
      <Modal
        animationIn="bounceInUp"
        style={{ backgroundColor: "transparent" }}
        isVisible={modalShow}>
        <ScrollView
          style={styles.container}
          contentContainerStyle={{
            alignItems: "center",
            justifyContent: "center"
          }}>
          <View style={styles.card}>
            <TouchableOpacity
              style={{ paddingTop: 8, paddingHorizontal: 10 }}
              onPress={() => setModalShow(false)}>
              <Icon
                name="close"
                size={30}
                style={{ alignSelf: "flex-start" }}
              />
            </TouchableOpacity>
            {list.map((item, i) => (
              <ListItem key={i} bottomDivider>
                <ListItem.Content>
                  <ListItem.CheckBox
                    title={item.title}
                    checked={check[i]}
                    onIconPress={() => checkHandler(i)}
                  />
                </ListItem.Content>
                <ListItem.Chevron />
              </ListItem>
            ))}

            {/* Time Picker */}
            <View style={styles.timeContainer}>
              {/* <Text>Pick the Time for business hours</Text>
              <Text>Selected Time: {time}</Text> */}
              <Text
                style={{
                  fontFamily: "OpenSans-Bold",
                  fontSize: 0.02 * screen.height
                }}>
                From :
              </Text>
              <DatePicker
                style={{ height: 0.07 * screen.height }}
                mode="time"
                date={timeAm}
                onDateChange={(time) => {
                  setTimeAm(time);
                }}
              />
              <Text
                style={{
                  fontFamily: "OpenSans-Bold",
                  fontSize: 0.02 * screen.height
                }}>
                To :
              </Text>
              <DatePicker
                style={{ height: 0.07 * screen.height }}
                mode="time"
                date={timePm}
                onDateChange={(time) => {
                  setTimePm(time);
                }}
              />
              <TouchableOpacity
                onPress={() => {
                  submitHandler(), setModalShow(false);
                }}
                style={{
                  backgroundColor: colors.dark_blue,
                  width: "80%",
                  height: 40,
                  borderRadius: 20,
                  alignItems: "center",
                  alignSelf: "center",
                  justifyContent: "center",
                  marginTop: 0.02 * screen.height
                }}>
                <Text style={{ fontFamily: "OpenSans-Bold", color: "white" }}>
                  SUBMIT
                </Text>
              </TouchableOpacity>
            </View>
            {/* End */}
          </View>
        </ScrollView>
      </Modal>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    width: "100%"
  },
  timeContainer: {
    backgroundColor: "white",
    padding: 10
  },
  card: {
    backgroundColor: "white",
    borderRadius: 15,
    width: "100%",
    shadowColor: "#000",
    shadowOffset: {
      width: 0,
      height: 1
    },
    shadowOpacity: 0.22,
    shadowRadius: 2.22,
    elevation: 3,
    padding: 10
  }
});
export default inject("store")(observer(index));
