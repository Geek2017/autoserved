//import liraries
import React, { Component } from "react";
import { View, Text, StyleSheet, TextInput } from "react-native";
import { screen, colors } from "../../../../constant";
import FeatherIcon from "react-native-vector-icons/FontAwesome5";
// create a component
const index = ({ setMobileNumber }) => {
  return (
    <View
      style={{
        flexDirection: "row",
        flexWrap: "wrap",
        justifyContent: "space-around"
      }}>
      <TextInput
        style={styles.inputStyle}
        placeholder="Locate Shopes Near me"
        placeholderTextColor={colors.font_text_color}
        keyboardType="number-pad"
        // onChangeText={(num) => setMobileNumber(num)}
      />
      <View
        style={{
          justifyContent: "center",
          zIndex: 10,
          flexDirection: "row",
          position: "absolute",
          width: 0.2 * screen.width,
          right: 0,
          top: 0
        }}>
        <View style={styles.verticalLine}></View>
        <View style={styles.iconStyle}>
          <FeatherIcon
            name="search-location"
            color={colors.blue_backgroud_secondary}
            size={30}
          />
        </View>
      </View>
    </View>
  );
};

// define your styles
const styles = StyleSheet.create({
  inputStyle: {
    backgroundColor: "white",
    paddingLeft: 30,
    width: 0.85 * screen.width,
    height: 50,
    borderRadius: 70,
    fontSize: 0.02 * screen.height,
    color: colors.font_text_color
  },
  iconStyle: {
    alignItems: "center",
    justifyContent: "center",
    marginLeft: 20
  },
  verticalLine: {
    height: 50,
    width: 2,
    backgroundColor: colors.font_text_color
  }
});

//make this component available to the app
export default index;
