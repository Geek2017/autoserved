//import liraries
import React, { Component } from "react";
import { View, Text, StyleSheet, TextInput } from "react-native";
import { screen, colors } from "../../../../constant";
// create a component
const index = ({ placeholder, isNumberPad, setData, defaultValue }) => {
  let keyboardType = isNumberPad ? "number-pad" : "default";
  return (
    <TextInput
      defaultValue={defaultValue}
      style={styles.inputStyle}
      placeholder={placeholder}
      placeholderTextColor={colors.font_text_color}
      keyboardType={keyboardType}
      onChangeText={(num) => setData(num)}
    />
  );
};

// define your styles
const styles = StyleSheet.create({
  inputStyle: {
    backgroundColor: "#fafafa",
    borderRadius: 10,
    height: 40,
    width: 0.8 * screen.width,
    margin: 10,
    alignItems: "flex-start",
    justifyContent: "center",
    paddingLeft: 20,
    paddingRight: 20
  }
});

//make this component available to the app
export default index;
