//import liraries
import React, { useRef, useEffect } from "react";
import { View, Text, StyleSheet, TextInput } from "react-native";
import { screen, colors } from "../../../../constant";
import { GooglePlacesAutocomplete } from "react-native-google-places-autocomplete";

// create a component
const index = ({ setData, defaultValue, onPress, onKeyboardShouldPersist }) => {
  const ref = useRef();
  useEffect(() => {
    ref.current?.setAddressText(defaultValue ? defaultValue : "");
  }, []);
  return (
    <GooglePlacesAutocomplete
      ref={ref}
      styles={{
        container: {
          width: 0.85 * screen.width
        },
        textInput: {
          paddingLeft: 20,
          paddingRight: 20,
          height: 40,
          width: 0.8 * screen.width,
          margin: 10,
          borderRadius: 10
        }
      }}
      textInputProps={{
        onChangeText: (text) => {
          console.log(text);
        }
      }}
      //   onChangeText={setData}
      placeholder="Car Location"
      //   fetchDetails={true}
      //   listViewDisplayed={false}
      onPress={(data, details = null) => {
        onPress(data.description);
        // onKeyboardShouldPersist(true);
        console.log(data.description);
      }}
      onFail={(error) => console.error(error)}
      query={{
        key: "AIzaSyAuYmZ6xFjgvREwx9az-NPrlglHgDIPkN0",
        language: "en",
        components: "country:PH"
      }}
    />
  );
};

// define your styles
const styles = StyleSheet.create({
  container: {
    backgroundColor: "#fafafa",
    borderRadius: 10,
    height: 40,
    width: 0.8 * screen.width,
    margin: 10,
    alignItems: "flex-start",
    justifyContent: "center",
    paddingLeft: 20,
    paddingRight: 20
  }
});

//make this component available to the app
export default index;
