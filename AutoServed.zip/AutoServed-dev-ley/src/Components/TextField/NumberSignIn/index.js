//import liraries
import React, { Component } from "react";
import { View, Text, StyleSheet, TextInput } from "react-native";
import { screen, colors } from "../../../../constant";
import TextInputMask from "react-native-text-input-mask";
// create a component
const index = ({ setMobileNumber }) => {
  return (
    <View>
      <View
        style={{
          justifyContent: "center",
          position: "absolute",
          zIndex: 10,
          flexDirection: "row",
          alignItems: "center"
        }}>
        <Text style={styles.lbl}>+63</Text>
        <View style={styles.verticalLine}></View>
      </View>
      <TextInputMask
        style={styles.inputStyle}
        placeholder="9-11-111-1111"
        placeholderTextColor={colors.font_text_color}
        keyboardType="number-pad"
        refInput={(ref) => {
          this.input = ref;
        }}
        onChangeText={(formatted, extracted) => {
          // console.log(formatted); // +1 (123) 456-78-90
          // console.log(extracted); // 1234567890
          setMobileNumber(extracted);
        }}
        mask={"([0]) [00] [000] [0000]"}
      />
    </View>
  );
};

// define your styles
const styles = StyleSheet.create({
  inputStyle: {
    backgroundColor: "white",
    paddingLeft: 100,
    width: 0.85 * screen.width,
    height: 50,
    borderRadius: 70,
    fontSize: 18,
    color: colors.font_text_color
  },
  lbl: {
    fontFamily: "OpenSans-Regular",
    fontSize: 18,
    color: colors.font_text_color,
    marginLeft: 20
  },
  verticalLine: {
    height: 50,
    width: 2,
    backgroundColor: colors.font_text_color,
    marginLeft: 35
  }
});

//make this component available to the app
export default index;
