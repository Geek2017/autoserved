//import liraries
import React, { Component } from "react";
import { View, Text, StyleSheet, TextInput } from "react-native";
import { screen, colors } from "../../../../constant";
// create a component
const index = ({ setMobileNumber }) => {
  return (
    <View>
      <View
        style={{
          justifyContent: "center",
          position: "absolute",
          zIndex: 10,
          flexDirection: "row",
          alignItems: "center"
        }}>
        <Text style={styles.lbl}>+63</Text>
        <View style={styles.verticalLine}></View>
      </View>
      <TextInput
        style={styles.inputStyle}
        placeholder="9-11-111-111"
        placeholderTextColor={colors.font_text_color}
        keyboardType="number-pad"
        onChangeText={(num) => setMobileNumber(num)}
      />
    </View>
  );
};

// define your styles
const styles = StyleSheet.create({
  inputStyle: {
    backgroundColor: "white",
    paddingLeft: 100,
    width: 0.85 * screen.width,
    height: 50,
    borderRadius: 70,
    fontSize: 18,
    color: colors.font_text_color
  },
  lbl: {
    fontFamily: "OpenSans-Regular",
    fontSize: 18,
    color: colors.font_text_color,
    marginLeft: 20
  },
  verticalLine: {
    height: 52,
    width: 2,
    backgroundColor: colors.font_text_color,
    marginLeft: 35
  }
});

//make this component available to the app
export default index;
