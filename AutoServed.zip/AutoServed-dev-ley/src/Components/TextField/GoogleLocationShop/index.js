//import liraries
import React, { Component } from "react";
import { View, Text, StyleSheet, TextInput } from "react-native";
import { screen, colors } from "../../../../constant";
import { GooglePlacesAutocomplete } from "react-native-google-places-autocomplete";
import { color } from "react-native-reanimated";

// create a component
const index = ({ setData, defaultValue, onPress, onKeyboardShouldPersist }) => {
  return (
    <GooglePlacesAutocomplete
      //   defaultValue={defaultValue}
      //   style={styles.container}
      styles={{
        container: {
          width: 0.85 * screen.width
        },
        textInput: {
          paddingLeft: 20,
          paddingRight: 20,
          borderRadius: 70,
          width: 0.85 * screen.width,
          height: 50,
          marginBottom: 20,
          color: colors.font_text_color
        }
      }}
      //   onChangeText={setData}
      placeholder="Map Location"
      //   fetchDetails={true}
      //   listViewDisplayed={false}
      onPress={(data, details = null) => {
        onPress(data.description);
        // onKeyboardShouldPersist(true);
        console.log(data.description);
      }}
      onFail={(error) => console.error(error)}
      query={{
        key: "AIzaSyAuYmZ6xFjgvREwx9az-NPrlglHgDIPkN0",
        language: "en",
        components: "country:PH"
      }}
    />
  );
};

// define your styles
const styles = StyleSheet.create({
  container: {
    backgroundColor: "#fafafa",
    borderRadius: 70,
    height: 50,
    alignItems: "flex-start",
    justifyContent: "center",
    paddingLeft: 20,
    paddingRight: 20
  }
});

//make this component available to the app
export default index;
