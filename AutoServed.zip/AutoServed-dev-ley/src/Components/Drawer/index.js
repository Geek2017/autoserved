import React, { useState } from "react";
import { View, StyleSheet, Linking } from "react-native";
import { DrawerItem, DrawerContentScrollView } from "@react-navigation/drawer";
import {
  useTheme,
  Avatar,
  Title,
  Caption,
  Paragraph,
  Drawer,
  Text,
  TouchableRipple,
  Switch
} from "react-native-paper";
import MaterialCommunityIcons from "react-native-vector-icons/MaterialCommunityIcons";
import { colors, icons } from "../../../constant";
import { Modal } from "../../Components";
import { inject, observer } from "mobx-react";
import { CommonActions } from "@react-navigation/native";

const DrawerContent = ({ props, store, navigation }) => {
  const [isModal, setModalShow] = useState(false);
  const Logout = () => {
    navigation.dispatch(
      CommonActions.navigate({
        name: "SignInScreen"
      })
    );
    store.logout();
    setModalShow(false);
  };

  const feedBack = async () => {
    await Linking.openURL("https://m.me/autoserved");
  };

  return (
    <DrawerContentScrollView {...props}>
      <Modal
        modalShow={isModal}
        title="Logout"
        btnTitle="proceed"
        setModalShow={setModalShow}
        content="Are you sure you want to logout ?"
        handle={() => Logout()}
      />
      <View style={styles.drawerContent}>
        <View style={styles.userInfoSection}>
          <Avatar.Image
            source={
              store.profile.usertype == "individual"
                ? icons.party_pop
                : { uri: store.shops.logo ?? null }
            }
            size={50}
          />
          <Title style={styles.title}>
            {store.profile.usertype == "individual"
              ? store.profile.fullname
              : store.shops.shop_name ?? ""}
          </Title>
          <Caption style={[styles.caption, { fontSize: 14 }]}>
            @{store.profile.usertype}
          </Caption>
          <View style={styles.row}>
            <View style={styles.section}>
              <Paragraph style={[styles.paragraph, styles.caption]}>
                {store.profile.balance ? store.profile.balance : 0}
              </Paragraph>
              <Caption style={styles.caption}>Balance</Caption>
              <View
                style={{
                  borderWidth: 1,
                  height: 18,
                  marginLeft: 8,
                  borderColor: "gainsboro"
                }}></View>
            </View>
            <View style={styles.section}>
              <Paragraph style={[styles.paragraph, styles.caption]}>
                {store.profile.points ? store.profile.points : 0}
              </Paragraph>
              <Caption style={styles.caption}>Points</Caption>
              <View
                style={{
                  borderWidth: 1,
                  height: 18,
                  marginLeft: 8,
                  borderColor: "gainsboro"
                }}></View>
            </View>
            <View style={styles.section}>
              <Paragraph style={[styles.paragraph, styles.caption]}>
                0
              </Paragraph>
              <Caption style={styles.caption}>Credits</Caption>
            </View>
          </View>
        </View>
        <Drawer.Section style={styles.drawerSection}>
          <DrawerItem
            icon={({ color, size }) => (
              <MaterialCommunityIcons
                name="account-outline"
                color={color}
                size={size}
              />
            )}
            label="Profile"
            onPress={() => {}}
          />
          <DrawerItem
            icon={({ color, size }) => (
              <MaterialCommunityIcons
                name={
                  store.profile.usertype == "individual"
                    ? "history"
                    : "credit-card"
                }
                color={color}
                size={size}
              />
            )}
            label={
              store.profile.usertype == "individual"
                ? "Repair History"
                : "Apply For Credits"
            }
            onPress={() => {}}
          />
          <DrawerItem
            icon={({ color, size }) => (
              <MaterialCommunityIcons name="tune" color={color} size={size} />
            )}
            label="Preferences"
            onPress={() => {}}
          />
          {store.profile.usertype == "individual" ? (
            <View>
              <DrawerItem
                icon={({ color, size }) => (
                  <MaterialCommunityIcons
                    name="star"
                    color={color}
                    size={size}
                  />
                )}
                label="Favourite Shops"
                onPress={() => {}}
              />
              <DrawerItem
                icon={({ color, size }) => (
                  <MaterialCommunityIcons
                    name="account-group"
                    color={color}
                    size={size}
                  />
                )}
                label="Refer Friends"
                onPress={() => {}}
              />
              <DrawerItem
                icon={({ color, size }) => (
                  <MaterialCommunityIcons
                    name="credit-card"
                    color={color}
                    size={size}
                  />
                )}
                label="Apply For Credit"
                onPress={() => {}}
              />
              <DrawerItem
                icon={({ color, size }) => (
                  <MaterialCommunityIcons
                    name="rss"
                    color={color}
                    size={size}
                  />
                )}
                label="News Feed"
                onPress={() => {}}
              />
            </View>
          ) : (
            <View />
          )}
          <DrawerItem
            icon={({ color, size }) => (
              <MaterialCommunityIcons
                name="comment-quote"
                color={color}
                size={size}
              />
            )}
            label="Feed Back"
            onPress={() => feedBack()}
          />
          <DrawerItem
            icon={({ color, size }) => (
              <MaterialCommunityIcons
                name="face-agent"
                color={color}
                size={size}
              />
            )}
            label="Help"
            onPress={() => feedBack()}
          />
        </Drawer.Section>
        <Drawer.Section title="Preferences">
          <TouchableRipple onPress={() => setModalShow(true)}>
            <View style={styles.preference}>
              <Text>Logout</Text>
            </View>
          </TouchableRipple>
        </Drawer.Section>
      </View>
    </DrawerContentScrollView>
  );
};

const styles = StyleSheet.create({
  drawerContent: {
    flex: 1
  },
  userInfoSection: {
    paddingLeft: 20
  },
  title: {
    marginTop: 20,
    fontWeight: "bold"
  },
  caption: {
    fontSize: 11,
    lineHeight: 14
  },
  row: {
    marginTop: 20,
    flexDirection: "row",
    alignItems: "center"
  },
  section: {
    flexDirection: "row",
    alignItems: "center",
    marginRight: 15
  },
  paragraph: {
    fontWeight: "bold",
    marginRight: 2
  },
  drawerSection: {
    marginTop: 15
  },
  preference: {
    flexDirection: "row",
    justifyContent: "space-between",
    paddingVertical: 12,
    paddingHorizontal: 16
  }
});
export default inject("store")(observer(DrawerContent));
