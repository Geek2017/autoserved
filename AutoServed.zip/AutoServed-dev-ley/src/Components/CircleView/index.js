//import liraries
import React, { Component } from "react";
import { View, Text, StyleSheet, Image, TouchableOpacity } from "react-native";
import { colors, screen } from "../../../constant";
// create a component
const index = ({ imageSrc, title, isHide, handleNav }) => {
  return (
    <View>
      <TouchableOpacity
        onPress={handleNav}
        disabled={isHide}
        style={[styles.container, { opacity: isHide ? 0.4 : 1 }]}>
        <View
          style={{
            height: "50%",
            justifyContent: "center"
          }}>
          <Image
            style={{
              height: 0.06 * screen.height,
              width: 0.06 * screen.height,
              marginTop: 20
            }}
            source={imageSrc}
          />
        </View>
        <View style={{ height: "50%", justifyContent: "center" }}>
          <Text style={styles.lbl} adjustsFontSizeToFit>
            {title}
          </Text>
        </View>
      </TouchableOpacity>
      <Text
        style={{ color: "red", textAlign: "center", top: -25, fontSize: 12 }}>
        {isHide ? "soon" : ""}
      </Text>
    </View>
  );
};

// define your styles
const styles = StyleSheet.create({
  container: {
    height: 0.23 * screen.width,
    width: 0.23 * screen.width,
    alignItems: "center",
    backgroundColor: colors.blue_backgroud_secondary,
    borderRadius: 75,
    margin: 10
  },
  lbl: {
    fontFamily: "OpenSans-Regular",
    fontSize: 10,
    color: "white",
    width: 90,
    textAlign: "center",
    lineHeight: 10
  }
});

//make this component available to the app
export default index;
