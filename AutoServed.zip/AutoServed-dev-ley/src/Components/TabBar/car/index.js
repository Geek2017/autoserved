import React from "react";
import {
  View,
  Text,
  useWindowDimensions,
  TouchableOpacity,
  Image
} from "react-native";

import { colors, icons, screen } from "../../../../constant";
const iconsArr = [
  icons.car,
  icons.calendar2,
  // icons.history,
  icons.home,
  icons.deferred,
  icons.wallet
];

export default function TabBarCar({ state, descriptors, navigation }) {
  const focusedOptions = descriptors[state.routes[state.index].key].options;

  if (focusedOptions.tabBarVisible === false) {
    return null;
  }

  return (
    <View
      key={Math.random()}
      style={{
        position: "absolute",
        bottom: 0,
        padding: 10,
        width: screen.width,
        zIndex: 1,
        elevation: 3,
        flexDirection: "row",
        backgroundColor: "#E6F2FC",
        borderTopRightRadius: 16,
        borderTopLeftRadius: 16,
        justifyContent: "center",
        height: 72,
        alignItems: "center"
      }}>
      {state.routes.map((route, index) => {
        const { options } = descriptors[route.key];
        const label =
          options.tabBarLabel !== undefined
            ? options.tabBarLabel
            : options.title !== undefined
            ? options.title
            : route.name;

        const isFocused = state.index === index;

        const onPress = () => {
          const event = navigation.emit({
            type: "tabPress",
            target: route.key
          });

          if (!isFocused && !event.defaultPrevented) {
            navigation.navigate(route.name);
          }
        };

        const onLongPress = () => {
          navigation.emit({
            type: "tabLongPress",
            target: route.key
          });
        };

        return (
          <TouchableOpacity
            key={Math.random()}
            accessibilityRole="button"
            accessibilityState={isFocused ? { selected: true } : {}}
            accessibilityLabel={options.tabBarAccessibilityLabel}
            testID={options.tabBarTestID}
            // onPress={onPress}
            onPress={() => {
              if (label == "Home") {
                navigation.navigate("MyCarScreen");
                return;
              }
              if (label == "Deferred Repairs") {
                return null;
              }
              if (label == "Repair History") {
                return null;
              }
              if (label == "My Wallet") {
                return null;
              }
              navigation.navigate(label);
            }}
            style={{ flex: 1, alignItems: "center" }}>
            <View
              style={{
                height: "50%",
                alignItems: "center",
                justifyContent: "center"
              }}>
              <Image
                source={iconsArr[index]}
                style={{
                  width: label != "Home" ? 30 : 50,
                  height: label != "Home" ? 30 : 50,
                  marginTop: label != "Home" ? 0 : 20
                }}
              />
            </View>
            <View
              style={{
                height: "50%",
                alignItems: "center"
              }}>
              {label != "Home" ? (
                <Text
                  style={{
                    fontSize: 10,
                    color: colors.font_text_color,
                    textAlign: "center",
                    lineHeight: 10,
                    marginTop: screen.height * 0.01
                  }}>
                  {label}
                </Text>
              ) : (
                <View />
              )}
              {label == "Deferred Repairs" ? (
                <Text style={{ color: "red", lineHeight: 15 }}>soon</Text>
              ) : label == "My Wallet" ? (
                <Text style={{ color: "red", lineHeight: 15 }}>soon</Text>
              ) : (
                <View />
              )}
            </View>
          </TouchableOpacity>
        );
      })}
    </View>
  );
}
