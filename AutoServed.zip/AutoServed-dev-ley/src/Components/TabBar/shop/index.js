import React from "react";
import {
  View,
  Text,
  useWindowDimensions,
  TouchableOpacity,
  Image
} from "react-native";

import { colors, icons, screen } from "../../../../constant";
// import Icons from "react-native-vector-icons/FontAwesome5";
const iconsArr = [
  icons.myshop,
  icons.quatation,
  icons.home,
  icons.calendar2,
  icons.wallet
];
// const iconsArr = ["store", "concierge-bell", "home", "clipboard", "wallet"];
import { inject, observer } from "mobx-react";
const TabBarShop = ({ state, descriptors, navigation, store }) => {
  const focusedOptions = descriptors[state.routes[state.index].key].options;

  if (focusedOptions.tabBarVisible === false) {
    return null;
  }

  return (
    <View
      key={Math.random()}
      style={{
        position: "absolute",
        bottom: 0,
        padding: 10,
        width: screen.width,
        zIndex: 1,
        elevation: 3,
        flexDirection: "row",
        height: 72,
        backgroundColor: "#E6F2FC",
        borderTopRightRadius: 16,
        borderTopLeftRadius: 16,
        justifyContent: "center",
        alignItems: "center"
      }}>
      {state.routes.map((route, index) => {
        const { options } = descriptors[route.key];
        const label =
          options.tabBarLabel !== undefined
            ? options.tabBarLabel
            : options.title !== undefined
            ? options.title
            : route.name;

        const isFocused = state.index === index;

        const onPress = () => {
          const event = navigation.emit({
            type: "tabPress",
            target: route.key
          });

          if (!isFocused && !event.defaultPrevented) {
            navigation.navigate(route.name);
          }
        };

        const onLongPress = () => {
          navigation.emit({
            type: "tabLongPress",
            target: route.key
          });
        };

        return (
          <TouchableOpacity
            key={Math.random()}
            accessibilityRole="button"
            accessibilityState={isFocused ? { selected: true } : {}}
            accessibilityLabel={options.tabBarAccessibilityLabel}
            testID={options.tabBarTestID}
            // onPress={onPress}
            onPress={() => {
              if (label == "Home") {
                navigation.navigate("ShopScreen");
                return;
              }
              if (label == "Transaction History") {
                return null;
              }
              if (label == "My Wallet") {
                return null;
              }
              navigation.navigate(label);
            }}
            style={{ flex: 1, alignItems: "center" }}>
            <View
              style={{
                height: "50%",
                alignItems: "center",
                justifyContent: "center"
              }}>
              <Image
                source={iconsArr[index]}
                style={{
                  width: label != "Home" ? 30 : 50,
                  height: label != "Home" ? 30 : 50,
                  marginTop: label != "Home" ? 0 : 20
                }}
              />
            </View>
            {/* <Icons name={iconsArr[index]} size={30} color="#3A8ECC" /> */}

            <View
              style={{
                height: "50%",
                alignItems: "center"
              }}>
              {label != "Home" ? (
                <Text
                  style={{
                    fontSize: 10,
                    color: colors.font_text_color,
                    textAlign: "center",
                    lineHeight: 10,
                    marginTop: screen.width * 0.01
                  }}>
                  {label}
                </Text>
              ) : (
                <View />
              )}
              {label == "My Wallet" ? (
                <Text style={{ color: "red", lineHeight: 15 }}>soon</Text>
              ) : (
                <View />
              )}
            </View>
          </TouchableOpacity>
        );
      })}
    </View>
  );
};
export default inject("store")(observer(TabBarShop));
