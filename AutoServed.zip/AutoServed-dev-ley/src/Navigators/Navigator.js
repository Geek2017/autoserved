import React from "react";
import { createStackNavigator } from "@react-navigation/stack";
import {
  LoadingScreen,
  OTPScreen,
  LoginStateScreen,
  SignInScreenMain
} from "../Screens";
import { ShopTabBarNav, TabNav, AuthNav } from "./index";
import { inject, observer } from "mobx-react";

const Stack = createStackNavigator();

const Navigator = ({ store }) => {
  return (
    <Stack.Navigator screenOptions={{ headerShown: false }} headerMode="none">
      <Stack.Screen
        name="LoadingScreen"
        component={LoadingScreen}
        options={{
          animationTypeForReplace: "pop"
        }}
      />
      <Stack.Screen
        name="Main"
        component={TabNav}
        options={{
          animationEnabled: false
        }}
      />
      <Stack.Screen
        name="LoginStateScreen"
        component={LoginStateScreen}
        options={{
          animationEnabled: false
        }}
      />
      <Stack.Screen
        name="ShopTabBarNav"
        component={ShopTabBarNav}
        options={{
          animationEnabled: false
        }}
      />
      <Stack.Screen
        name="OTPScreen"
        component={OTPScreen}
        options={{
          animationEnabled: false
        }}
      />
      <Stack.Screen
        name="SignInScreen"
        component={AuthNav}
        options={{
          title: "SignIn",
          animationTypeForReplace: "pop"
        }}
      />
    </Stack.Navigator>
  );
};

export default inject("store")(observer(Navigator));
