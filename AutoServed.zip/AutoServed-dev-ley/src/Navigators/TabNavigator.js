import React from "react";
import {
  MyCarScreen,
  CarCreateScreen,
  DeffereScreen,
  HistoryRepairScreen,
  MaintenanceScreen,
  WalletScreen,
  CarShowScreen,
  CarEditScreen,
  PMSShowSCreen,
  PMSScreen,
  PMSRequestScreen,
  PMSSummaryScreen,
  PMSQoutesListScreen,
  PMSBookAndPayScreen,
  PMSPaymentScreen,
  SignInScreenMain,
  PMSCheckoutScreen,
  PMSPreAssestmentScreen
} from "../Screens";
import { createBottomTabNavigator } from "@react-navigation/bottom-tabs";
import { createDrawerNavigator } from "@react-navigation/drawer";
import { createStackNavigator } from "@react-navigation/stack";
import { TabBarCar, DrawerContent } from "../Components";
import { colors, icons } from "../../constant";
import { Image, TouchableOpacity } from "react-native";
import { useNavigation } from "@react-navigation/native";
import { getFocusedRouteNameFromRoute } from "@react-navigation/native";
import { CommonActions } from "@react-navigation/native";
import { HeaderBackButton } from "@react-navigation/stack";
import AuthNavigator from "./Auth";
import Icon from "react-native-vector-icons/FontAwesome5";
import IconPro from "react-native-vector-icons/FontAwesome5Pro";

const Stack = createStackNavigator();

const DrawerNav = () => {
  const Drawer = createDrawerNavigator();
  return (
    <Drawer.Navigator
      drawerContent={(props) => <DrawerContent {...props} />}
      initialRouteName="Home">
      <Drawer.Screen name="Home" component={TabNavigator} />
      <Drawer.Screen name="SignInScreen" component={AuthNavigator} />
    </Drawer.Navigator>
  );
};

const TabNavigator = () => {
  const Tab = createBottomTabNavigator();
  return (
    <Tab.Navigator
      tabBar={(props) => <TabBarCar {...props} />}
      headerMode="none"
      initialRouteName="Home">
      <Tab.Screen name="My Car" component={MyCarStack} />
      <Tab.Screen name="Maintenance Schedule" component={MaintenanceStack} />
      <Tab.Screen name="Home" component={CarStack} />
      <Tab.Screen name="Deferred Repairs" component={DeffereScreen} />
      <Tab.Screen name="My Wallet" component={WalletScreen} />
    </Tab.Navigator>
  );
};

const MaintenanceStack = () => {
  const navigation = useNavigation();

  return (
    <Stack.Navigator>
      <Stack.Screen
        name="Maintenance Schedule"
        component={MaintenanceScreen}
        options={{
          headerShown: true,
          headerBackTitle: "Home",
          headerTitleStyle: { color: "white" },
          headerTitle: "Maintenance Schedule",
          headerBackTitleStyle: { color: "white" },
          headerTintColor: "white",
          headerStyle: { backgroundColor: colors.blue_backgroud_secondary },
          headerRight: () => (
            <Icon
              name="calendar-alt"
              size={20}
              color="white"
              style={{ paddingRight: 16 }}
            />
          )
        }}
      />
    </Stack.Navigator>
  );
};

const CarStack = () => {
  const navigation = useNavigation();

  return (
    <Stack.Navigator screenOptions={{ headerShown: false }}>
      <Stack.Screen
        name="MyCarScreen"
        component={MyCarScreen}
        options={{
          animationTypeForReplace: "pop"
        }}
      />
      <Stack.Screen
        name="CreateCarScreen"
        component={CarCreateScreen}
        options={{
          headerShown: true,
          headerBackTitle: "Back",
          headerTitleStyle: { color: "white" },
          headerTitle: "Create Car",
          headerLeft: (props) => (
            <HeaderBackButton
              {...props}
              onPress={() => {
                navigation.dispatch(
                  CommonActions.navigate({
                    name: "My Car"
                  })
                );
              }}
            />
          ),
          headerBackTitleStyle: { color: "white" },
          headerTintColor: "white",
          headerStyle: { backgroundColor: colors.blue_backgroud_secondary },
          headerRight: () => (
            <Icon
              name="car"
              size={20}
              color="white"
              style={{ paddingRight: 16 }}
            />
          )
        }}
      />
      <Stack.Screen
        name="ShowCarScreen"
        component={CarShowScreen}
        options={{
          headerShown: true,
          headerBackTitle: "Home",
          headerTitleStyle: { color: "white" },
          headerTitle: "My Car",
          headerBackTitleStyle: { color: "white" },
          headerTintColor: "white",
          headerStyle: { backgroundColor: colors.blue_backgroud_secondary },
          headerRight: () => <Image source={icons.car} />
        }}
      />
      <Stack.Screen
        name="EditCarScreen"
        component={CarEditScreen}
        options={{
          headerShown: true,
          headerBackTitle: "Back",
          headerTitleStyle: { color: "white" },
          headerTitle: "Edit Car",
          headerLeft: (props) => (
            <HeaderBackButton
              {...props}
              onPress={() => {
                navigation.dispatch(
                  CommonActions.navigate({
                    name: "My Car"
                  })
                );
              }}
            />
          ),
          headerBackTitleStyle: { color: "white" },
          headerTintColor: "white",
          headerStyle: { backgroundColor: colors.blue_backgroud_secondary },
          headerRight: () => (
            <Icon
              name="car"
              size={20}
              color="white"
              style={{ paddingRight: 16 }}
            />
          )
        }}
      />
      <Stack.Screen
        name="PMSScreen"
        component={PMSScreen}
        options={{
          headerShown: true,
          headerBackTitle: "Home",
          headerTitleStyle: { color: "white" },
          headerTitle: "PMS",
          headerBackTitleStyle: { color: "white" },
          headerTintColor: "white",
          headerStyle: { backgroundColor: colors.blue_backgroud_secondary },
          headerRight: () => (
            <Icon
              name="tools"
              size={20}
              color="white"
              style={{ paddingRight: 16 }}
            />
          )
        }}
      />
      <Stack.Screen
        name="PMSShowSCreen"
        component={PMSShowSCreen}
        options={{
          headerShown: true,
          headerBackTitle: "PMS",
          headerTitleStyle: { color: "white" },
          headerTitle: "Maintenance Schedule",
          headerBackTitleStyle: { color: "white" },
          headerTintColor: "white",
          headerStyle: { backgroundColor: colors.blue_backgroud_secondary },
          headerRight: () => (
            <Icon
              name="tools"
              size={20}
              color="white"
              style={{ paddingRight: 16 }}
            />
          )
        }}
      />
      <Stack.Screen
        name="PMSRequestScreen"
        component={PMSRequestScreen}
        options={{
          headerShown: true,
          headerBackTitle: "PMS",
          headerTitleStyle: { color: "white" },
          headerTitle: "Maintenance Schedule",
          headerBackTitleStyle: { color: "white" },
          headerTintColor: "white",
          headerStyle: { backgroundColor: colors.blue_backgroud_secondary },
          headerRight: () => (
            <Icon
              name="calendar-alt"
              size={20}
              color="white"
              style={{ paddingRight: 16 }}
            />
          )
        }}
      />
      <Stack.Screen
        name="PMSSummaryScreen"
        component={PMSSummaryScreen}
        options={{
          headerShown: true,
          headerBackTitle: "Back",
          headerTitleStyle: { color: "white" },
          headerTitle: "Summary",
          headerLeft: (props) => (
            <HeaderBackButton
              {...props}
              onPress={() => {
                navigation.dispatch(
                  CommonActions.navigate({
                    name: "PMSScreen"
                  })
                );
              }}
            />
          ),
          headerBackTitleStyle: { color: "white" },
          headerTintColor: "white",
          headerStyle: { backgroundColor: colors.blue_backgroud_secondary },
          headerRight: () => (
            <Icon
              name="calendar-alt"
              size={20}
              color="white"
              style={{ paddingRight: 16 }}
            />
          )
        }}
      />
      <Stack.Screen
        name="PMSQoutesListScreen"
        component={PMSQoutesListScreen}
        options={{
          headerShown: true,
          headerBackTitle: "Back",
          headerTitleStyle: { color: "white" },
          headerTitle: "QUOTES LIST",
          headerBackTitleStyle: { color: "white" },
          headerTintColor: "white",
          headerStyle: { backgroundColor: colors.blue_backgroud_secondary },
          headerRight: () => (
            <Icon
              name="concierge-bell"
              size={20}
              color="white"
              style={{ paddingRight: 16 }}
            />
          )
        }}
      />
      <Stack.Screen
        name="PMSPreAssestmentScreen"
        component={PMSPreAssestmentScreen}
        options={{
          headerShown: true,
          headerBackTitle: "Back",
          headerTitleStyle: { color: "white" },
          headerTitle: "Pre-Assessment",
          headerBackTitleStyle: { color: "white" },
          headerTintColor: "white",
          headerStyle: { backgroundColor: colors.blue_backgroud_secondary },
          headerRight: () => (
            <Icon
              name="concierge-bell"
              size={20}
              color="white"
              style={{ paddingRight: 16 }}
            />
          )
        }}
      />
      <Stack.Screen
        name="PMSBookAndPayScreen"
        component={PMSBookAndPayScreen}
        options={{
          headerShown: true,
          headerBackTitle: "Back",
          headerTitleStyle: { color: "white" },
          headerTitle: "Book and Payment",
          headerBackTitleStyle: { color: "white" },
          headerTintColor: "white",
          headerStyle: { backgroundColor: colors.blue_backgroud_secondary },
          headerRight: () => (
            <Icon
              name="concierge-bell"
              size={20}
              color="white"
              style={{ paddingRight: 16 }}
            />
          )
        }}
      />
      <Stack.Screen
        name="PMSPaymentScreen"
        component={PMSPaymentScreen}
        options={{
          headerShown: true,
          headerBackTitle: "Back",
          headerTitleStyle: { color: "white" },
          headerTitle: "Payment",
          headerBackTitleStyle: { color: "white" },
          headerTintColor: "white",
          headerStyle: { backgroundColor: colors.blue_backgroud_secondary },
          headerRight: () => (
            <Icon
              name="wallet"
              size={20}
              color="white"
              style={{ paddingRight: 16 }}
            />
          )
        }}
      />
      <Stack.Screen
        name="PMSCheckoutScreen"
        component={PMSCheckoutScreen}
        options={{
          headerShown: true,
          headerBackTitle: "Back",
          headerTitleStyle: { color: "white" },
          headerTitle: "Checkout",
          headerBackTitleStyle: { color: "white" },
          headerTintColor: "white",
          headerLeft: (props) => (
            <HeaderBackButton
              {...props}
              onPress={() => {
                navigation.dispatch(
                  CommonActions.navigate({
                    name: "PMSScreen"
                  })
                );
              }}
            />
          ),
          headerStyle: { backgroundColor: colors.blue_backgroud_secondary },
          headerRight: () => <Image source={icons.wallet} />
        }}
      />
    </Stack.Navigator>
  );
};

const MyCarStack = () => {
  return (
    <Stack.Navigator>
      <Stack.Screen
        name="My Car"
        component={CarShowScreen}
        options={{
          headerShown: true,
          headerBackTitle: "Home",
          headerTitleStyle: { color: "white" },
          headerTitle: "My Car",
          headerBackTitleStyle: { color: "white" },
          headerTintColor: "white",
          headerStyle: { backgroundColor: colors.blue_backgroud_secondary },
          headerRight: () => (
            <Icon
              name="car"
              size={20}
              color="white"
              style={{ paddingRight: 16 }}
            />
          )
        }}
      />
    </Stack.Navigator>
  );
};

const getTabBarVisibility = (route) => {
  const routeName = getFocusedRouteNameFromRoute(route) ?? "";
  if (routeName === "") {
    return false;
  }
  return true;
};
export default DrawerNav;
