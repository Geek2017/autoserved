import React, { useEffect, useState } from "react";
import { StatusBar } from "react-native";
import { NavigationContainer } from "@react-navigation/native";
import AuthNavigator from "./Auth";
import Navigator from "./Navigator";
import { inject, observer } from "mobx-react";
const MainNavigator = ({ store }) => {
  // Set an initializing state whilst Firebase connects
  const [initializing, setInitializing] = useState(true);
  const [user, setUser] = useState();

  // Handle user state changes
  function onAuthStateChanged(user) {
    console.log(user);
    setUser(user);
    if (initializing) setInitializing(false);
  }

  store
    .retriveStorage("loginState")
    .then((response) => {
      onAuthStateChanged(response);
    })
    .catch((e) => console.log(e));

  if (initializing) return null;

  return (
    <NavigationContainer>
      <StatusBar
        barStyle="dark-content"
        translucent
        backgroundColor="transparent"
      />
      {user ? <Navigator /> : <AuthNavigator />}
    </NavigationContainer>
  );
};

export default inject("store")(observer(MainNavigator));
