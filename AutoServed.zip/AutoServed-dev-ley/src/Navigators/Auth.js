//import liraries
import React, { Component } from "react";
import { createStackNavigator } from "@react-navigation/stack";
import {
  SignInScreenMain,
  OTPScreen,
  SignUpScreen,
  LoginStateScreen,
  LoadingScreen
} from "../Screens";
import { ShopTabBarNav, TabNav } from "./index";
import { inject, observer } from "mobx-react";
const Auth = ({ store }) => {
  const Stack = createStackNavigator();
  return (
    <Stack.Navigator screenOptions={{ headerShown: false }} headerMode="none">
      <Stack.Screen
        name="SignInScreen"
        component={SignInScreenMain}
        options={{
          title: "SignIn",
          animationTypeForReplace: "pop"
        }}
      />
      <Stack.Screen
        name="OTPScreen"
        component={OTPScreen}
        options={{
          title: "",
          animationTypeForReplace: "pop"
        }}
      />
      <Stack.Screen
        name="LoadingScreen"
        component={LoadingScreen}
        options={{
          animationTypeForReplace: "pop"
        }}
      />
      <Stack.Screen
        name="SignUpScreen"
        component={SignUpScreen}
        options={{
          title: "",
          animationTypeForReplace: "pop"
        }}
      />
      <Stack.Screen
        name="Main"
        component={TabNav}
        options={{
          animationEnabled: false
        }}
      />
      <Stack.Screen
        name="LoginStateScreen"
        component={LoginStateScreen}
        options={{
          animationEnabled: false
        }}
      />
      <Stack.Screen
        name="ShopTabBarNav"
        component={ShopTabBarNav}
        options={{
          animationEnabled: false
        }}
      />
    </Stack.Navigator>
  );
};

export default inject("store")(observer(Auth));
