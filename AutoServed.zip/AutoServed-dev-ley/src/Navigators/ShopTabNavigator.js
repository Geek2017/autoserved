import React from "react";
import {
  MyCarScreen,
  CarCreateScreen,
  DeffereScreen,
  HistoryRepairScreen,
  MaintenanceScreen,
  WalletScreen,
  ShopScreen,
  ShopShowScreen,
  ShopServicesScreen,
  ShopBookedQoutesScreen,
  ShopBookedQoutesDeclineScreen,
  ShopPriceScreen,
  ShopCreateScreen,
  ShopSummaryScreen,
  ShopQuotationRequestScreen,
  ShopQuotationAcceptScreen,
  ShopQuotationSummaryScreen,
  ShopEditScreen,
  SignInScreenMain
} from "../Screens";
import { createBottomTabNavigator } from "@react-navigation/bottom-tabs";
import { createDrawerNavigator } from "@react-navigation/drawer";
import { createStackNavigator } from "@react-navigation/stack";
import { TabBarShop, DrawerContent } from "../Components";
import { colors, icons } from "../../constant";
import { Image, TouchableOpacity } from "react-native";
import { useNavigation, CommonActions } from "@react-navigation/native";
import { HeaderBackButton } from "@react-navigation/stack";
import { getFocusedRouteNameFromRoute } from "@react-navigation/native";
import AuthNavigator from "./Auth";
import Icon from "react-native-vector-icons/FontAwesome5";
const Stack = createStackNavigator();

const DrawerNav = () => {
  const Drawer = createDrawerNavigator();
  return (
    <Drawer.Navigator
      drawerContent={(props) => <DrawerContent {...props} />}
      initialRouteName="Home">
      <Drawer.Screen name="Home" component={TabNavigator} />
      <Drawer.Screen name="SignInScreen" component={AuthNavigator} />
    </Drawer.Navigator>
  );
};

const TabNavigator = () => {
  const Tab = createBottomTabNavigator();
  return (
    <Tab.Navigator
      tabBar={(props) => <TabBarShop {...props} />}
      initialRouteName="Home">
      <Tab.Screen
        name="My Shop"
        component={MyShopStack}
        options={({ route }) => ({
          tabBarVisible: getTabBarVisibility(route)
        })}
      />
      <Tab.Screen name="Quatation Request" component={qoutesStack} />
      <Tab.Screen name="Home" component={ShopStack} />
      <Tab.Screen
        name="Booked Appointments"
        component={BookedAppointmentStack}
        options={({ route }) => ({
          tabBarVisible: getTabBarVisibility(route)
        })}
      />
      {/* <Tab.Screen
        name="Transaction History"
        component={MaintenanceScreen}
        options={({ route }) => ({
          tabBarVisible: getTabBarVisibility(route)
        })}
      /> */}
      <Tab.Screen
        name="My Wallet"
        component={WalletScreen}
        options={({ route }) => ({
          tabBarVisible: getTabBarVisibility(route)
        })}
      />
    </Tab.Navigator>
  );
};

const qoutesStack = () => {
  const navigation = useNavigation();
  return (
    <Stack.Navigator>
      <Stack.Screen
        name="Quatation Request"
        component={ShopQuotationRequestScreen}
        options={{
          headerShown: true,
          headerBackTitle: "Back",
          headerTitleStyle: { color: "white" },
          headerTitle: "Quotation Requests",
          headerBackTitleStyle: { color: "white" },
          headerTintColor: "white",
          headerStyle: { backgroundColor: colors.blue_backgroud_secondary },
          headerRight: () => (
            <Icon
              name="concierge-bell"
              size={20}
              color="white"
              style={{ paddingRight: 16 }}
            />
          )
        }}
      />
      <Stack.Screen
        name="Quatation Accept"
        component={ShopQuotationAcceptScreen}
        options={{
          headerShown: true,
          headerBackTitle: "Back",
          headerTitleStyle: { color: "white" },
          headerTitle: "Quotation Accept",
          headerBackTitleStyle: { color: "white" },
          headerTintColor: "white",
          headerStyle: { backgroundColor: colors.blue_backgroud_secondary },
          headerRight: () => (
            <Icon
              name="concierge-bell"
              size={20}
              color="white"
              style={{ paddingRight: 16 }}
            />
          )
        }}
      />

      <Stack.Screen
        name="QuatationSummary"
        component={ShopQuotationSummaryScreen}
        options={{
          headerShown: true,
          headerBackTitle: "Back",
          // headerLeft: () => (
          //   <HeaderBackButton
          //     onPress={() => {
          //       navigation.goBack();
          //       // navigation.dispatch(
          //       //     CommonActions.navigate({
          //       //       name: "Quatation Request"
          //       //     })
          //       // );
          //     }}
          //   />
          // ),
          headerTitleStyle: { color: "white" },
          headerTitle: "Quotation Requests",
          headerBackTitleStyle: { color: "white" },
          headerTintColor: "white",
          headerStyle: { backgroundColor: colors.blue_backgroud_secondary },
          headerRight: () => (
            <Icon
              name="concierge-bell"
              size={20}
              color="white"
              style={{ paddingRight: 16 }}
            />
          )
        }}
      />
    </Stack.Navigator>
  );
};

const MyShopStack = () => {
  return (
    <Stack.Navigator screenOptions={{ headerShown: false }}>
      <Stack.Screen
        name="ShopShowScreen"
        component={ShopShowScreen}
        options={{
          headerShown: true,
          headerBackTitle: "Back",
          headerTitleStyle: { color: "white" },
          headerTitle: "My Shop",
          headerBackTitleStyle: { color: "white" },
          headerTintColor: "white",
          headerStyle: { backgroundColor: colors.blue_backgroud_secondary },
          headerRight: () => (
            <Icon
              name="store-alt"
              size={20}
              color="white"
              style={{ paddingRight: 16 }}
            />
          )
        }}
      />
      <Stack.Screen
        name="ShopEditScreen"
        component={ShopEditScreen}
        options={{
          headerShown: true,
          headerBackTitle: "Back",
          headerTitleStyle: { color: "white", alignSelf: "center" },
          headerTitle: "Edit Shop",
          headerBackTitleStyle: { color: "white" },
          headerTintColor: "white",
          headerStyle: { backgroundColor: colors.blue_backgroud_secondary },
          headerRight: () => (
            <Icon
              name="store-alt"
              size={20}
              color="white"
              style={{ paddingRight: 16 }}
            />
          )
        }}
      />
    </Stack.Navigator>
  );
};

const ShopStack = () => {
  return (
    <Stack.Navigator screenOptions={{ headerShown: false }}>
      <Stack.Screen
        name="ShopScreen"
        component={ShopScreen}
        options={{
          animationTypeForReplace: "pop",
          headerTitle: "My Shop"
        }}
      />
      <Stack.Screen
        name="ShopShowScreen"
        component={ShopShowScreen}
        options={{
          headerShown: true,
          headerBackTitle: "Back",
          headerTitleStyle: { color: "white" },
          headerTitle: "My Shop",
          headerBackTitleStyle: { color: "white" },
          headerTintColor: "white",
          headerStyle: { backgroundColor: colors.blue_backgroud_secondary }
        }}
      />
      <Stack.Screen
        name="ShopCreateScreen"
        component={ShopCreationStack}
        options={{
          animationTypeForReplace: "pop",
          headerTitle: "Create Shop"
        }}
      />
      <Stack.Screen
        name="ShopServicesScreen"
        component={ShopServicesScreen}
        options={{
          headerShown: true,
          headerBackTitle: "Back",
          headerTitleStyle: { color: "white" },
          headerTitle: "Services Offered",
          headerBackTitleStyle: { color: "white" },
          headerTintColor: "white",
          headerStyle: { backgroundColor: colors.blue_backgroud_secondary },
          headerRight: () => (
            <Icon
              name="cogs"
              size={20}
              color="white"
              style={{ paddingRight: 16 }}
            />
          )
        }}
      />
      <Stack.Screen
        name="ShopPriceScreen"
        component={ShopPriceScreen}
        options={{
          headerShown: true,
          headerBackTitle: "Back",
          headerTitleStyle: { color: "white" },
          headerTitle: "Pricing Setup",
          headerBackTitleStyle: { color: "white" },
          headerTintColor: "white",
          headerStyle: { backgroundColor: colors.blue_backgroud_secondary },
          headerRight: () => (
            <Icon
              name="cogs"
              size={20}
              color="white"
              style={{ paddingRight: 16 }}
            />
          )
        }}
      />
    </Stack.Navigator>
  );
};

const BookedAppointmentStack = () => {
  return (
    <Stack.Navigator screenOptions={{ headerShown: false }}>
      <Stack.Screen
        name="ShopBookedQoutesScreen"
        component={ShopBookedQoutesScreen}
        options={{
          headerShown: true,
          headerBackTitle: "Back",
          headerTitleStyle: { color: "white" },
          headerTitle: "Booked Appointments",
          headerBackTitleStyle: { color: "white" },
          headerTintColor: "white",
          headerStyle: { backgroundColor: colors.blue_backgroud_secondary },
          headerRight: () => (
            <Icon
              name="calendar-day"
              size={20}
              color="white"
              style={{ paddingRight: 16 }}
            />
          )
        }}
      />
      <Stack.Screen
        name="ShopBookedQoutesDeclineScreen"
        component={ShopBookedQoutesDeclineScreen}
        options={{
          headerShown: true,
          headerBackTitle: "Back",
          headerTitleStyle: { color: "white", alignSelf: "center" },
          headerTitle: "Reschedule Appointment",
          headerBackTitleStyle: { color: "white" },
          headerTintColor: "white",
          headerStyle: { backgroundColor: colors.blue_backgroud_secondary },
          headerRight: () => (
            <Icon
              name="calendar-day"
              size={20}
              color="white"
              style={{ paddingRight: 16 }}
            />
          )
        }}
      />
    </Stack.Navigator>
  );
};

const ShopCreationStack = () => {
  return (
    <Stack.Navigator screenOptions={{ headerShown: false }}>
      <Stack.Screen
        name="ShopCreateScreen"
        component={ShopCreateScreen}
        options={{
          animationTypeForReplace: "pop",
          headerTitle: "My Shop"
        }}
      />
      <Stack.Screen
        name="ShopSummaryScreen"
        component={ShopSummaryScreen}
        options={{
          animationTypeForReplace: "pop",
          headerTitle: "Summary"
        }}
      />
    </Stack.Navigator>
  );
};

const getTabBarVisibility = (route) => {
  const routeName = getFocusedRouteNameFromRoute(route) ?? "";
  console.log(routeName);
  if (
    routeName === "ShopCreateScreen" ||
    routeName === "ShopSummaryScreen"
    // routeName === "ProfileChangePasswordScreen" ||
    // routeName === "ProfileEditScreen" ||
    // routeName === "SearchCounselorsScreen" ||
    // routeName === "SearchProfileScreen"
  ) {
    return false;
  }
  return true;
};

export default DrawerNav;
