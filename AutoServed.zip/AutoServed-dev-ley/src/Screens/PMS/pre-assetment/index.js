//import liraries
import React, { useState } from "react";
import { ScrollView } from "react-native";
import { View, Text, StyleSheet, Image } from "react-native";
import { colors, mainStyle, screen, images } from "../../../../constant";
import { thousands_separators } from "../../../Helper";
import { ButtonGroup, Icon } from "react-native-elements";
import moment from "moment";
import { TouchableOpacity } from "react-native";
// create a component
const index = ({ route, navigation }) => {
  const { shopData, priceData, qoutesData } = route.params;
  let total = 0;
  const pricingCheck = priceData ? priceData : [];
  const [selectedIndex, setSelectedIndex] = useState();

  pricingCheck.map((item) => {
    total =
      parseInt(item.airfilter ? item.airfilter : 0) +
      parseInt(item.cabinfilter ? item.cabinfilter : 0) +
      parseInt(item.coolant ? item.coolant : 0) +
      parseInt(item.engineoil ? item.engineoil : 0) +
      parseInt(item.flushing ? item.flushing : 0) +
      parseInt(item.labor ? item.labor : 0) +
      parseInt(item.oilfilter ? item.oilfilter : 0) +
      parseInt(item.bsf ? item.bsf : 0) +
      parseInt(item.sparkplug ? item.sparkplug : 0) +
      parseInt(item.breakfluid ? item.breakfluid : 0) +
      parseInt(item.psf ? item.psf : 0);
  });

  const decline = () => (
    <View
      style={{
        backgroundColor: "#FF0000",
        width: "100%",
        height: "100%",
        justifyContent: "center",
        alignItems: "center"
      }}>
      <Text
        style={{
          fontFamily: "OpenSans-Regular",
          fontSize: 14,
          color: "white"
        }}>
        DECLINE
      </Text>
    </View>
  );
  const negotiate = () => (
    <View
      style={{
        backgroundColor: "#367EC6",
        width: "100%",
        height: "100%",
        justifyContent: "center",
        alignItems: "center"
      }}>
      <Text
        style={{
          fontFamily: "OpenSans-Regular",
          fontSize: 14,
          color: "white"
        }}>
        NEGOTIATE
      </Text>
    </View>
  );
  const accept = () => (
    <View
      style={{
        backgroundColor: colors.dark_blue,
        width: "100%",
        height: "100%",
        justifyContent: "center",
        alignItems: "center"
      }}>
      <Text
        style={{
          fontFamily: "OpenSans-Regular",
          fontSize: 14,
          color: "white"
        }}>
        ACCEPT
      </Text>
    </View>
  );
  const buttons = [
    { element: decline },
    { element: negotiate },
    { element: accept }
  ];

  const updateIndex = async (selectedIndex) => {
    setSelectedIndex(selectedIndex);
    if (selectedIndex == 0) {
    }
    if (selectedIndex == 1) {
      await Linking.openURL("https://m.me/" + shopData.fb_messenger);
    }
    if (selectedIndex == 2) {
      // store.getAllPrices();
      navigation.navigate("PMSPaymentScreen", {
        arrData: shopData,
        qoutesData: qoutesData,
        priceData: priceData
      });
    }
  };

  return (
    <ScrollView
      style={{ backgroundColor: colors.blue_backgroud }}
      contentContainerStyle={{
        alignItems: "center",
        justifyContent: "center"
      }}>
      <View style={styles.container}>
        {/* First Content */}
        <View style={styles.firstContentOne}>
          {/* shop img */}
          <View
            style={{ width: "40%", paddingLeft: 8, justifyContent: "center" }}>
            <Image
              source={
                shopData.shop_frontimg
                  ? { uri: shopData.shop_frontimg }
                  : images.card_home
              }
              style={styles.img}
            />
          </View>
          {/* Vertical Line */}
          <View style={{ borderWidth: 1, borderColor: "white" }}></View>

          {/* details */}
          <View style={{ paddingHorizontal: 8 }}>
            <Text
              style={[
                mainStyle.main.Header2,
                { color: "white", fontSize: 16 }
              ]}>
              {shopData.shop_name.toUpperCase()}
            </Text>
            <Text
              style={[
                mainStyle.main.subtleText,
                {
                  fontSize: 10,
                  color: "white",
                  width: screen.width * 0.55
                }
              ]}>
              {
                (shopData.city,
                +" " +
                  shopData.brgy +
                  " " +
                  shopData.province +
                  " " +
                  shopData.region)
              }
            </Text>
            <Text
              style={[mainStyle.main.Bold, { color: "white", fontSize: 10 }]}>
              CONTACT :{" "}
              {`${shopData.owner_contactperson.toUpperCase()}\n${
                shopData.owner_contactperson_no
              }\n${shopData.email}`}
            </Text>
          </View>
        </View>
        {/* End First Content */}

        {/* Qoute and Job */}
        <View
          style={{
            flexDirection: "row",
            justifyContent: "space-between",
            paddingHorizontal: 8
          }}>
          <Text
            style={[
              mainStyle.main.Header2,
              { color: colors.another_blue, fontSize: 16 }
            ]}>
            {`Quote PHP. ${thousands_separators(total)}`}
          </Text>

          <Text
            style={[
              mainStyle.main.Header2,
              { color: colors.another_blue, fontSize: 16 }
            ]}>
            {`Job : ${qoutesData.pms}`}
          </Text>
        </View>
        {/* End Qoute and Job */}
        {/* Note */}
        <Text
          style={[
            mainStyle.main.Header2,
            {
              color: colors.another_blue,
              fontSize: 12,
              paddingHorizontal: 8,
              paddingVertical: 16,
              textAlign: "center"
            }
          ]}>
          Note:Price may change during actual of the car inspection
        </Text>
        {/* End Note*/}

        {/* Horizontal Line */}
        <View
          style={{
            borderWidth: 1,
            borderColor: colors.another_blue,
            height: 1,
            width: "100%",
            marginBottom: 16
          }}></View>

        {/* Car Details */}
        <View style={{ paddingHorizontal: 8 }}>
          {/*  */}
          <View style={{ flexDirection: "row" }}>
            <Text
              style={[
                mainStyle.main.PreTitle,
                { color: colors.another_blue, width: "50%", fontSize: 14 }
              ]}>
              Plate Number :{" "}
            </Text>
            <Text
              style={[
                mainStyle.main.PreTitle,
                { color: colors.another_blue, width: "50%", fontSize: 14 }
              ]}>
              {qoutesData.plateno}
            </Text>
          </View>
          {/*  */}
          <View style={{ flexDirection: "row" }}>
            <Text
              style={[
                mainStyle.main.PreTitle,
                { color: colors.another_blue, width: "50%", fontSize: 14 }
              ]}>
              Year Model :{" "}
            </Text>
            <Text
              style={[
                mainStyle.main.PreTitle,
                { color: colors.another_blue, width: "50%", fontSize: 14 }
              ]}>
              {qoutesData.yrmodel}
            </Text>
          </View>
          {/*  */}
          <View style={{ flexDirection: "row" }}>
            <Text
              style={[
                mainStyle.main.PreTitle,
                { color: colors.another_blue, width: "50%", fontSize: 14 }
              ]}>
              Make :{" "}
            </Text>
            <Text
              style={[
                mainStyle.main.PreTitle,
                { color: colors.another_blue, width: "50%", fontSize: 14 }
              ]}>
              {qoutesData.make}
            </Text>
          </View>
          {/*  */}
          <View style={{ flexDirection: "row" }}>
            <Text
              style={[
                mainStyle.main.PreTitle,
                { color: colors.another_blue, width: "50%", fontSize: 14 }
              ]}>
              Model :{" "}
            </Text>
            <Text
              style={[
                mainStyle.main.PreTitle,
                { color: colors.another_blue, width: "50%", fontSize: 14 }
              ]}>
              {qoutesData.model}
            </Text>
          </View>
          {/*  */}
          <View style={{ flexDirection: "row" }}>
            <Text
              style={[
                mainStyle.main.PreTitle,
                { color: colors.another_blue, width: "50%", fontSize: 14 }
              ]}>
              Engine :{" "}
            </Text>
            <Text
              style={[
                mainStyle.main.PreTitle,
                { color: colors.another_blue, width: "50%", fontSize: 14 }
              ]}>
              {qoutesData.engine}
            </Text>
          </View>
          {/*  */}
          <View style={{ flexDirection: "row" }}>
            <Text
              style={[
                mainStyle.main.PreTitle,
                { color: colors.another_blue, width: "50%", fontSize: 14 }
              ]}>
              Transmission :{" "}
            </Text>
            <Text
              style={[
                mainStyle.main.PreTitle,
                { color: colors.another_blue, width: "50%", fontSize: 14 }
              ]}>
              {qoutesData.transmission}
            </Text>
          </View>
          {/*  */}
          <View style={{ flexDirection: "row" }}>
            <Text
              style={[
                mainStyle.main.PreTitle,
                { color: colors.another_blue, width: "50%", fontSize: 14 }
              ]}>
              Date of Request :{" "}
            </Text>
            <Text
              style={[
                mainStyle.main.PreTitle,
                { color: colors.another_blue, width: "50%", fontSize: 14 }
              ]}>
              {qoutesData.purchasedate}
            </Text>
          </View>
          {/*  */}
          <View style={{ flexDirection: "row" }}>
            <Text
              style={[
                mainStyle.main.PreTitle,
                { color: colors.another_blue, width: "50%", fontSize: 14 }
              ]}>
              Current Mileage :{" "}
            </Text>
            <Text
              style={[
                mainStyle.main.PreTitle,
                { color: colors.another_blue, width: "50%", fontSize: 14 }
              ]}>
              {thousands_separators(qoutesData.mileage)}
            </Text>
          </View>
        </View>
        {/* End Car Details */}

        {/* Horizontal Line */}
        <View
          style={{
            borderWidth: 1,
            borderColor: colors.another_blue,
            height: 1,
            width: "100%",
            marginVertical: 16
          }}></View>

        {/* Date OF */}
        <View style={{ paddingHorizontal: 8 }}>
          {/*  */}
          <View style={{ flexDirection: "row" }}>
            <Text
              style={[
                mainStyle.main.PreTitle,
                { color: colors.another_blue, width: "50%", fontSize: 14 }
              ]}>
              DATE OF REQUEST :{" "}
            </Text>
            <Text
              style={[
                mainStyle.main.PreTitle,
                { color: colors.another_blue, width: "50%", fontSize: 14 }
              ]}>
              {qoutesData.preferedschedules.split(",").map((item, index) => {
                return `${moment(item).format("MMMM DD, YYYY")} ${"\n"}`;
              })}
            </Text>
          </View>
          {/*  */}
          <View style={{ flexDirection: "row", marginTop: -22 }}>
            <Text
              style={[
                mainStyle.main.PreTitle,
                { color: colors.another_blue, width: "50%", fontSize: 14 }
              ]}>
              FOR REPLACEMENT :{" "}
            </Text>
          </View>
          <View style={{ paddingBottom: 16 }}>
            {qoutesData.for_replacement.split(",").map((item, index) => (
              <View
                style={{
                  flexDirection: "row",
                  marginVertical: -2
                }}>
                <Text
                  style={[
                    mainStyle.main.PreTitle,
                    { color: colors.another_blue, width: "50%", fontSize: 14 }
                  ]}>
                  - {item}
                </Text>
                <Text
                  style={[
                    mainStyle.main.PreTitle,
                    { color: colors.another_blue, width: "50%", fontSize: 14 }
                  ]}>
                  {/* PHP: {jsonReplacement[item]} */}
                  {/* {console.log(qoutesData)} */}
                </Text>
              </View>
            ))}
          </View>
        </View>

        <ButtonGroup
          onPress={(index) => updateIndex(index)}
          selectedIndex={selectedIndex}
          buttons={buttons}
          containerStyle={{
            height: 40,
            marginVertical: 16,
            borderRadius: 75,
            borderWidth: 2,
            borderColor: colors.blue_backgroud_secondary,
            shadowColor: "#000",
            shadowOffset: {
              width: 0,
              height: 2
            },
            shadowOpacity: 0.25,
            shadowRadius: 3.84,
            elevation: 5
          }}
          selectedButtonStyle={{ backgroundColor: colors.font_text_color }}
        />
      </View>
      <View style={{ marginBottom: 60 }}></View>
      {/* Three Btn */}
    </ScrollView>
  );
};

// define your styles
const styles = StyleSheet.create({
  container: {
    marginVertical: 16,
    backgroundColor: "white",
    borderRadius: 15,
    shadowColor: "#000",
    shadowOffset: {
      width: 0,
      height: 2
    },
    shadowOpacity: 0.25,
    shadowRadius: 3.84,
    marginBottom: 30,
    width: screen.width * 0.9,
    paddingHorizontal: 16,
    elevation: 5
  },
  firstContentOne: {
    flexDirection: "row",
    backgroundColor: colors.another_blue,
    borderRadius: 15,
    marginVertical: 16
  },
  img: {
    height: 75,
    width: "90%",
    borderRadius: 15,
    marginVertical: 8
  }
});

//make this component available to the app
export default index;
