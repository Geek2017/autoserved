//import liraries
import React, { useEffect, useState } from "react";
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  ActivityIndicator
} from "react-native";
import { QuotesList, SubmitButton } from "../../../Components";
import { colors, mainStyle, screen } from "../../../../constant";
import { inject, observer } from "mobx-react";
// create a component
const index = ({ navigation, store }) => {
  if (store.fetching == false) {
    store.allShops.map((data) => {});
  }
  useEffect(() => {
    store.allShops = [];
    console.log(store.allPrices[0]);
  }, []);

  return (
    <ScrollView style={{ flex: 1, backgroundColor: colors.blue_backgroud }}>
      {store.fetching ? (
        <ActivityIndicator
          color="grey"
          size={60}
          style={{ justifyContent: "center" }}
        />
      ) : (
        <View>
          <Text
            style={[
              mainStyle.main.Header2,
              { textAlign: "center", fontSize: 20, paddingVertical: 8 }
            ]}>
            {store.allShops.length == 0 ? "" : "HERE ARE YOUR QUOTES"}
          </Text>

          <View style={styles.container}>
            {store.allShops.map((data, index) => {
              let priceData = store.allQoutesShopPrices[0]
                ? store.allQoutesShopPrices[0].filter(
                    (e) => e.shopid == data.mobileno
                  )
                : [];
              return (
                <View key={Math.random()}>
                  <QuotesList
                    arrData={data}
                    qoutesData={store.allQoutesIndividual[0]}
                    navigation={navigation}
                    threeBtn
                    priceData={priceData}
                  />
                  {index == store.allShops.length - 1 ? (
                    <View />
                  ) : (
                    <View
                      style={{
                        borderColor: colors.blue_backgroud_secondary,
                        borderWidth: 1.5,
                        zIndex: 20
                      }}></View>
                  )}
                </View>
              );
            })}
            {store.allShops.length == 0 ? (
              <Text
                style={[
                  mainStyle.main.Header3,
                  {
                    width: screen.width * 0.9,
                    textAlign: "center",
                    fontSize: 40
                  }
                ]}>
                There's no shop accepting your quotes
              </Text>
            ) : (
              <View />
            )}
          </View>
        </View>
      )}
      <View style={{ marginBottom: 100 }}></View>
    </ScrollView>
  );
};

// define your styles
const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: "center",
    backgroundColor: "white",
    marginHorizontal: 16,
    borderRadius: 15,
    shadowColor: "#000",
    shadowOffset: {
      width: 0,
      height: 2
    },
    shadowOpacity: 0.25,
    shadowRadius: 3.84,
    elevation: 5
  }
});

//make this component available to the app
export default inject("store")(observer(index));
