//import liraries
import React, { useState } from "react";
import {
  View,
  Text,
  StyleSheet,
  Image,
  TouchableOpacity,
  ScrollView,
  Alert
} from "react-native";
import { screen, colors, icons } from "../../../../constant";
import Icon from "react-native-vector-icons/Feather";
import { SubmitButton } from "../../../Components";
import { Calendar, CalendarList, Agenda } from "react-native-calendars";
import { ThreeButton } from "../../../Components";
import { inject, observer } from "mobx-react";
import moment from "moment";
import buttonStyle from "../../../../constant/buttonStyle";
function removeDuplicates(data, key) {
  return [...new Map(data.map((item) => [key(item), item])).values()];
}

function sortFunction(a, b) {
  var dateA = new Date(a.date).getTime();
  var dateB = new Date(b.date).getTime();
  return dateA > dateB ? 1 : -1;
}
const index = ({ navigation, route, store }) => {
  const { arrData, isPmsMajor } = route.params;
  const [markedDates, setmarkedDates] = useState({});
  const [dataReplacement, setDataReplacement] = useState([]);
  const [typeOfShop, setTypeOfShop] = useState([]);
  const [prefSched, setPrefSched] = useState([]);
  const PMS_Type = isPmsMajor ? "major" : "minor";
  const onDayPress = (day) => {
    let date = { date: day.dateString };

    let markedDatesObj = { ...markedDates };
    markedDatesObj[day.dateString] = {
      selected: true
    };
    if (Object.keys(markedDates).length < 3) {
      setmarkedDates(markedDatesObj);
      setPrefSched((prev) => [...prev, date]);
    } else {
      alert("You can only pick 3 dates");
    }
  };

  const storingData = () => {
    let replacement = removeDuplicates(dataReplacement, (item) => item.title);
    let arrReplacement = [];
    let arrReplacementOption = [];

    let dateSort = prefSched.sort(sortFunction);
    let dateRemoveDup = removeDuplicates(dateSort, (item) => item.date);
    let arrDate = [];

    let prefType = removeDuplicates(typeOfShop, (item) => item.title);
    let distance = "";

    prefType.map((item, index) => {
      if (index == 0) {
        distance = item.value;
      }
    });

    replacement.map((item) => {
      let val = item.value.replace(/\s+/g, " ").replace("-", "").trim();
      arrReplacement.push(item.title);
      arrReplacementOption.push(val);
    });

    dateRemoveDup.map((item) => {
      arrDate.push(item.date);
    });

    store.qoutes.iqr_from = arrData.mobileno;
    store.qoutes.engine = arrData.engine;
    store.qoutes.make = arrData.make;
    store.qoutes.mileage = arrData.mileage;
    store.qoutes.model = arrData.model;
    store.qoutes.cartype = arrData.cartype;
    store.qoutes.plateno = arrData.plateno;
    store.qoutes.purchasedate = arrData.purchasedate;
    store.qoutes.transmission = arrData.transmission;
    store.qoutes.pms = PMS_Type;
    store.qoutes.for_replacement = arrReplacement.toString();
    store.qoutes.for_rep_option = arrReplacementOption.toString();
    store.qoutes.preferedschedules = arrDate.toString();
    store.qoutes.shopsvecinity = distance;
    store.qoutes.stats = 1;
    store.qoutes.yrmodel = arrData.year;
    store.qoutes.lat = arrData.lat;
    store.qoutes.long = arrData.long;
    store.qoutes.requestdate = moment().format("MMMM DD YYYY");
    if (arrDate.toString() != "") {
      if (arrReplacement.toString() != "") {
        store.createQoutes((result) => {
          if (!result)
            navigation.navigate("PMSSummaryScreen", {
              arrData: arrData,
              replacement: removeDuplicates(
                dataReplacement,
                (item) => item.title
              ),
              prefSched: dateRemoveDup,
              prefTypeShop: removeDuplicates(typeOfShop, (item) => item.title)
            });
        });
      } else {
        alert("Please select a replacement");
      }
    } else {
      alert("Please select a prefered schedules");
    }
  };

  return (
    <ScrollView
      style={styles.container}
      contentContainerStyle={{ alignItems: "center" }}>
      <View
        style={{
          width: 0.9 * screen.width,
          margin: 10,
          paddingHorizontal: 16,
          backgroundColor: colors.blue_backgroud_secondary,
          borderRadius: 15,
          shadowColor: "#000",
          shadowOffset: {
            width: 0,
            height: 2
          },
          shadowOpacity: 0.25,
          shadowRadius: 3.84,
          elevation: 5
        }}>
        <View
          style={{
            justifyContent: "center",
            alignItems: "center",
            flexDirection: "row"
          }}>
          <View style={styles.data_content}>
            <Text style={styles.lbl}>For Replacement</Text>
            <View
              style={{
                flexDirection: "row",
                flexWrap: "wrap",
                alignItems: "center"
              }}>
              <Text style={styles.lblThree}>Engine Oil: </Text>
              <ThreeButton
                one="Regular"
                two={`Semi- \n Synthetic`}
                three={`Fully- \n Synthetic`}
                title="Engine Oil"
                setDataReplacement={setDataReplacement}
                dataReplacement={dataReplacement}
              />
            </View>
          </View>
        </View>
        {isPmsMajor
          ? store.major.map((item) => {
              return (
                <View
                  style={{
                    justifyContent: "center",
                    alignItems: "center",
                    flexDirection: "row"
                  }}>
                  <View style={styles.data_content}>
                    <View
                      style={{
                        flexDirection: "row",
                        flexWrap: "wrap",
                        alignItems: "center"
                      }}>
                      <Text style={styles.lblThree}>{item}: </Text>
                      <ThreeButton
                        one="Original"
                        two="Replacement"
                        three={`Shop \n Recommends`}
                        title={item}
                        setDataReplacement={setDataReplacement}
                        dataReplacement={dataReplacement}
                      />
                    </View>
                  </View>
                </View>
              );
            })
          : store.minor.map((item) => {
              return (
                <View
                  style={{
                    justifyContent: "center",
                    alignItems: "center",
                    flexDirection: "row"
                  }}>
                  <View style={styles.data_content}>
                    <View
                      style={{
                        flexDirection: "row",
                        flexWrap: "wrap",
                        alignItems: "center"
                      }}>
                      <Text style={styles.lblThree}>{item}: </Text>
                      <ThreeButton
                        one="Original"
                        two="Replacement"
                        three={`Shop \n Recommends`}
                        title={item}
                        setDataReplacement={setDataReplacement}
                        dataReplacement={dataReplacement}
                      />
                    </View>
                  </View>
                </View>
              );
            })}
        <View style={styles.lineSeperator}></View>

        {/* Second */}
        <View
          style={{
            justifyContent: "center",
            alignItems: "center",
            flexDirection: "row"
          }}>
          <View style={styles.data_content}>
            <Text style={styles.lbl}>PREFFERED SCHEDULE</Text>
            <Text style={styles.lbl}>Pick 3 choices</Text>

            <Calendar
              current={new Date()}
              hideExtraDays={false}
              onDayPress={onDayPress}
              markedDates={markedDates}
              theme={{
                calendarBackground: colors.dark_blue,
                dayTextColor: "white",
                monthTextColor: "white",
                indicatorColor: "white",
                selectedDayTextColor: "#ffffff",
                textDayFontFamily: "OpenSans-Regular",
                textMonthFontFamily: "OpenSans-Regular",
                textDayHeaderFontFamily: "OpenSans-Regular",
                textMonthFontWeight: "bold",
                textDayHeaderFontWeight: "300",
                textDayFontSize: 20,
                textMonthFontSize: 20,
                textDayHeaderFontSize: 20,
                arrowColor: "white",
                selectedDayTextColor: "black",
                "stylesheet.day.basic": {
                  selected: {
                    borderRadius: 25,
                    alignItems: "center",
                    backgroundColor: "white"
                  }
                }
                // textDisabledColor: 'red',
              }}
            />
          </View>
        </View>
        <View style={styles.lineSeperator}></View>
        {/* Third */}
        <View
          style={{
            justifyContent: "center",
            alignItems: "center",
            flexDirection: "row",
            paddingBottom: 40
          }}>
          <View style={styles.data_content}>
            <Text style={styles.lbl}>PREFFERED TYPE OF SHOPS</Text>
            <View
              style={{
                flexDirection: "row",
                flexWrap: "wrap",
                alignItems: "center"
              }}>
              <Text style={styles.lblThree}>Distance:</Text>
              <ThreeButton
                one="5KM"
                two="10KM"
                three="20KM"
                title="Distance: "
                setDataReplacement={setTypeOfShop}
                dataReplacement={typeOfShop}
              />
            </View>
            {/* <View
              style={{
                flexDirection: "row",
                flexWrap: "wrap",
                alignItems: "center"
              }}>
              <Text style={styles.lblThree}>Rating :</Text>
              <ThreeButton
                one="< 3 stars"
                two="3-4 stars"
                three="5 stars"
                title="Rating: "
                setDataReplacement={setTypeOfShop}
                dataReplacement={typeOfShop}
              />
            </View> */}
          </View>
        </View>
      </View>
      <TouchableOpacity
        style={[buttonStyle.btn.btnDarkBlue, { elevation: 6 }]}
        onPress={() => storingData()}>
        <Text style={buttonStyle.btn.lblBtnDarkBlue}>REQUEST QUOTES</Text>
      </TouchableOpacity>
      <View style={{ marginBottom: 70 }}></View>
    </ScrollView>
  );
};

// define your styles
const styles = StyleSheet.create({
  container: {
    // alignItems: "center",
    backgroundColor: colors.blue_backgroud
  },
  data_content: {
    width: "100%",
    height: "100%",
    paddingTop: 20
  },
  lbl: {
    fontFamily: "OpenSans-Regular",
    color: "white",
    fontSize: 0.02 * screen.height
  },
  edit: {
    width: "45%",
    height: 40,
    backgroundColor: colors.dark_blue,
    borderTopLeftRadius: 20,
    borderBottomLeftRadius: 20,
    alignItems: "center",
    justifyContent: "center"
  },
  delete: {
    width: "45%",
    height: 40,
    backgroundColor: "red",
    borderTopRightRadius: 20,
    borderBottomRightRadius: 20,
    alignItems: "center",
    justifyContent: "center"
  },
  lblEditDelete: {
    fontFamily: "OpenSans-Regular",
    color: "white"
  },
  lineSeperator: {
    backgroundColor: "black",
    width: "100%",
    height: 3
  },
  lblList: {
    fontFamily: "OpenSans-Regular",
    color: "white",
    marginLeft: 20
  },
  lblThree: {
    width: "20%",
    fontFamily: "OpenSans-Regular",
    color: "white"
  }
});

//make this component available to the app
export default inject("store")(observer(index));
