//import liraries
import React, { Component } from "react";
import {
  View,
  Text,
  StyleSheet,
  Image,
  TouchableOpacity,
  ScrollView
} from "react-native";
import { screen, colors, icons } from "../../../../constant";
import Icon from "react-native-vector-icons/Feather";
import { SubmitButton } from "../../../Components";
import buttonStyle from "../../../../constant/buttonStyle";
import moment from "moment";
function thousands_separators(num) {
  var newNstr = num.toString().replace(",", "");
  var num_parts = newNstr.toString().split(".");
  num_parts[0] = num_parts[0].replace(/\B(?=(\d{3})+(?!\d))/g, ",");
  return num_parts.join(".");
}

function AgeOfCar(dop) {
  const startDate = dop;
  // const endDate = "2020-03-15";
  const diffInMs = new Date() - new Date(startDate);
  const diffInDays = diffInMs / (1000 * 60 * 60 * 24);
  let total = Math.round(diffInDays);
  return total;
}

function KmForDay(CurrentMileage, AgeOfCar) {
  console.log("Current Mileage :", CurrentMileage);
  console.log("Age Of Car :", AgeOfCar);
  let total = parseInt(CurrentMileage / AgeOfCar);
  return CurrentMileage / AgeOfCar;
}

function PMS(CurrentMileage) {
  let total = Math.ceil(CurrentMileage / 5000) * 5000;
  return total;
}

function daysToPms(pms, CurrentMileage, kmday) {
  let total = (parseInt(pms) - parseInt(CurrentMileage)) / parseInt(kmday);
  return total.toFixed(2);
}

function actualDatePms(pmsDay) {
  var todayDate = new Date();
  todayDate.setDate(todayDate.getDate() + parseInt(pmsDay));
  return todayDate;
}

function boolPmsBelowHundreds(pms) {
  if (pms >= 100000) {
    return false;
  } else {
    return true;
  }
}

function MajorOrMinorPms(pms) {
  var algo = (Math.ceil(pms / 5000) * 5000) % 20000;

  if (algo == 0) {
    return true;
  } else {
    return false;
  }
}
// create a component
const index = ({ navigation, route }) => {
  const { arrData } = route.params;
  let pms = PMS(arrData.mileage);
  let carage = AgeOfCar(arrData.purchasedate);
  let kmday = KmForDay(arrData.mileage, carage);
  let daysPms = daysToPms(pms, arrData.mileage, kmday);
  let daysString = actualDatePms(daysPms);
  var strDate = moment(daysString).format("LL");
  let isPmsBelowHundreds = boolPmsBelowHundreds(pms);
  let isPmsMajor = MajorOrMinorPms(pms);
  return (
    <ScrollView
      style={styles.container}
      contentContainerStyle={{ alignItems: "center" }}>
      <View
        style={{
          width: 0.9 * screen.width,
          margin: 10,
          backgroundColor: colors.blue_backgroud_secondary,
          borderRadius: 15,
          shadowColor: "#000",
          shadowOffset: {
            width: 0,
            height: 2
          },
          shadowOpacity: 0.25,
          shadowRadius: 3.84,
          elevation: 5
        }}>
        <View
          style={{
            justifyContent: "center",
            alignItems: "center",
            flexDirection: "row"
          }}>
          <View style={styles.data_content}>
            <View style={{ flexDirection: "row" }}>
              <Text style={styles.lbl}>Plate Number : </Text>
              <Text style={styles.lbl}>
                {thousands_separators(arrData.plateno)}
              </Text>
            </View>
            <View style={{ flexDirection: "row" }}>
              <Text style={styles.lbl}>Year Model : </Text>
              <Text style={styles.lbl}>{arrData.year}</Text>
            </View>

            <View style={{ flexDirection: "row" }}>
              <Text style={styles.lbl}>Make : </Text>
              <Text style={styles.lbl}>{arrData.make}</Text>
            </View>

            <View style={{ flexDirection: "row" }}>
              <Text style={styles.lbl}>Model : </Text>
              <Text style={styles.lbl}>{arrData.model}</Text>
            </View>
            <View style={{ flexDirection: "row" }}>
              <Text style={styles.lbl}>Engine : </Text>
              <Text style={styles.lbl}>{arrData.engine}</Text>
            </View>
            <View style={{ flexDirection: "row" }}>
              <Text style={styles.lbl}>Transmission :</Text>
              <Text style={styles.lbl}>{arrData.transmission}</Text>
            </View>
            <View style={{ flexDirection: "row" }}>
              <Text style={styles.lbl}>DOP : </Text>
              <Text style={styles.lbl}>{arrData.purchasedate}</Text>
            </View>
            <View style={{ flexDirection: "row" }}>
              <Text style={styles.lbl}>CurrentMileage: </Text>
              <Text style={styles.lbl}>
                {thousands_separators(arrData.mileage)} KM
              </Text>
            </View>
          </View>
        </View>
        <View style={styles.lineSeperator}></View>
        <View>
          <Text
            style={{
              fontFamily: "OpenSans-Regular",
              fontSize: 16,
              color: "white",
              padding: 0.05 * screen.width
            }}>
            {isPmsBelowHundreds
              ? "Your warranty is 100,000KM it is highly recommended to visit your authorized dealerships for your maintenance needs. Consult your owners manual for proper guidance." +
                `Your next maintenance schedule is ON or BEFORE ${strDate} OR when you reach ${thousands_separators(
                  pms
                )} KM whichever comes first.`
              : `Your next maintenance schedule is ON or BEFORE ${strDate} OR when you reach ${thousands_separators(
                  pms
                )} KM whichever comes first.`}
          </Text>
        </View>
        <View style={styles.lineSeperator}></View>
        <View style={{ marginBottom: 40 }}>
          <Text
            style={{
              fontFamily: "OpenSans-Regular",
              fontSize: 16,
              color: "white",
              padding: 0.05 * screen.width
            }}>
            Your next maintenance requires replacement of the following parts:
          </Text>
          {isPmsMajor ? (
            <View>
              <Text style={styles.lblList}>1. Engine oil</Text>
              <Text style={styles.lblList}>2. Oil filter</Text>
              <Text style={styles.lblList}>3. Flushing (optional)</Text>
              <Text style={styles.lblList}>4. Air Filter</Text>
              <Text style={styles.lblList}>5. Cabin Filter</Text>
              <Text style={styles.lblList}>6. Coolant</Text>
              <Text style={styles.lblList}>7. Break Fluid</Text>
              <Text style={styles.lblList}>8. Power Steering Fluid</Text>
              <Text style={styles.lblList}>9. Break Steering Fluid</Text>
            </View>
          ) : (
            <View>
              <Text style={styles.lblList}>1. Engine oil</Text>
              <Text style={styles.lblList}>2. Oil filter</Text>
              <Text style={styles.lblList}>3. Flushing (optional)</Text>
              {/* <Text
                style={{
                  fontFamily: "OpenSans-Regular",
                  fontSize: 0.02 * screen.height,
                  color: "white",
                  padding: 0.03 * screen.width
                }}>
                Inspection, checking, cleaning and adjustments of the following
                parts:
              </Text>
              <Text style={styles.lblList}>- Brake pads</Text>
              <Text style={styles.lblList}>- Brake fluids</Text> */}
            </View>
          )}
        </View>
      </View>
      <TouchableOpacity
        style={[buttonStyle.btn.btnDarkBlue, { elevation: 6 }]}
        onPress={() =>
          navigation.navigate("PMSRequestScreen", {
            arrData: arrData,
            isPmsMajor: isPmsMajor
          })
        }>
        <Text style={buttonStyle.btn.lblBtnDarkBlue}>VIEW MY OPTIONS</Text>
      </TouchableOpacity>
      <View style={{ marginBottom: 60 }}></View>
    </ScrollView>
  );
};

// define your styles
const styles = StyleSheet.create({
  container: {
    // alignItems: "center",
    backgroundColor: colors.blue_backgroud
  },
  data_content: {
    width: "100%",
    height: "100%",
    padding: 0.02 * screen.height
  },
  lbl: {
    fontFamily: "OpenSans-Regular",
    color: "white",
    fontSize: 16,
    width: "50%"
  },
  edit: {
    width: "45%",
    height: 40,
    backgroundColor: colors.dark_blue,
    borderTopLeftRadius: 20,
    borderBottomLeftRadius: 20,
    alignItems: "center",
    justifyContent: "center"
  },
  delete: {
    width: "45%",
    height: 40,
    backgroundColor: "red",
    borderTopRightRadius: 20,
    borderBottomRightRadius: 20,
    alignItems: "center",
    justifyContent: "center"
  },
  lblEditDelete: {
    fontFamily: "OpenSans-Regular",
    color: "white"
  },
  lineSeperator: {
    backgroundColor: "white",
    width: "100%",
    height: 2
  },
  lblList: {
    fontFamily: "OpenSans-Regular",
    color: "white",
    marginLeft: 20,
    fontSize: 16,
    paddingBottom: 0.01 * screen.height
  }
});

//make this component available to the app
export default index;
