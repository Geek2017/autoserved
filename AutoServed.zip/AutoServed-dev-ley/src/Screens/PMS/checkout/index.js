//import liraries
import React, { useEffect, useState } from "react";
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  ActivityIndicator,
  Image,
  TouchableOpacity
} from "react-native";
import { QuotesList, SubmitButton } from "../../../Components";
import { colors, images, screen } from "../../../../constant";
import { inject, observer } from "mobx-react";
import { CommonActions } from "@react-navigation/native";
import _ from "lodash";
import buttonStyle from "../../../../constant/buttonStyle";
import mainStyle from "../../../../constant/mainStyle";
import { capitalizeFirstLetter } from "../../../Helper";
import moment from "moment";

function thousands_separators(num) {
  if (!num) {
    return "";
  }
  var newNstr = num.toString().replace(",", "");
  var num_parts = newNstr.toString().split(".");
  num_parts[0] = num_parts[0].replace(/\B(?=(\d{3})+(?!\d))/g, ",");
  return num_parts.join(".");
}
const index = ({ navigation, store, route }) => {
  const [selectedIndex, setSelectedIndex] = useState();
  const { arrData, priceData, qoutesData } = route.params;

  const arrReplacement = store.allQoutesIndividual
    ? store.allQoutesIndividual[0].for_replacement.split(",")
    : [];

  let jsonReplacement = {};
  let total;
  let pricingCheck = priceData ? priceData : [];
  pricingCheck.map((item) => {
    total =
      parseInt(item.airfilter ? item.airfilter : 0) +
      parseInt(item.cabinfilter ? item.cabinfilter : 0) +
      parseInt(item.coolant ? item.coolant : 0) +
      parseInt(item.engineoil ? item.engineoil : 0) +
      parseInt(item.flushing ? item.flushing : 0) +
      parseInt(item.labor ? item.labor : 0) +
      parseInt(item.oilfilter ? item.oilfilter : 0) +
      parseInt(item.bsf ? item.bsf : 0) +
      parseInt(item.sparkplug ? item.sparkplug : 0) +
      parseInt(item.breakfluid ? item.breakfluid : 0) +
      parseInt(item.psf ? item.psf : 0);
  });

  pricingCheck.map((item) => {
    jsonReplacement["Engine Oil"] = item.engineoil ? item.engineoil : 0;
    jsonReplacement["Oil Filter"] = item.oilfilter ? item.oilfilter : 0;
    jsonReplacement["Flushing"] = item.flushing ? item.flushing : 0;
    jsonReplacement["Air Filter"] = item.airfilter ? item.airfilter : 0;
    jsonReplacement["Spark plugs"] = item.sparkplug ? item.sparkplug : 0;
    jsonReplacement["Cabin Filter"] = item.cabinfilter ? item.cabinfilter : 0;
    jsonReplacement["Coolant"] = item.coolant ? item.coolant : 0;
    jsonReplacement["Brake Fluid"] = item.breakfluid ? item.breakfluid : 0;
    jsonReplacement["Power Steering Fluid"] = item.psf ? item.psf : 0;
    jsonReplacement["Brake Cleaner"] = item.bsf ? item.bsf : 0;
    jsonReplacement["Labor"] = item.labor ? item.labor : 0;
  });
  const CarDetails = ({ title, content }) => {
    return (
      <View style={{ flexDirection: "row" }}>
        <Text
          style={[
            mainStyle.main.subtleText,
            {
              color: "#428EE2",
              fontSize: 16,
              lineHeight: 20,
              width: "40%"
            }
          ]}>
          {title} :
        </Text>
        <Text
          style={[
            mainStyle.main.subtleText,
            {
              color: "#428EE2",
              fontSize: 16,
              lineHeight: 20,
              width: "60%"
            }
          ]}>
          {content}
        </Text>
      </View>
    );
  };

  const PriceText = ({ title, content }) => {
    return (
      <View
        style={{
          flexDirection: "row"
        }}>
        <Text
          style={[
            mainStyle.main.Bold,
            {
              color: colors.another_blue,
              fontSize: 18,
              lineHeight: 20
            }
          ]}>
          {title} :{" "}
        </Text>
        <Text
          style={[
            mainStyle.main.subtleText,
            {
              color: colors.font_text_color,
              fontSize: 18,
              lineHeight: 20
            }
          ]}>
          ₱ {thousands_separators(content)}
        </Text>
      </View>
    );
  };

  return (
    <ScrollView style={{ flex: 1, backgroundColor: colors.blue_backgroud }}>
      <View
        style={{
          justifyContent: "center",
          alignItems: "center",
          paddingTop: 8
        }}>
        <View style={styles.container}>
          <View style={styles.content_one}>
            <Text
              style={[
                mainStyle.main.Body,
                { color: colors.font_text_color, fontSize: 32 }
              ]}>
              Payment Successful!
            </Text>
            <Text
              style={[
                mainStyle.main.subtleText,
                { color: colors.font_text_color, fontSize: 16 }
              ]}>
              {`Confirmation No. \n 2021 0101 001`}
            </Text>
          </View>
          <View style={styles.seperator}></View>

          <View style={styles.content_two}>
            <CarDetails title="Year Model" content={store.car.year} />
            <CarDetails title="Make" content={store.car.make} />
            <CarDetails title="Model" content={store.car.model} />
            <CarDetails title="Engine" content={store.car.engine} />
            <CarDetails title="Transmission" content={store.car.transmission} />
            <CarDetails
              title="Date Of purchase"
              content={store.car.purchasedate}
            />
            <CarDetails
              title="Current Milleage"
              content={thousands_separators(store.car.mileage)}
            />
          </View>
          <View style={styles.seperator}></View>
          <View style={styles.content_two}>
            <View
              style={{ flexDirection: "row", justifyContent: "space-between" }}>
              <View style={{ flexDirection: "row", alignItems: "center" }}>
                <Text
                  style={[
                    mainStyle.main.Bold,
                    { color: colors.another_blue, fontSize: 18 }
                  ]}>
                  Vehicle Type :{" "}
                </Text>
                <Text
                  style={[
                    mainStyle.main.subtleText,
                    { color: colors.font_text_color, fontSize: 18 }
                  ]}>
                  {qoutesData.cartype}
                </Text>
              </View>

              <View style={{ flexDirection: "row", alignItems: "center" }}>
                <Text
                  style={[
                    mainStyle.main.Bold,
                    { color: colors.another_blue, fontSize: 18 }
                  ]}>
                  PMS Type :{" "}
                </Text>
                <Text
                  style={[
                    mainStyle.main.subtleText,
                    { color: colors.font_text_color, fontSize: 18 }
                  ]}>
                  {capitalizeFirstLetter(qoutesData.pms)}
                </Text>
              </View>
            </View>

            <View
              style={{
                alignItems: "center",
                justifyContent: "center",
                paddingTop: 16
              }}>
              <PriceText
                title="Total Labor Cost"
                content={jsonReplacement["Labor"]}
              />
              {arrReplacement.map((item) => (
                <PriceText title={item} content={jsonReplacement[item]} />
              ))}
            </View>

            <View>
              <View
                style={{
                  flexDirection: "row",
                  alignItems: "center",
                  justifyContent: "center",
                  paddingTop: 32
                }}>
                <Text
                  style={[
                    mainStyle.main.Header2,
                    { color: colors.another_blue, fontSize: 24 }
                  ]}>
                  Amount Paid
                </Text>
                <Text
                  style={[
                    mainStyle.main.Header2,
                    { color: colors.another_blue, fontSize: 16 }
                  ]}>
                  (₱ {total ? thousands_separators(total) : 0})
                </Text>
              </View>
              <Text
                style={[
                  mainStyle.main.Header2,
                  {
                    color: colors.another_blue,
                    fontSize: 10,
                    alignSelf: "center",
                    paddingTop: 8
                  }
                ]}>
                {moment().format("MMMM Do YYYY, h:mm:ss a")}
              </Text>
            </View>
          </View>
        </View>
      </View>
      <View style={{ marginBottom: 70 }}></View>
    </ScrollView>
  );
};

// define your styles
const styles = StyleSheet.create({
  container: {
    width: "85%",
    backgroundColor: "white",
    borderRadius: 15,
    shadowColor: "#000",
    shadowOffset: {
      width: 0,
      height: 2
    },
    shadowOpacity: 0.25,
    shadowRadius: 3.84,
    elevation: 5
  },
  lblAmount: {
    fontFamily: "OpenSans-Regular",
    fontSize: 0.04 * screen.height,
    color: "white"
  },
  lbl: {
    fontFamily: "OpenSans-Regular",
    fontSize: 0.02 * screen.height,
    color: "white"
  },
  seperator: {
    borderWidth: 2,
    borderColor: colors.blue_backgroud,
    marginVertical: 8
  },
  content_one: {
    alignItems: "center",
    paddingTop: 16,
    marginHorizontal: 8
  },
  content_two: {
    paddingVertical: 8,
    marginHorizontal: 8
  }
});

//make this component available to the app
export default inject("store")(observer(index));
