//import liraries
import React, { useEffect, useState } from "react";
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  ActivityIndicator,
  Image,
  TouchableOpacity
} from "react-native";
import { QuotesList, SubmitButton } from "../../../Components";
import { colors, images, screen } from "../../../../constant";
import { inject, observer } from "mobx-react";
import { CommonActions } from "@react-navigation/native";
import _ from "lodash";
import buttonStyle from "../../../../constant/buttonStyle";
import mainStyle from "../../../../constant/mainStyle";
function thousands_separators(num) {
  var newNstr = num.toString().replace(",", "");
  var num_parts = newNstr.toString().split(".");
  num_parts[0] = num_parts[0].replace(/\B(?=(\d{3})+(?!\d))/g, ",");
  return num_parts.join(".");
}
const index = ({ navigation, store, route }) => {
  const [selectedIndex, setSelectedIndex] = useState();
  const { arrData, priceData, qoutesData } = route.params;
  let qoutesPms =
    qoutesData.pms == "minor" ? "pms_minor_price" : "pms_major_price";

  let total;
  let pricingCheck = priceData ? priceData : [];
  pricingCheck.map((item) => {
    total =
      parseInt(item.airfilter ? item.airfilter : 0) +
      parseInt(item.cabinfilter ? item.cabinfilter : 0) +
      parseInt(item.coolant ? item.coolant : 0) +
      parseInt(item.engineoil ? item.engineoil : 0) +
      parseInt(item.flushing ? item.flushing : 0) +
      parseInt(item.labor ? item.labor : 0) +
      parseInt(item.oilfilter ? item.oilfilter : 0) +
      parseInt(item.bsf ? item.bsf : 0) +
      parseInt(item.sparkplug ? item.sparkplug : 0) +
      parseInt(item.breakfluid ? item.breakfluid : 0) +
      parseInt(item.psf ? item.psf : 0);
  });

  const acceptShops = () => {
    let data = store.allQoutesIndividual[0];
    let sqr_byArr = data.sqr_by.split(",");
    const find = (element) => element == arrData.mobileno;
    var index = sqr_byArr.findIndex(find);
    let sqr_stateArr = data.sqr_state.split(",").fill(0);
    sqr_stateArr[index] = 3;
    fetch(
      `https://lj2e11f6r1.execute-api.ap-southeast-1.amazonaws.com/autoserved/qoutes/1`,
      {
        method: "PATCH",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify({
          ...data,
          sqr_state: sqr_stateArr.toString(),
          stats: 0
        })
      }
    )
      .then((response) => {
        let newPricing = pricingCheck[0];
        newPricing["status"] = 1;
        fetch(
          `https://lj2e11f6r1.execute-api.ap-southeast-1.amazonaws.com/autoserved/mqoutes/1`,
          {
            method: "PATCH",
            headers: {
              "Content-Type": "application/json"
            },
            body: JSON.stringify(newPricing)
          }
        ).then((response) => {
          console.log("resp:", response);
          // alert("Thank you for using our service");
          navigation.navigate("PMSCheckoutScreen", {
            arrData: arrData,
            priceData: priceData,
            qoutesData: qoutesData
          });
        });
      })
      .catch((error) => {
        console.error("Error:", error);
      });
  };

  return (
    <ScrollView style={{ flex: 1, backgroundColor: colors.blue_backgroud }}>
      <View
        style={{
          justifyContent: "center",
          alignItems: "center",
          paddingTop: 8
        }}>
        <View style={styles.container}>
          <View
            style={{
              alignItems: "center",
              justifyContent: "center",
              height: "25%"
            }}>
            <Text
              style={[
                mainStyle.main.Header2,
                { fontSize: 32, color: "white" }
              ]}>
              PHP. 0.0
            </Text>
            <Text style={styles.lbl}>Prepaid account balance</Text>
          </View>
          <View
            style={{
              borderWidth: 1,
              borderColor: "white",
              height: 1
            }}></View>

          {/* 2nd */}

          <View
            style={{
              alignItems: "center",
              justifyContent: "center",
              height: "25%"
            }}>
            <Text
              style={[
                mainStyle.main.Header2,
                { fontSize: 32, color: "white" }
              ]}>
              PHP. 0.0
            </Text>
            <Text style={styles.lbl}>Amount to be paid</Text>
            <Text style={styles.lbl}>
              (Php. {total ? thousands_separators(total) : 0}.00)
            </Text>
          </View>
          {/*  */}

          {/* 3rd */}
          <View
            style={{
              alignItems: "center",
              height: "50%",
              backgroundColor: "white",
              borderBottomEndRadius: 15,
              borderBottomStartRadius: 15
            }}>
            <Text
              style={[
                mainStyle.main.small,
                { paddingVertical: 16, color: colors.font_text_color }
              ]}>
              Load with
            </Text>
            <Image
              source={{
                uri:
                  "https://upload.wikimedia.org/wikipedia/commons/9/9a/PayMaya_Logo.png"
              }}
              style={{ width: 184, height: 67 }}
            />
            <Image
              source={{
                uri:
                  "https://s3.amazonaws.com/apple-platypus-production/assets/attachments/5df2/2077/6f75/3236/bbd7/9a1e/original/GCash_Horizontal_-_Full_Blue_%28Transparent%29.png?1576149111"
              }}
              style={{ width: 184, height: 67 }}
            />
            <Image
              source={{
                uri:
                  "https://miro.medium.com/max/800/1*pn1vv3DNwMCUZeXem1C4nQ.png"
              }}
              style={{ width: 250, height: 67 }}
            />
          </View>

          {/* Btn */}
        </View>
        <View
          style={{
            zIndex: 20,
            flexDirection: "row",
            justifyContent: "center",
            top: -20,
            width: "100%",
            elevation: 5
          }}>
          <TouchableOpacity
            style={buttonStyle.btn.btnTwoEdit}
            onPress={() => {
              acceptShops();
            }}>
            <Text style={buttonStyle.btn.lblTwoBtn}>PAY NOW</Text>
          </TouchableOpacity>
          <TouchableOpacity
            style={buttonStyle.btn.btnTwoDelete}
            onPress={() => {
              acceptShops();
            }}>
            <Text style={buttonStyle.btn.lblTwoBtn}>PAY ON SHOPS</Text>
          </TouchableOpacity>
        </View>
      </View>
      <View style={{ marginBottom: 90 }}></View>
    </ScrollView>
  );
};

// define your styles
const styles = StyleSheet.create({
  container: {
    width: "85%",
    height: 670,
    backgroundColor: colors.blue_backgroud_secondary,
    borderRadius: 15,
    shadowColor: "#000",
    shadowOffset: {
      width: 0,
      height: 2
    },
    shadowOpacity: 0.25,
    shadowRadius: 3.84,
    elevation: 5
  },
  lblAmount: {
    fontFamily: "OpenSans-Regular",
    fontSize: 0.04 * screen.height,
    color: "white"
  },
  lbl: {
    fontFamily: "OpenSans-Regular",
    fontSize: 0.02 * screen.height,
    color: "white"
  }
});

//make this component available to the app
export default inject("store")(observer(index));
