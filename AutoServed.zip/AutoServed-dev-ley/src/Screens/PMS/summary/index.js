//import liraries
import React, { Component } from "react";
import {
  View,
  Text,
  StyleSheet,
  Image,
  TouchableOpacity,
  ScrollView
} from "react-native";
import { screen, colors, icons } from "../../../../constant";
import Icon from "react-native-vector-icons/Feather";
import { SubmitButton } from "../../../Components";
import moment from "moment";
function thousands_separators(num) {
  var newNstr = num.toString().replace(",", "");
  var num_parts = newNstr.toString().split(".");
  num_parts[0] = num_parts[0].replace(/\B(?=(\d{3})+(?!\d))/g, ",");
  return num_parts.join(".");
}

// create a component
const index = ({ navigation, route }) => {
  const { arrData, replacement, prefSched, prefTypeShop } = route.params;

  return (
    <ScrollView
      style={styles.container}
      contentContainerStyle={{ alignItems: "center" }}>
      <View
        style={{
          width: 0.9 * screen.width,
          margin: 10,
          paddingHorizontal: 16,
          backgroundColor: "rgba(255,255,255,0.85)",
          borderRadius: 15,
          shadowColor: "#000",
          shadowOffset: {
            width: 0,
            height: 2
          },
          shadowOpacity: 0.25,
          shadowRadius: 3.84
        }}>
        {/* Header Text */}
        <View
          style={{
            justifyContent: "center",
            alignItems: "center"
          }}>
          <Text
            style={{
              fontFamily: "OpenSans-Regular",
              fontSize: 0.05 * screen.height,
              color: colors.another_blue,
              textAlign: "center"
            }}>
            Your request has been sent
          </Text>
          <Text
            style={{
              fontFamily: "OpenSans-Regular",
              fontSize: 0.02 * screen.height,
              color: colors.another_blue
            }}>
            Here`s the summary
          </Text>
        </View>
        {/* Car Info */}
        <View
          style={{
            justifyContent: "center",
            alignItems: "center",
            flexDirection: "row"
          }}>
          <View style={styles.data_content}>
            <View style={{ flexDirection: "row" }}>
              <Text style={styles.lbl}>Plate Number : </Text>
              <Text style={styles.lbl}>
                {thousands_separators(arrData.plateno)}
              </Text>
            </View>
            <View style={{ flexDirection: "row" }}>
              <Text style={styles.lbl}>Year Model : </Text>
              <Text style={styles.lbl}>{arrData.year}</Text>
            </View>
            <View style={{ flexDirection: "row" }}>
              <Text style={styles.lbl}>Make : </Text>
              <Text style={styles.lbl}>{arrData.make}</Text>
            </View>
            <View style={{ flexDirection: "row" }}>
              <Text style={styles.lbl}>Model : </Text>
              <Text style={styles.lbl}>{arrData.model}</Text>
            </View>
            <View style={{ flexDirection: "row" }}>
              <Text style={styles.lbl}>Engine : </Text>
              <Text style={styles.lbl}>{arrData.engine}</Text>
            </View>
            <View style={{ flexDirection: "row" }}>
              <Text style={styles.lbl}>Transmission :</Text>
              <Text style={styles.lbl}>{arrData.transmission}</Text>
            </View>
            <View style={{ flexDirection: "row" }}>
              <Text style={styles.lbl}>DOP : </Text>
              <Text style={styles.lbl}>{arrData.purchasedate}</Text>
            </View>
            <View style={{ flexDirection: "row" }}>
              <Text style={styles.lbl}>CurrentMileage: </Text>
              <Text style={styles.lbl}>
                {thousands_separators(arrData.mileage)} KM
              </Text>
            </View>
          </View>
        </View>
        <View style={{ marginBottom: 40 }}>
          <Text
            style={{
              fontFamily: "OpenSans-Regular",
              fontSize: 0.02 * screen.height,
              color: colors.another_blue,
              padding: 0.02 * screen.width
            }}>
            DATE OF REQUEST: {arrData.requestdate}
          </Text>
          {/* For Replacement */}
          <Text
            style={{
              fontFamily: "OpenSans-Regular",
              fontSize: 0.02 * screen.height,
              color: colors.another_blue,
              padding: 0.02 * screen.width
            }}>
            FOR REPLACEMENT:
          </Text>
          {replacement.map((item) => (
            <View>
              <Text style={styles.lblList}>
                - {item.title} -- {item.value}
              </Text>
            </View>
          ))}
          <Text
            style={{
              fontFamily: "OpenSans-Regular",
              fontSize: 0.02 * screen.height,
              color: colors.another_blue,
              padding: 0.02 * screen.width
            }}>
            PREFERRED SCHEDULES
          </Text>
          <View>
            {prefSched.map((item) => (
              <Text style={styles.lblList}>
                {moment(item.date).format("MMMM DD YYYY")}
              </Text>
            ))}
          </View>
          <Text
            style={{
              fontFamily: "OpenSans-Regular",
              fontSize: 0.02 * screen.height,
              color: colors.another_blue,
              padding: 0.02 * screen.width
            }}>
            PREFERRED TYPE OF SHOPS
          </Text>
          {prefTypeShop.map((item) => (
            <View>
              <Text style={styles.lblList}>
                {" "}
                - {item.title} -- {item.value}
              </Text>
            </View>
          ))}
        </View>
      </View>
      <View style={{ marginBottom: 50 }}>
        <SubmitButton
          title="VIEW QUOTES"
          inProfile
          onPress={() => navigation.navigate("PMSQoutesListScreen")}
        />
      </View>
      <View style={{ marginBottom: 60 }}></View>
    </ScrollView>
  );
};

// define your styles
const styles = StyleSheet.create({
  container: {
    // alignItems: "center",
    backgroundColor: colors.blue_backgroud
  },
  data_content: {
    width: "100%",
    height: "100%",
    padding: 0.02 * screen.height
  },
  lblList: {
    fontFamily: "OpenSans-Regular",
    color: colors.another_blue,
    marginLeft: 20,
    fontSize: 0.02 * screen.height,
    paddingBottom: 0.01 * screen.height
  },
  lbl: {
    fontFamily: "OpenSans-Regular",
    color: colors.another_blue,
    fontSize: 0.02 * screen.height,
    width: "50%"
  }
});

//make this component available to the app
export default index;
