//import liraries
import React, { useEffect } from "react";
import { View, Text, StyleSheet, ScrollView } from "react-native";
import { PMSCardList, SubmitButton } from "../../../Components";
import { colors, mainStyle, screen } from "../../../../constant";
import { inject, observer } from "mobx-react";
// create a component
const index = ({ navigation, store }) => {
  useEffect(() => {
    const unsubscribe = navigation.addListener("focus", () => {
      store.car = {};
      // store.getAllPrices();
    });
    return unsubscribe;
  }, [navigation]);
  const onHandle = async (data) => {
    store.car = data;
    store.allQoutesShopPrices = [];
    store.getIndividualQoutes(function (result) {
      if (result == "done") {
        if (store.allQoutesIndividual.length === 0) {
          // alert("true");
          navigation.navigate("PMSShowSCreen", { arrData: data });
        } else {
          navigation.navigate("PMSQoutesListScreen");
          // alert("false");
        }
      }
    });
  };

  return (
    <ScrollView style={{ flex: 1, backgroundColor: colors.blue_backgroud }}>
      <Text
        style={[
          mainStyle.main.Header2,
          { textAlign: "center", marginVertical: 8, fontSize: 32 }
        ]}>
        PICK A CAR FOR PMS
      </Text>
      <View style={styles.container}>
        {store.cars.map((data) => (
          <View key={Math.random()}>
            <PMSCardList arrData={data} navHandle={() => onHandle(data)} />
          </View>
        ))}
      </View>
      <View
        style={{
          alignItems: "center",
          justifyContent: "center"
        }}>
        <SubmitButton
          title="Add a Car"
          onPress={() => navigation.navigate("CreateCarScreen")}
          inProfile
        />
      </View>
      <View style={{ marginBottom: 110 }}></View>
    </ScrollView>
  );
};

// define your styles
const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: "center",
    backgroundColor: colors.blue_backgroud
  }
});

//make this component available to the app
export default inject("store")(observer(index));
