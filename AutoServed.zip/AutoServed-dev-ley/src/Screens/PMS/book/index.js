//import liraries
import React, { useEffect } from "react";
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity
} from "react-native";
import { QuotesList, SubmitButton } from "../../../Components";
import { colors, mainStyle, screen } from "../../../../constant";
import { inject, observer } from "mobx-react";
import moment from "moment";
import buttonStyle from "../../../../constant/buttonStyle";
function thousands_separators(num) {
  var newNstr = num.toString().replace(",", "");
  var num_parts = newNstr.toString().split(".");
  num_parts[0] = num_parts[0].replace(/\B(?=(\d{3})+(?!\d))/g, ",");
  return num_parts.join(".");
}

// create a component
const index = ({ navigation, store, route }) => {
  //   console.log(store.cars);
  const { arrData, qoutesData, priceData } = route.params;
  const arrReplacement = store.allQoutesIndividual
    ? store.allQoutesIndividual[0].for_replacement.split(",")
    : [];

  // const prefSchedule = store.allQoutesIndividual[0].preferedschedules.split(
  //   ","
  // );

  let jsonReplacement = {};
  const pricingCheck = priceData ? priceData : [];
  let total = 0;
  pricingCheck.map((item) => {
    jsonReplacement["Engine Oil"] = item.engineoil ? item.engineoil : 0;
    jsonReplacement["Oil Filter"] = item.oilfilter ? item.oilfilter : 0;
    jsonReplacement["Flushing"] = item.flushing ? item.flushing : 0;
    jsonReplacement["Air Filter"] = item.airfilter ? item.airfilter : 0;
    jsonReplacement["Spark plugs"] = item.sparkplug ? item.sparkplug : 0;
    jsonReplacement["Cabin Filter"] = item.cabinfilter ? item.cabinfilter : 0;
    jsonReplacement["Coolant"] = item.coolant ? item.coolant : 0;
    jsonReplacement["Brake Fluid"] = item.breakfluid ? item.breakfluid : 0;
    jsonReplacement["Power Steering Fluid"] = item.psf ? item.psf : 0;
    jsonReplacement["Brake Cleaner"] = item.bsf ? item.bsf : 0;
    jsonReplacement["Labor"] = item.labor ? item.labor : 0;
  });

  pricingCheck.map((item) => {
    total =
      parseInt(item.airfilter ? item.airfilter : 0) +
      parseInt(item.cabinfilter ? item.cabinfilter : 0) +
      parseInt(item.coolant ? item.coolant : 0) +
      parseInt(item.engineoil ? item.engineoil : 0) +
      parseInt(item.flushing ? item.flushing : 0) +
      parseInt(item.labor ? item.labor : 0) +
      parseInt(item.oilfilter ? item.oilfilter : 0) +
      parseInt(item.bsf ? item.bsf : 0) +
      parseInt(item.sparkplug ? item.sparkplug : 0) +
      parseInt(item.breakfluid ? item.breakfluid : 0) +
      parseInt(item.psf ? item.psf : 0);
  });

  useEffect(() => {
    store.getIndividualQoutes(function () {});
  }, []);

  return (
    <ScrollView style={{ flex: 1, backgroundColor: colors.blue_backgroud }}>
      <Text
        style={[
          mainStyle.main.Header2,
          { textAlign: "center", fontSize: 20, paddingVertical: 8 }
        ]}>
        BOOKING
      </Text>
      <View style={styles.container}>
        <View key={Math.random()}>
          <QuotesList
            arrData={arrData}
            qoutesData={qoutesData}
            navigation={navigation}
            priceData={priceData}
          />
          <View
            style={{
              width: 0.9 * screen.width,
              height: 1,
              borderColor: colors.another_blue,
              borderWidth: 1,
              marginBottom: 16
            }}></View>
        </View>

        {/* Car Info */}
        <View style={styles.data_content}>
          <View style={{ flexDirection: "row" }}>
            <Text style={styles.lbl}>Plate Number : </Text>
            <Text style={styles.lbl}>
              {thousands_separators(store.car.plateno)}
            </Text>
          </View>
          <View style={{ flexDirection: "row" }}>
            <Text style={styles.lbl}>Year Model : </Text>
            <Text style={styles.lbl}>{store.car.year}</Text>
          </View>
          <View style={{ flexDirection: "row" }}>
            <Text style={styles.lbl}>Make : </Text>
            <Text style={styles.lbl}>{store.car.make}</Text>
          </View>
          <View style={{ flexDirection: "row" }}>
            <Text style={styles.lbl}>Model : </Text>
            <Text style={styles.lbl}>{store.car.model}</Text>
          </View>
          <View style={{ flexDirection: "row" }}>
            <Text style={styles.lbl}>Engine : </Text>
            <Text style={styles.lbl}>{store.car.engine}</Text>
          </View>
          <View style={{ flexDirection: "row" }}>
            <Text style={styles.lbl}>Transmission :</Text>
            <Text style={styles.lbl}>{store.car.transmission}</Text>
          </View>
          <View style={{ flexDirection: "row" }}>
            <Text style={styles.lbl}>DOP : </Text>
            <Text style={styles.lbl}>{store.car.purchasedate}</Text>
          </View>
          <View style={{ flexDirection: "row" }}>
            <Text style={styles.lbl}>CurrentMileage: </Text>
            <Text style={styles.lbl}>
              {thousands_separators(store.car.mileage)} KM
            </Text>
          </View>
        </View>

        {/* End */}

        {/* For Replacement */}

        <View style={[styles.data_content, { marginTop: 16 }]}>
          <View style={{ flexDirection: "row" }}>
            <Text style={[styles.lblList, { width: "40%" }]}>
              DATE OF REQUEST:
            </Text>
            <Text style={[styles.lblList, { width: "40%" }]}>
              {store.allQoutesIndividual
                ? store.allQoutesIndividual[0].requestdate
                : ""}
            </Text>
          </View>
          {/* <View style={{ flexDirection: "row" }}>
            <Text style={[styles.lblList, { width: "40%" }]}>LABOR:</Text>
            <Text style={[styles.lblList, { width: "40%" }]}>
              PHP: {jsonReplacement["Labor"]}
            </Text>
          </View> */}
          <Text style={[styles.lblList, {}]}>FOR REPLACEMENT:</Text>
          {arrReplacement.map((item) => (
            <View style={{ flexDirection: "row", marginVertical: -4, top: -8 }}>
              <Text style={[styles.lblList, { width: "50%" }]}>- {item}</Text>
              <Text style={[styles.lblList, { width: "50%" }]}>
                PHP: {jsonReplacement[item]}
              </Text>
            </View>
          ))}
          <Text style={[styles.lblList, { fontSize: 32, fontWeight: "500" }]}>
            {`QUOTE AMOUNT: \nPHP. ${thousands_separators(total)}`}
          </Text>
        </View>
        <TouchableOpacity
          style={[buttonStyle.btn.btnDarkBlue, { top: 20 }]}
          onPress={() =>
            navigation.navigate("PMSPaymentScreen", {
              arrData: arrData,
              priceData: priceData,
              qoutesData: qoutesData
            })
          }>
          <Text style={buttonStyle.btn.lblBtnDarkBlue}>BOOK & PAY</Text>
        </TouchableOpacity>
      </View>
      <View style={{ marginBottom: 130 }}></View>
    </ScrollView>
  );
};

// define your styles
const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: "center",
    backgroundColor: "white",
    marginHorizontal: 16,
    borderRadius: 15,
    shadowColor: "#000",
    shadowOffset: {
      width: 0,
      height: 2
    },
    shadowOpacity: 0.25,
    shadowRadius: 3.84,
    elevation: 5
  },
  data_content: { paddingHorizontal: 16 },
  lbl: {
    fontFamily: "OpenSans-Regular",
    color: colors.another_blue,
    fontSize: 16,
    width: "50%"
  },
  lblList: {
    fontFamily: "OpenSans-Regular",
    color: colors.another_blue,
    marginLeft: 20,
    fontSize: 16,
    paddingBottom: 0.01 * screen.height
  }
});

//make this component available to the app
export default inject("store")(observer(index));
