//import liraries
import React, { Component } from "react";
import { View, Text, StyleSheet, Image, Linking } from "react-native";
import { colors, screen, icons } from "../../../../constant";
import { inject, observer } from "mobx-react";
import { CommonActions } from "@react-navigation/native";
// create a component
const index = ({ username, store, navigation }) => {
  const Logout = () => {
    navigation.dispatch(
      CommonActions.reset({
        index: 1,
        routes: [{ name: "SignInScreen" }]
      })
    );
    store.logout();
  };
  return (
    <View style={styles.container}>
      <Image style={{ width: 50, height: 50 }} source={icons.party_pop} />
      <Text style={styles.lbl}>
        {`We${"`"}ve reserved a spot for you ${
          store.profile.fullname
        }, will text / email you as soon as your account is ready. Thanks!`}
      </Text>
      <Text>{`\n`}</Text>
      <Text style={styles.lbl}>
        To learn more about AutoServed{" "}
        <Text
          style={{ color: "blue", fontFamily: "OpenSans-Regular" }}
          onPress={() => Linking.openURL("http://autoserved.com")}>
          click here{" "}
        </Text>
      </Text>
      <Text
        style={{
          color: "red",
          fontFamily: "OpenSans-Regular",
          fontSize: 0.03 * screen.height
        }}
        onPress={() => Logout()}>
        Exit{" "}
      </Text>
    </View>
  );
};

// define your styles
const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    backgroundColor: colors.blue_backgroud,
    padding: 40
  },
  lbl: {
    fontFamily: "OpenSans-Regular",
    fontSize: 0.025 * screen.height,
    textAlign: "center"
  }
});

export default inject("store")(observer(index));
