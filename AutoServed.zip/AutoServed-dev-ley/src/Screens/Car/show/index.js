//import liraries
import React, { Component } from "react";
import { View, Text, StyleSheet, ScrollView } from "react-native";
import { CarCardList, SubmitButton } from "../../../Components";
import { colors, mainStyle, screen } from "../../../../constant";
import { inject, observer } from "mobx-react";
// create a component
const index = ({ navigation, store }) => {
  //   console.log(store.cars);

  const deleteHandler = (plateno) => {
    store.deleteCarProfile(plateno);
  };

  return (
    <ScrollView style={{ flex: 1, backgroundColor: colors.blue_backgroud }}>
      <Text
        style={[
          mainStyle.main.Header2,
          { textAlign: "center", marginVertical: 8 }
        ]}>
        MY CAR PROFILE
      </Text>
      <View style={styles.container}>
        {store.cars.map((data) => (
          <View key={Math.random()}>
            <CarCardList
              arrData={data}
              navHandleEdit={() =>
                navigation.navigate("EditCarScreen", { arrData: data })
              }
              navHandleDelete={() => deleteHandler(data.plateno)}
            />
          </View>
        ))}
      </View>
      <View
        style={{
          alignItems: "center",
          justifyContent: "center"
        }}>
        <SubmitButton
          title="ADD A CAR"
          onPress={() => navigation.navigate("CreateCarScreen")}
          inProfile
        />
      </View>
      <View style={{ marginBottom: 115 }}></View>
    </ScrollView>
  );
};

// define your styles
const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: "center",
    backgroundColor: colors.blue_backgroud
  }
});

//make this component available to the app
export default inject("store")(observer(index));
