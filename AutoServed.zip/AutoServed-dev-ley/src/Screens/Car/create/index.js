//import liraries
import React, { useState, useEffect, useRef } from "react";
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  ScrollView,
  TextInput
} from "react-native";
import { colors, screen, carItems, mainStyle } from "../../../../constant";
import DatePicker from "react-native-date-picker";
import {
  CarTextField,
  SubmitButton,
  DropDownList,
  GoogleTextfield
} from "../../../Components";

import { inject, observer } from "mobx-react";
import { TextInputMask } from "react-native-masked-text";
import moment from "moment";
import DateTimePicker from "@react-native-community/datetimepicker";
import Geocoder from "react-native-geocoding";
function addCommas(nStr) {
  var newNstr = nStr.toString().replace(",", "");
  newNstr += "";
  var x = newNstr.split(".");
  var x1 = x[0];
  var x2 = x.length > 1 ? "." + x[1] : "";
  var rgx = /(\d+)(\d{3})/;
  while (rgx.test(x1)) {
    x1 = x1.replace(rgx, "$1" + "," + "$2");
  }
  return x1 + x2;
}
Geocoder.init("AIzaSyAuYmZ6xFjgvREwx9az-NPrlglHgDIPkN0");

// create a component
const index = ({ navigation, store }) => {
  const [date, setDate] = useState(null);
  const [isDateShow, setShowDate] = useState(false);
  const newDate = date ? moment(date).toJSON().substring(0, 10) : "";
  const [mileages, setmileage] = useState(0);

  useEffect(() => {
    const unsubscribe = navigation.addListener("focus", () => {
      setDate(null);
      setmileage(0);
      store.car = {};
    });
    return unsubscribe;
  }, [navigation]);

  const onHandleResult = (result) => {
    if (!result) {
      //
      navigation.navigate("ShowCarScreen");
    } else {
      alert(result);
    }
  };
  const onSubmit = () => {
    if (Object.keys(store.car).length < 12) {
      alert("Please complete the form");
      return;
    }
    store.createOrUpdateCar(onHandleResult);
  };

  const locationSaving = (address) => {
    store.car.location = address;
    Geocoder.from(address)
      .then((json) => {
        var location = json.results[0].geometry.location;
        store.car.lat = location.lat;
        store.car.long = location.lng;
        console.log(store.car.long);
      })
      .catch((error) => console.warn(error));
  };

  const onChange = (event, selectedDate) => {
    const currentDate = selectedDate || date;
    setShowDate(!isDateShow);
    setDate(currentDate);
    store.car.purchasedate = moment(currentDate).toJSON().substring(0, 10);
  };
  return (
    <View style={styles.container}>
      <ScrollView
        style={styles.content}
        // keyboardShouldPersistTaps={isKeyboardScrollView ? "never" : "always"}
        keyboardShouldPersistTaps="always"
        contentContainerStyle={{ alignItems: "center" }}>
        <Text
          style={[
            mainStyle.main.Header2,
            { textAlign: "center", fontSize: 32 }
          ]}>
          CREATE CAR PROFILE
        </Text>
        <GoogleTextfield
          onPress={(address) => locationSaving(address)}
          // onKeyboardShouldPersist={setKeyboardScrollView}
        />
        <TextInput
          placeholder="Year Model"
          style={styles.TextInputMask}
          onChangeText={(text) => (store.car.year = text)}
          keyboardType="numeric"
          value={store.car.year}
        />
        <TextInput
          placeholder="Brand"
          style={styles.TextInputMask}
          onChangeText={(text) => (store.car.make = text)}
          value={store.car.make}
        />
        <TextInput
          placeholder="Model"
          style={styles.TextInputMask}
          onChangeText={(text) => (store.car.model = text)}
          value={store.car.model}
        />
        <TextInput
          placeholder="Vehicle Type"
          style={styles.TextInputMask}
          onChangeText={(text) => (store.car.cartype = text)}
          value={store.car.cartype}
        />
        {/* <TextInput
          placeholder="Engine"
          style={styles.TextInputMask}
          onChangeText={(text) => (store.car.engine = text)}
        /> */}
        <DropDownList
          item={carItems.engine}
          placeholder="Engine"
          zIndex={96}
          setData={(text) => (store.car.engine = text.value)}
        />
        <DropDownList
          item={carItems.transmission}
          placeholder="Transmission"
          zIndex={95}
          setData={(text) => (store.car.transmission = text.value)}
        />
        {/* <TextInput
          placeholder="Transmission"
          style={styles.TextInputMask}
          onChangeText={(text) => (store.car.transmission = text)}
        /> */}
        {/* <DropDownList
          item={carItems.year}
          placeholder="Year Model"
          setData={(text) => (store.car.year = text.value)}
        />
        <DropDownList
          item={carItems.brand}
          placeholder="Brand"
          zIndex={100}
          setData={(text) => (store.car.make = text.value)}
        />
        <DropDownList
          item={carItems.model}
          placeholder="Model"
          zIndex={98}
          setData={(text) => (store.car.model = text.value)}
        />
        <DropDownList
          item={store.carType}
          placeholder="Vehicle Type"
          zIndex={97}
          setData={(text) => (store.car.cartype = text.value)}
          scrollViewProps={{
            persistentScrollbar: true
          }}
          autoScrollToDefaultValue
        />
        <DropDownList
          item={carItems.engine}
          placeholder="Engine"
          zIndex={96}
          setData={(text) => (store.car.engine = text.value)}
        />

        <DropDownList
          item={carItems.transmission}
          placeholder="Transmission"
          zIndex={95}
          setData={(text) => (store.car.transmission = text.value)}
        /> */}
        {/* Date */}
        <TouchableOpacity
          style={{
            backgroundColor: "#fafafa",
            borderRadius: 10,
            height: 40,
            width: 0.8 * screen.width,
            margin: 10,
            alignItems: "flex-start",
            justifyContent: "center"
          }}
          onPress={() => setShowDate(!isDateShow)}>
          <Text
            style={{
              paddingLeft: 20,
              textAlign: "left",
              color: colors.blue_backgroud
            }}>
            {date ? newDate : "Date Purchased"}
          </Text>
        </TouchableOpacity>
        {isDateShow ? (
          // <DatePicker
          //   date={date ? date : new Date()}
          //   mode="date"
          //   onDateChange={setDate}
          //   androidVariant="nativeAndroid"
          // />
          <DateTimePicker
            testID="dateTimePicker"
            value={date ? date : new Date()}
            mode="date"
            onChange={onChange}
            style={{
              width: 320,
              backgroundColor: "white"
            }}
          />
        ) : (
          <View></View>
        )}
        {/* Date End */}
        {/* <CarTextField
          placeholder="Current Millage/Km"
          isNumberPad
          setData={(text) => (store.car.mileage = text)}
        /> */}
        <Text style={(mainStyle.main.PreTitle, { color: colors.dark_blue })}>
          (Check vehicle certificate of registration to be sure)
        </Text>
        <TextInput
          placeholder="Current Millage/Km"
          style={styles.TextInputMask}
          value={mileages ? addCommas(mileages) : ""}
          onChangeText={(text) => {
            (store.car.mileage = text.replace(",", "")), setmileage(text);
          }}
          keyboardType="numeric"
        />
        <CarTextField
          placeholder="Plate Number"
          setData={(text) => (store.car.plateno = text)}
          defaultValue={store.car.plateno}
        />
        <View style={{ marginBottom: 50 }}>
          <SubmitButton title="SAVE" onPress={onSubmit} inProfile />
        </View>
      </ScrollView>
      <View style={{ marginBottom: 70 }}></View>
    </View>
  );
};

// define your styles
const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.blue_backgroud
  },
  content: {
    paddingTop: 40
  },
  TextInputMask: {
    backgroundColor: "#fafafa",
    borderRadius: 10,
    height: 40,
    width: 0.8 * screen.width,
    margin: 10,
    alignItems: "flex-start",
    justifyContent: "center",
    paddingLeft: 20,
    paddingRight: 20
  }
});

//make this component available to the app
export default inject("store")(observer(index));
