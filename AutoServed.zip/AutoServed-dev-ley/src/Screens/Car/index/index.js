//import liraries
import React, { useEffect, useState } from "react";
import {
  View,
  Text,
  StyleSheet,
  Image,
  ScrollView,
  TouchableOpacity
} from "react-native";
import { colors, images, screen, icons } from "../../../../constant";
import { inject, observer } from "mobx-react";
import { TextFieldLocation, Modal } from "../../../Components";
import { CircleView } from "../../../Components";
import FeatherIcon from "react-native-vector-icons/Feather";
import RNExitApp from "react-native-exit-app";
import { capitalizeFirstLetter } from "../../../Helper";
// create a component
const index = ({ navigation, store }) => {
  // const [isModal, setModalShow] = useState(false);
  useEffect(() => {
    store.getUserData();
    store.checkUserCar();
    store.getAllServices();
  }, []);

  const onHandleNav = () => {
    if (store.cars.length != 0) {
      navigation.navigate("PMSScreen");
    } else {
      navigation.navigate("CreateCarScreen");
    }
  };
  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity
          style={{
            position: "absolute",
            left: 10,
            top: 0.05 * screen.height,
            zIndex: 20
          }}
          onPress={() => navigation.openDrawer()}>
          <FeatherIcon name="menu" size={50} color={colors.dark_blue} />
        </TouchableOpacity>
        <Image
          source={images.card_home}
          style={{ width: screen.width, height: "100%" }}
        />
      </View>
      <View style={styles.floating_content}>
        <View style={styles.headerContent}>
          <Text
            style={[
              styles.secondaryHeaderLbl,
              { fontSize: screen.height * 0.035 }
            ]}>
            Welcome{" "}
            {capitalizeFirstLetter(
              store.profile.fullname
                ? store.profile.fullname.split(/(\s+)/)[0]
                : ""
            )}
          </Text>
          <Text style={styles.secondaryHeaderLbl}>
            What does your car needs done today?
          </Text>
          <View style={{ marginTop: 20 }}>
            <View
              style={{
                flexDirection: "row",
                width: "100%",
                justifyContent: "space-around",
                paddingBottom: 8
              }}>
              <Image
                source={images.ads}
                style={{ width: "100%", height: 100, borderRadius: 15 }}
              />
            </View>
            <TextFieldLocation />
          </View>
        </View>

        {/*  */}
        <ScrollView>
          <View style={styles.content}>
            <CircleView
              imageSrc={icons.pms}
              title={`Preventive Maintenance \n(PMS)`}
              handleNav={onHandleNav}
            />
            <CircleView imageSrc={icons.change_oil} title="Oil Change" isHide />
            <CircleView
              imageSrc={icons.cardiag}
              title="Inspection and Diagnosis"
              isHide
            />
            <CircleView imageSrc={icons.tires} title={`Tires`} isHide />
            <CircleView imageSrc={icons.battery} title="Battery" isHide />
            <CircleView
              imageSrc={icons.generalrepair}
              title={`General \n Repairs`}
              isHide
            />
            <CircleView
              imageSrc={icons.roadside}
              title={`Roadside \n Assistace`}
              isHide
            />
            <CircleView
              imageSrc={icons.bodypaint}
              title={`Body and \n Paint`}
              isHide
            />
            <CircleView
              imageSrc={icons.customer_messages}
              title={`Chat with a \n Service \n Advisor`}
              isHide
            />
          </View>
          <View style={{ marginBottom: screen.height * 0.05 }}></View>
        </ScrollView>
      </View>
    </View>
  );
};

// define your styles
const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.blue_backgroud
  },
  header: {
    flex: 0.25
  },
  floating_content: {
    backgroundColor: "rgba(255,255,255,0.85)",
    position: "absolute",
    margin: 20,
    left: 0,
    right: 0,
    top: 0.14 * screen.height,
    bottom: 0,
    borderRadius: 15,
    shadowColor: "#000",
    shadowOffset: {
      width: 0,
      height: 2
    },
    shadowOpacity: 0.25,
    shadowRadius: 3.84,
    height: screen.height * 0.7
  },
  headerContent: {
    zIndex: 10,
    padding: 20,
    justifyContent: "center",
    alignItems: "center"
  },
  welcomeLbl: {
    fontFamily: "OpenSans-Regular",
    fontSize: 0.05 * screen.height,
    color: colors.blue_backgroud_secondary
  },
  secondaryHeaderLbl: {
    fontFamily: "OpenSans-Regular",
    fontSize: 0.02 * screen.height,
    color: colors.blue_backgroud_secondary
  },
  content: {
    flexDirection: "row",
    flexWrap: "wrap",
    justifyContent: "center"
  }
});

//make this component available to the app
export default inject("store")(observer(index));
