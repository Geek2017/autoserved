//import liraries
import React, { useState, useEffect } from "react";
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  ScrollView,
  TextInput
} from "react-native";
import { colors, screen, carItems, mainStyle } from "../../../../constant";
import DatePicker from "react-native-date-picker";
import DateTimePicker from "@react-native-community/datetimepicker";
import {
  CarTextField,
  SubmitButton,
  DropDownList,
  GoogleTextfield
} from "../../../Components";
import { inject, observer } from "mobx-react";
import moment from "moment";
import Geocoder from "react-native-geocoding";
function addCommas(nStr) {
  var newNstr = nStr.toString().replace(",", "");
  newNstr += "";
  var x = newNstr.split(".");
  var x1 = x[0];
  var x2 = x.length > 1 ? "." + x[1] : "";
  var rgx = /(\d+)(\d{3})/;
  while (rgx.test(x1)) {
    x1 = x1.replace(rgx, "$1" + "," + "$2");
  }
  return x1 + x2;
}

Geocoder.init("AIzaSyAuYmZ6xFjgvREwx9az-NPrlglHgDIPkN0");

const index = ({ navigation, store, route }) => {
  const { arrData } = route.params;
  const [date, setDate] = useState(null);
  const [isDateShow, setShowDate] = useState(false);
  const [mileages, setmileage] = useState(0);
  // const newDate = date ? moment(date).toJSON().substring(0, 10) : "";

  useEffect(() => {
    const unsubscribe = navigation.addListener("focus", () => {
      store.car = {};
      store.car = arrData;
    });
    return unsubscribe;
  }, [navigation]);
  const onHandleResult = (result) => {
    if (!result) {
      navigation.navigate("ShowCarScreen");
    } else {
      alert(result);
    }
  };
  const onSubmit = () => {
    if (Object.keys(store.car).length < 10) {
      alert("Please complete the form");
      return;
    }
    console.log(store.car);

    store.createOrUpdateCar(onHandleResult);
  };

  const locationSaving = (address) => {
    store.car.location = address;
    Geocoder.from(address)
      .then((json) => {
        var location = json.results[0].geometry.location;
        store.car.lat = location.lat;
        store.car.long = location.lng;
      })
      .catch((error) => console.warn(error));
  };

  const onChange = (event, selectedDate) => {
    const currentDate = selectedDate || date;
    setShowDate(!isDateShow);
    setDate(currentDate);
    store.car.purchasedate = moment(currentDate).toJSON().substring(0, 10);
  };
  return (
    <View style={styles.container}>
      <ScrollView
        style={styles.content}
        keyboardShouldPersistTaps="always"
        contentContainerStyle={{ alignItems: "center" }}>
        <Text
          style={[
            mainStyle.main.Header2,
            { textAlign: "center", fontSize: 32 }
          ]}>
          EDIT CAR PROFILE
        </Text>
        {/* <CarTextField
          defaultValue={arrData.location}
          placeholder="Address"
          setData={(text) => (store.car.location = text)}
        /> */}
        <GoogleTextfield
          onPress={(address) => locationSaving(address)}
          defaultValue={arrData.location}
          // onKeyboardShouldPersist={setKeyboardScrollView}
        />
        <TextInput
          placeholder="Year Model"
          style={styles.TextInputMask}
          onChangeText={(text) => (store.car.year = text)}
          keyboardType="numeric"
          defaultValue={arrData.year}
        />
        <TextInput
          placeholder="Brand"
          style={styles.TextInputMask}
          onChangeText={(text) => (store.car.make = text)}
          defaultValue={arrData.make}
        />
        <TextInput
          placeholder="Model"
          style={styles.TextInputMask}
          onChangeText={(text) => (store.car.model = text)}
          defaultValue={arrData.model}
        />
        <TextInput
          placeholder="Vehicle Type"
          style={styles.TextInputMask}
          onChangeText={(text) => (store.car.cartype = text)}
          defaultValue={arrData.cartype}
        />
        {/* <DropDownList
          value={arrData.year}
          item={carItems.year}
          placeholder="Year Model"
          setData={(text) => (store.car.year = text.value)}
        />
        <DropDownList
          value={arrData.make}
          item={carItems.brand}
          placeholder="Brand"
          zIndex={100}
          setData={(text) => (store.car.make = text.value)}
        />
        <DropDownList
          value={arrData.model}
          item={carItems.model}
          placeholder="Model"
          zIndex={98}
          setData={(text) => (store.car.model = text.value)}
        />
        <DropDownList
          value={arrData.cartype}
          item={store.carType}
          placeholder="Vehicle Type"
          zIndex={97}
          setData={(text) => (store.car.cartype = text.value)}
        />*/}
        <DropDownList
          item={carItems.engine}
          placeholder="Engine"
          value={arrData.engine}
          zIndex={96}
          setData={(text) => (store.car.engine = text.value)}
        />
        <DropDownList
          item={carItems.transmission}
          placeholder="Transmission"
          value={arrData.transmission}
          zIndex={95}
          setData={(text) => (store.car.transmission = text.value)}
        />
        {/* Date */}
        <TouchableOpacity
          style={{
            backgroundColor: "#fafafa",
            borderRadius: 10,
            height: 40,
            width: 0.8 * screen.width,
            margin: 10,
            alignItems: "flex-start",
            justifyContent: "center"
          }}
          onPress={() => setShowDate(!isDateShow)}>
          <Text
            style={{
              paddingLeft: 20,
              textAlign: "left",
              color: colors.blue_backgroud
            }}>
            {date
              ? moment(date).toJSON().substring(0, 10)
              : arrData.purchasedate}
          </Text>
        </TouchableOpacity>
        {isDateShow ? (
          // <DatePicker
          //   date={new Date()}
          //   mode="date"
          //   onDateChange={setDate}
          //   androidVariant="nativeAndroid"
          // />
          <DateTimePicker
            testID="dateTimePicker"
            value={date ? date : new Date()}
            mode="date"
            style={{
              width: 320,
              backgroundColor: "white"
            }}
            onChange={onChange}
          />
        ) : (
          <View></View>
        )}
        {/* Date End */}
        <TextInput
          placeholder="Current Millage/Km"
          style={styles.TextInputMask}
          value={mileages ? addCommas(mileages) : addCommas(arrData.mileage)}
          onChangeText={(text) => {
            (store.car.mileage = text.replace(",", "")), setmileage(text);
          }}
          keyboardType="numeric"
        />
        <CarTextField
          defaultValue={arrData.plateno}
          placeholder="Plate Number"
          setData={(text) => (store.car.plateno = text)}
        />
        <View style={{ marginBottom: 50 }}>
          <SubmitButton title="SAVE" onPress={onSubmit} inProfile />
        </View>
      </ScrollView>
      <View style={{ marginBottom: 70 }}></View>
    </View>
  );
};

// define your styles
const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.blue_backgroud
  },
  content: {
    paddingTop: 40
  },
  TextInputMask: {
    backgroundColor: "#fafafa",
    borderRadius: 10,
    height: 40,
    width: 0.8 * screen.width,
    margin: 10,
    alignItems: "flex-start",
    justifyContent: "center",
    paddingLeft: 20,
    paddingRight: 20
  }
});

//make this component available to the app
export default inject("store")(observer(index));
