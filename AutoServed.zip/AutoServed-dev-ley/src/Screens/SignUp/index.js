//import liraries
import React, { useReducer, useState } from "react";
import {
  View,
  Text,
  StyleSheet,
  Image,
  TouchableOpacity,
  ScrollView,
  Alert
} from "react-native";
import CheckBox from "@react-native-community/checkbox";
import { colors, icons, screen, images } from "../../../constant";
import {
  TextFieldRegular,
  SubmitButton,
  TextFieldNumberSignIn
} from "../../Components";
import FontAwesome from "react-native-vector-icons/FontAwesome5";

import { registration, generateOTP } from "../../Services/Auth";
import { inject, observer } from "mobx-react";

const index = ({ navigation, store }) => {
  let { profile } = store;
  const [isSelected, setSelection] = useState(false);

  const img =
    profile.usertype == "individual"
      ? images.card_signin_one
      : profile.usertype == "shop"
      ? images.card_signin_two
      : profile.usertype == "business"
      ? images.card_signin_three
      : images.card_signin_one;

  const signUpResult = (result) => {
    if (result.status != 200) {
      Alert.alert("ERROR 404");
    } else {
      store.generateOTP();
      navigation.navigate("OTPScreen", { fromLogin: true });
    }
  };

  function signUp() {
    profile.state = "pending";
    profile.points = "1000";
    profile.mobileno =
      "+63" +
      profile?.mobileno
        ?.match(/^(0|\+63)\d{10}|^(9)\d{9}$/gm)?.[0]
        ?.replace(/^(0|\+63)/gm, "");

    if (!isSelected) {
      Alert.alert("Please agree to terms.");
      return;
    }

    if (profile.mobileno?.length == 13) {
      store.register(signUpResult);
      return;
    }
    alert("Invalid PH number!");
  }

  return (
    <View style={styles.container}>
      <ScrollView>
        <View style={styles.first_content}>
          <TouchableOpacity
            style={{
              position: "absolute",
              left: 16,
              paddingHorizontal: 16,
              paddingTop: 40,
              zIndex: 10
            }}
            onPress={() => navigation.goBack()}>
            <FontAwesome
              name="chevron-left"
              size={24}
              color={colors.blue_backgroud_secondary}
            />
          </TouchableOpacity>
          <Image source={img} style={styles.logo} resizeMode="contain" />

          {/* Input Text */}
          <View style={{ marginTop: 0.05 * screen.height }}>
            {profile.usertype == "shop" ? (
              <TextFieldRegular
                placeholder="Name of Shop"
                setData={(text) => (profile.shopname = text)}
              />
            ) : profile.usertype == "business" ? (
              <TextFieldRegular
                placeholder="Business Name"
                setData={(text) => (profile.bizname = text)}
              />
            ) : (
              <View></View>
            )}
            <TextFieldRegular
              placeholder="Last, First Name"
              setData={(text) => (profile.fullname = text)}
            />
            <TextFieldRegular
              placeholder="juan@delecruz.ph"
              setData={(text) => (profile.email = text)}
            />
            <View style={{ marginBottom: 20 }}>
              <TextFieldNumberSignIn
                setMobileNumber={(text) => (profile.mobileno = text)}
              />
            </View>
          </View>
          {/* End Input */}

          {/*  */}
          <View style={styles.threeBtnStyle}>
            <TouchableOpacity
              style={[
                styles.left,
                {
                  backgroundColor:
                    profile.usertype != "individual"
                      ? "white"
                      : colors.dark_blue
                }
              ]}
              onPress={() => {
                profile.usertype = "individual";
              }}>
              <Text
                style={{
                  fontFamily: "OpenSans-Bold",
                  color:
                    profile.usertype != "individual"
                      ? colors.blue_backgroud_secondary
                      : "white"
                }}>
                Individual
              </Text>
            </TouchableOpacity>
            <TouchableOpacity
              style={[
                styles.center,
                {
                  backgroundColor:
                    profile.usertype != "shop" ? "white" : colors.dark_blue
                }
              ]}
              onPress={() => {
                profile.usertype = "shop";
              }}>
              <Text
                style={{
                  fontFamily: "OpenSans-Bold",
                  color:
                    profile.usertype != "shop"
                      ? colors.blue_backgroud_secondary
                      : "white"
                }}>
                Shop
              </Text>
            </TouchableOpacity>
            <TouchableOpacity
              style={[
                styles.right,
                {
                  backgroundColor:
                    profile.usertype != "business" ? "white" : colors.dark_blue
                }
              ]}
              onPress={() => {
                profile.usertype = "business";
              }}>
              <Text
                style={{
                  fontFamily: "OpenSans-Bold",
                  color:
                    profile.usertype != "business"
                      ? colors.blue_backgroud_secondary
                      : "white"
                }}>
                Business
              </Text>
            </TouchableOpacity>
          </View>
          <View style={styles.checkboxContainer}>
            <CheckBox
              value={isSelected}
              onValueChange={setSelection}
              style={styles.checkbox}
              tintColor="black"
              onCheckColor="white"
              tintColors={{ true: "white", false: "black" }}
            />
            <Text style={styles.label}>
              I agree with the Terms & Conditions and Privacy Policy
            </Text>
          </View>
        </View>
      </ScrollView>
      <View style={styles.second_content}>
        <SubmitButton title="Sign Up" onPress={signUp} />
      </View>
    </View>
  );
};

// define your styles
const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    backgroundColor: colors.blue_backgroud_secondary
  },
  first_content: {
    flex: 0.7,
    alignItems: "center",
    width: "100%"
    // backgroundColor: "cyan"
  },
  logo: {
    width: screen.width,
    height: 157
  },
  second_content: {
    height: 100,
    backgroundColor: "white",
    width: "100%",
    justifyContent: "center",
    alignItems: "center"
  },
  threeBtnStyle: {
    backgroundColor: "white",
    width: 0.85 * screen.width,
    height: 50,
    borderRadius: 70,
    borderWidth: 1,
    borderColor: colors.blue_backgroud_secondary,
    fontSize: 18,
    color: colors.font_text_color,
    marginBottom: 20,
    flexDirection: "row"
  },
  left: {
    backgroundColor: colors.dark_blue,
    width: "33%",
    height: "100%",
    borderTopLeftRadius: 20,
    borderBottomLeftRadius: 20,
    alignItems: "center",
    justifyContent: "center"
  },
  center: {
    backgroundColor: colors.dark_blue,
    width: "33%",
    height: "100%",
    alignItems: "center",
    justifyContent: "center"
  },
  right: {
    backgroundColor: colors.dark_blue,
    width: "35%",
    height: "100%",
    borderTopRightRadius: 20,
    borderBottomRightRadius: 20,
    alignItems: "center",
    justifyContent: "center"
  },
  checkboxContainer: {
    flexDirection: "row",
    marginBottom: 20,
    width: 0.9 * screen.width,
    paddingLeft: 20,
    paddingRight: 20,
    alignItems: "center"
  },
  checkbox: {
    alignSelf: "flex-start"
  },
  label: {
    fontFamily: "OpenSans-Regular",
    color: "white",
    paddingLeft: 10
  }
});

//make this component available to the app
export default inject("store")(observer(index));
