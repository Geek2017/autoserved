//import liraries
import React, { useEffect, useState } from "react";
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  ActivityIndicator,
  TouchableOpacity
} from "react-native";
import { QuotesListMaintenance, SubmitButton } from "../../Components";
import { buttonStyle, colors, mainStyle, screen } from "../../../constant";
import { inject, observer } from "mobx-react";
import { Button } from "react-native-elements";
import moment from "moment";
import { Alert } from "react-native";
function thousands_separators(num) {
  var newNstr = num.toString().replace(",", "");
  var num_parts = newNstr.toString().split(".");
  num_parts[0] = num_parts[0].replace(/\B(?=(\d{3})+(?!\d))/g, ",");
  return num_parts.join(".");
}

// create a component
const index = ({ navigation, store }) => {
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const unsubscribe = navigation.addListener("focus", () => {
      // store.getAllPrices();
      store.allQoutesShopPrices = [];
      store.allQoutesIndividual = [];
      store.getConfirmQoutesForIndividual();
    });
    // Return the function to unsubscribe from the event so it gets removed on unmount
    return unsubscribe;
  }, [navigation]);

  // console.log(store.allQoutesShopPrices[0]);
  return (
    <ScrollView style={{ flex: 1, backgroundColor: colors.blue_backgroud }}>
      {store.fetching ? (
        <ActivityIndicator color="grey" size={30} />
      ) : (
        <View>
          {store.allQoutesIndividual.map((item, index) => {
            let index_sqr_state = item.sqr_state.split(",").indexOf("3");
            let sqrArr = item.sqr_by.split(",")[index_sqr_state];
            console.log("allShops", store.allShops);
            return (
              <View style={styles.container}>
                <View key={Math.random()}>
                  <QuotesListMaintenance
                    arrData={
                      store.allShops
                        ? store.allShops.filter((e) => e.mobileno == sqrArr)[0]
                        : []
                    }
                    threeBtn
                    qoutesData={item}
                    priceData={store.allQoutesShopPrices[0]}
                  />
                  <View
                    style={{
                      width: 0.9 * screen.width,
                      height: 1,
                      borderColor: colors.another_blue,
                      borderWidth: 1
                    }}></View>
                </View>

                {/* Car Info */}
                <View style={[styles.data_content, { marginVertical: 16 }]}>
                  <View style={{ flexDirection: "row" }}>
                    <Text style={styles.lbl}>Plate Number : </Text>
                    <Text style={styles.lbl}>
                      {thousands_separators(item.plateno)}
                    </Text>
                  </View>
                  <View style={{ flexDirection: "row" }}>
                    <Text style={styles.lbl}>Year Model : </Text>
                    <Text style={styles.lbl}>{item.year}</Text>
                  </View>
                  <View style={{ flexDirection: "row" }}>
                    <Text style={styles.lbl}>Make : </Text>
                    <Text style={styles.lbl}>{item.make}</Text>
                  </View>
                  <View style={{ flexDirection: "row" }}>
                    <Text style={styles.lbl}>Model : </Text>
                    <Text style={styles.lbl}>{item.model}</Text>
                  </View>
                  <View style={{ flexDirection: "row" }}>
                    <Text style={styles.lbl}>Engine : </Text>
                    <Text style={styles.lbl}>{item.engine}</Text>
                  </View>
                  <View style={{ flexDirection: "row" }}>
                    <Text style={styles.lbl}>Transmission :</Text>
                    <Text style={styles.lbl}>{item.transmission}</Text>
                  </View>
                  <View style={{ flexDirection: "row" }}>
                    <Text style={styles.lbl}>DOP : </Text>
                    <Text style={styles.lbl}>{item.purchasedate}</Text>
                  </View>
                  <View style={{ flexDirection: "row" }}>
                    <Text style={styles.lbl}>CurrentMileage: </Text>
                    <Text style={styles.lbl}>
                      {thousands_separators(item.mileage)} KM
                    </Text>
                  </View>
                </View>
                <View
                  style={{
                    width: 0.9 * screen.width,
                    height: 1,
                    borderColor: colors.another_blue,
                    borderWidth: 1
                  }}></View>
                {/* End */}

                {/* For Replacement */}

                <View style={[styles.data_content, { marginVertical: 16 }]}>
                  <View style={{ flexDirection: "row" }}>
                    <Text style={[styles.lblList, { width: "40%" }]}>
                      DATE OF REQUEST:
                    </Text>
                    <Text style={[styles.lblList, { width: "40%" }]}>
                      {item.preferedschedules.split(",").map((item, index) => {
                        return `${moment(item).format(
                          "MMMM DD, YYYY"
                        )} ${"\n"}`;
                      })}
                    </Text>
                  </View>

                  <Text style={[styles.lblList, {}]}>FOR REPLACEMENT:</Text>
                  {item.for_replacement.split(",").map((item) => (
                    <View
                      style={{
                        flexDirection: "row",
                        marginVertical: -4,
                        top: -8
                      }}>
                      <Text style={[styles.lblList, { width: "50%" }]}>
                        - {item}
                      </Text>
                      <Text style={[styles.lblList, { width: "50%" }]}>
                        {/* PHP: {jsonReplacement[item]} */}
                      </Text>
                    </View>
                  ))}

                  <Text
                    style={[
                      styles.lblList,
                      { fontSize: 32, fontWeight: "500" }
                    ]}>
                    {/* {`QUOTE AMOUNT: \nPHP. ${thousands_separators(total)}`} */}
                  </Text>
                </View>
                {/* End */}
                {/* <TouchableOpacity
                  style={[
                    buttonStyle.btn.btnDarkBlue,
                    {
                      alignSelf: "center",
                      backgroundColor:
                        item.sqr_state == 3
                          ? colors.dark_blue
                          : item.sqr_state == 4
                          ? colors.dark_blue
                          : "#B2BFDB"
                    }
                  ]}> */}
                <Text
                  style={[
                    buttonStyle.btn.lblBtnDarkBlue,
                    {
                      fontSize:
                        item.sqr_state == 3
                          ? 16
                          : item.sqr_state == 4
                          ? 14
                          : 30,
                      color: colors.another_blue
                    }
                  ]}>
                  {item.sqr_state == 3
                    ? "WAITING FOR SHOP TO CONFIRM"
                    : item.sqr_state == 4
                    ? "APPOINTMENT HAS BEEN RESCHEDULE"
                    : "CONFIRMED"}
                </Text>
                {/* </TouchableOpacity> */}
              </View>
            );
          })}
          {store.allQoutesIndividual.length == 0 ? (
            <View
              style={{ height: screen.height / 2, justifyContent: "center" }}>
              <Text
                style={[
                  mainStyle.main.Header3,
                  {
                    width: screen.width * 0.9,
                    textAlign: "center",
                    fontSize: 40
                  }
                ]}>
                YOU HAVE NO SCHEDULE
              </Text>
            </View>
          ) : (
            <View />
          )}
        </View>
      )}
      <View style={{ marginBottom: 120 }}></View>
    </ScrollView>
  );
};

// define your styles
const styles = StyleSheet.create({
  container: {
    alignItems: "center",
    backgroundColor: "white",
    marginHorizontal: 16,
    marginTop: 16,
    borderRadius: 15,
    shadowColor: "#000",
    shadowOffset: {
      width: 0,
      height: 2
    },
    shadowOpacity: 0.25,
    shadowRadius: 3.84
  },
  data_content: {
    paddingHorizontal: 16
  },
  lbl: {
    fontFamily: "OpenSans-Regular",
    color: colors.another_blue,
    fontSize: 16,
    width: "50%"
  },
  lblList: {
    fontFamily: "OpenSans-Regular",
    color: colors.another_blue,
    marginLeft: 20,
    fontSize: 16,
    paddingBottom: 0.01 * screen.height
  }
});

//make this component available to the app
export default inject("store")(observer(index));
