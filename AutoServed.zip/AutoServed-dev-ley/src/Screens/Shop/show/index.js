import React, { useEffect, useState } from "react";
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  ActivityIndicator,
  TouchableOpacity,
  Image
} from "react-native";
import { inject, observer } from "mobx-react";
import { colors, mainStyle, screen } from "../../../../constant";
import { SubmitButton } from "../../../Components";

const index = ({ navigation, store }) => {
  console.log(store.shops.logo);
  return (
    <ScrollView
      // ref={(ref) => (this.listView = ref)}
      // onContentSizeChange={() => {
      //   this.listView.scrollTo({ y: 0 });
      // }}
      style={{
        flex: 1,
        backgroundColor: colors.blue_backgroud
      }}>
      <View style={{ alignItems: "center" }}>
        <Text
          style={[
            mainStyle.main.Header2,
            { textAlign: "center", fontSize: 32 }
          ]}>
          Shop Profile
        </Text>
        <View style={styles.container}>
          {/* HEader */}
          <View style={[styles.container_header]}>
            <Image
              style={{
                height: 150,
                width: "100%",
                borderTopRightRadius: 15,
                borderTopLeftRadius: 15
              }}
              source={{ uri: store.shops.shop_frontimg }}
            />
            <Image
              style={{
                height: 75,
                width: 75,
                top: -0.045 * screen.height,
                borderRadius: 100,
                marginLeft: 20
              }}
              source={{ uri: store.shops.logo }}
            />
          </View>
          {/* Content */}
          <View
            style={{
              justifyContent: "center",
              alignItems: "center",
              flexDirection: "row"
            }}>
            <View style={styles.data_content}>
              {/* <Text style={styles.lbl}>Location:{store.shops.}</Text> */}
              <Text style={styles.lbl}>Shop Name: {store.shops.shop_name}</Text>
              <Text style={styles.lbl}>
                Business Name: {store.shops.bizname}
              </Text>
              <Text style={styles.lbl}>
                Street Address: {store.shops.stadd}
              </Text>
              <Text style={styles.lbl}>Baranggay: {store.shops.brgy}</Text>
              <Text style={styles.lbl}>City: {store.shops.city}</Text>
              <Text style={styles.lbl}>Region: {store.shops.region}</Text>
              <Text style={styles.lbl}>
                Owner/Main Contact Person: {store.shops.owner_contactperson}
              </Text>
              <Text style={styles.lbl}>
                Phone No. of Main Contact Person:
                {store.shops.owner_contactperson_no}
              </Text>
              <Text style={styles.lbl}>
                Business Phone No.: {store.shops.biz_no}
              </Text>
              <Text style={styles.lbl}>Email: {store.shops.email}</Text>
              <Text style={styles.lbl}>FB Page.: {store.shops.fbpage}</Text>
              <Text style={styles.lbl}>
                FB Messenger/WhatsApp: {store.shops.fb_messenger}
              </Text>
              <Text style={styles.lbl}>Website: {store.shops.website}</Text>
              <Text style={styles.lbl}>Days Open: {store.shops.daysopen}</Text>
              <Text style={styles.lbl}>
                Hours Open: {store.shops.operationhrs}
              </Text>
              <Text style={styles.lbl}>Business Permit (attached)</Text>
              <Text style={styles.lbl}>BIR Certificate (attached)</Text>
              <Text style={styles.lbl}>Logo (attached)</Text>
              <Text style={styles.lbl}>Shop Frontage (attached)</Text>
              <Text style={styles.lbl}>Services offered:</Text>
              <Text style={styles.lbl}>
                Tools & Equipment: LIFTERS, ALIGNMENT
              </Text>
              <Text style={styles.lbl}>Tech Certifications NC2, NC3</Text>
            </View>
          </View>
        </View>
        <View style={{ paddingTop: 16 }}>
          <SubmitButton title="EDIT" inProfile />
        </View>
      </View>
      <View style={{ marginBottom: 120 }}></View>
    </ScrollView>
  );
};

// define your styles
const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: "center",
    backgroundColor: "white",
    borderRadius: 15,
    shadowColor: "#000",
    shadowOffset: {
      width: 0,
      height: 2
    },
    shadowOpacity: 0.25,
    shadowRadius: 3.84
  },
  data_content: {
    width: 0.9 * screen.width,
    height: "100%",
    padding: 10
  },
  container_header: {
    height: 150,
    width: 0.9 * screen.width,
    backgroundColor: "black",
    marginBottom: 30,
    borderTopLeftRadius: 15,
    borderTopRightRadius: 15
  },
  lbl: {
    fontFamily: "OpenSans-Regular",
    color: colors.font_text_color,
    fontSize: 0.02 * screen.height
  }
});

export default inject("store")(observer(index));
