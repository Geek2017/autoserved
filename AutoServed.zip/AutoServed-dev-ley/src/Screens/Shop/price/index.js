import React, { useEffect, useState } from "react";
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  ActivityIndicator
} from "react-native";
import { inject, observer } from "mobx-react";
import { colors, screen } from "../../../../constant";
import { Button } from "react-native-elements";
import TextInputMask from "react-native-text-input-mask";
import _ from "lodash";
// create a component
function removeDuplicates(data, key) {
  return [...new Map(data.map((item) => [key(item), item])).values()];
}
const index = ({ navigation, store }) => {
  const [isLoading, setLoading] = useState(1);
  const [arrService, setArr] = useState([]);
  const [jsonPrice, setJsonPrice] = useState({});
  useEffect(() => {
    setArr(store.allservices);
  }, []);

  const handleBtnPress = () => {
    store.multiplePrices = store.tempArrPrices;
    store.createMultiplePrices();
    alert("Successfully created");
    navigation.goBack();
  };

  const jsonHandler = () => {
    let json = store.tempObjPrices;
    let id = json.serviceid;
    var index = _.findIndex(store.tempArrPrices, { serviceid: id });
    if (index != -1) {
      var obj = store.tempArrPrices[index];
      _.merge(obj, json);
      store.tempArrPrices.splice(index, 1, obj);
      //   console.log(store.tempArrPrices);
    } else {
      store.tempArrPrices = [...store.tempArrPrices, store.tempObjPrices];
    }
  };
  return (
    <ScrollView
      style={{
        backgroundColor: colors.blue_backgroud
      }}>
      {arrService.length ? (
        <View
          style={{
            justifyContent: "center",
            alignItems: "center"
          }}>
          <View
            style={{
              paddingLeft: 30,
              paddingBottom: 10,
              alignSelf: "flex-start"
            }}>
            <Text style={styles.headerLbl}>Price Set-Up - LABOR</Text>
          </View>
          <View style={styles.data_content}>
            <Text
              style={[
                styles.headerLbl,
                { fontSize: 0.02 * screen.height, paddingBottom: 10 }
              ]}>
              PMS MAJOR:
            </Text>
            <View style={{ flexDirection: "row", flexWrap: "wrap" }}>
              <View style={{ width: "100%", flexDirection: "row" }}>
                <View style={{ width: "40%", paddingBottom: 10 }}>
                  <Text style={styles.lbl}>VEHICLE TYPE:</Text>
                </View>
                <View style={{ width: "30%", paddingBottom: 10 }}>
                  <Text style={styles.lbl}>MINOR PMS:</Text>
                </View>
                <View style={{ width: "30%", paddingBottom: 10 }}>
                  <Text style={styles.lbl}>MAJOR PMS:</Text>
                </View>
              </View>
              {[...arrService]
                .sort((a, b) => a.id - b.id)
                .map((item) => {
                  return (
                    <View style={{ flexDirection: "row", flexWrap: "wrap" }}>
                      <View style={{ width: "40%", paddingBottom: 10 }}>
                        <Text style={styles.lbl}>
                          {item.id}
                          {". "}
                          {item.service}
                        </Text>
                      </View>
                      <View style={{ width: "30%", paddingBottom: 10 }}>
                        <TextInputMask
                          refInput={(ref) => {
                            this.input = ref;
                          }}
                          keyboardType="number-pad"
                          style={{
                            width: 0.2 * screen.width,
                            height: 0.05 * screen.height,
                            backgroundColor: "white",
                            borderRadius: 50,
                            paddingRight: 10,
                            paddingLeft: 10
                          }}
                          onChangeText={(formatted, extracted) => {
                            store.tempObjPrices = {
                              pms_minor_price: extracted,
                              serviceid: item.id,
                              shopid: store.profile.mobileno
                            };
                            jsonHandler();
                          }}
                          mask={"₱ [0000000]"}
                        />
                      </View>
                      <View style={{ width: "30%", paddingBottom: 10 }}>
                        <TextInputMask
                          refInput={(ref) => {
                            this.input = ref;
                          }}
                          keyboardType="number-pad"
                          style={{
                            width: 0.2 * screen.width,
                            height: 0.05 * screen.height,
                            backgroundColor: "white",
                            borderRadius: 50,
                            paddingRight: 10,
                            paddingLeft: 10
                          }}
                          onChangeText={(formatted, extracted) => {
                            store.tempObjPrices = {
                              pms_major_price: extracted,
                              serviceid: item.id,
                              shopid: store.profile.mobileno
                            };
                            jsonHandler();
                          }}
                          mask={"₱ [0000000]"}
                        />
                      </View>
                    </View>
                  );
                })}
            </View>

            {/* 2nd */}
            <Text
              style={[
                styles.headerLbl,
                { fontSize: 0.02 * screen.height, paddingBottom: 10 }
              ]}>
              CHANGE OIL LABOR:
            </Text>
            <View style={{ flexDirection: "row", flexWrap: "wrap" }}>
              <View style={{ width: "100%", flexDirection: "row" }}>
                <View style={{ width: "40%", paddingBottom: 10 }}>
                  <Text style={styles.lbl}>VEHICLE TYPE:</Text>
                </View>
              </View>
              {[...arrService]
                .sort((a, b) => a.id - b.id)
                .map((item) => {
                  return (
                    <View style={{ flexDirection: "row", flexWrap: "wrap" }}>
                      <View style={{ width: "50%", paddingBottom: 10 }}>
                        <Text style={styles.lbl}>
                          {item.id}
                          {". "}
                          {item.service}
                        </Text>
                      </View>
                      <View style={{ width: "50%", paddingBottom: 10 }}>
                        <TextInputMask
                          refInput={(ref) => {
                            this.input = ref;
                          }}
                          keyboardType="number-pad"
                          style={{
                            width: 0.2 * screen.width,
                            height: 0.05 * screen.height,
                            backgroundColor: "white",
                            borderRadius: 50
                          }}
                          onChangeText={(formatted, extracted) => {
                            store.tempObjPrices = {
                              change_oil_price: extracted,
                              serviceid: item.id,
                              shopid: store.profile.mobileno
                            };
                            jsonHandler();
                          }}
                          mask={"₱ [0000000]"}
                        />
                      </View>
                    </View>
                  );
                })}
            </View>
            {/* end */}
            <Button
              onPressIn={() => handleBtnPress()}
              title="Save"
              containerStyle={{
                borderRadius: 70,
                marginTop: 10,
                top: 0.02 * screen.height
              }}
              buttonStyle={{
                backgroundColor: colors.dark_blue,
                height: 0.06 * screen.height
              }}
            />
          </View>
          <View style={{ paddingBottom: 35 }}></View>
        </View>
      ) : (
        <ActivityIndicator color="grey" style={{ flex: 1 }} size={30} />
      )}
    </ScrollView>
  );
};

// define your styles
const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: "center",
    backgroundColor: colors.blue_backgroud,
    paddingTop: 10
  },
  data_content: {
    width: "85%",
    paddingLeft: 20,
    paddingRight: 10,
    backgroundColor: colors.font_text_color
  },
  headerLbl: {
    fontSize: 0.025 * screen.height,
    fontFamily: "OpenSans-Regular",
    color: "white"
  },
  lbl: {
    fontFamily: "OpenSans-Regular",
    color: "white"
  }
});

export default inject("store")(observer(index));
