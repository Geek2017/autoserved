//import liraries
import React, { useEffect, useState } from "react";
import {
  View,
  Text,
  StyleSheet,
  Image,
  ScrollView,
  TouchableOpacity
} from "react-native";
import { colors, images, screen, icons, mainStyle } from "../../../../constant";
import { inject, observer } from "mobx-react";
import { CircleView, Modal, TextFieldLocation } from "../../../Components";
import { useIsFocused } from "@react-navigation/native";
import FeatherIcon from "react-native-vector-icons/Feather";
// create a component
const index = ({ navigation, store }) => {
  const [isModal, setModalShow] = useState(false);
  const isFocused = useIsFocused();
  useEffect(() => {
    store.checkUserShop(checkUseShop);
    store.getUserData();
    store.getAllServices();
    // store.getAllPricesByShop();
    store.getQuotesConfirmedShops();
  }, []);

  const checkUseShop = (result) => {
    if (!result.isShopExist) {
      setModalShow(true);
    } else {
      store.getShopData();
    }
  };
  const onHandleNav = (route) => {
    if (store.shops.approval == "approve") {
      navigation.navigate(route);
    } else {
      // navigation.reset({ index: 0, routes: [{ name: "CreateCarScreen" }] });
      // navigation.navigate("CreateCarScreen");
    }
  };
  return (
    <View style={styles.container}>
      <Modal
        cancelHide
        modalShow={isModal}
        title="Shop"
        btnTitle="proceed"
        setModalShow={setModalShow}
        content="Please create a shop"
        handle={() => {
          navigation.navigate("ShopCreateScreen"), setModalShow(false);
        }}
        isShopCreation
      />
      <View style={styles.header}>
        <TouchableOpacity
          style={{
            position: "absolute",
            left: 10,
            top: 0.05 * screen.height,
            zIndex: 20
          }}
          onPress={() => navigation.openDrawer()}>
          <FeatherIcon name="menu" size={50} color={colors.dark_blue} />
        </TouchableOpacity>
        <Image
          source={images.card_home}
          style={{ width: screen.width, height: "100%" }}
        />
      </View>
      <View style={styles.floating_content}>
        <View style={styles.headerContent}>
          <Text style={styles.welcomeLbl}>Welcome {store.shops.shop_name}</Text>
          <Text style={styles.secondaryHeaderLbl}>
            Tara! Gawin nating busy ang shop mo!
          </Text>
          {/* Ads */}
          <View
            style={{
              flexDirection: "row",
              width: "100%",
              justifyContent: "space-around"
            }}>
            <Image
              source={images.ads}
              style={{ width: "100%", height: 100, borderRadius: 15 }}
            />
          </View>
        </View>

        {/*  */}
        <ScrollView>
          <View style={styles.content}>
            <CircleView
              imageSrc={icons.services_offered}
              title={`Services \n Offered`}
              handleNav={() => onHandleNav("ShopServicesScreen")}
            />

            <CircleView
              imageSrc={icons.price_setup}
              title="Price Set - Up"
              handleNav={() => onHandleNav("ShopPriceScreen")}
              isHide
            />
            <CircleView
              imageSrc={icons.customer_messages}
              title={`Customer \n Messages`}
              isHide
            />
            <CircleView
              imageSrc={icons.car_shop}
              title={`Car in \n Shop`}
              isHide
            />
            <CircleView imageSrc={icons.sales} title="Sales" isHide />
            <CircleView
              imageSrc={icons.reminders}
              title={`Due for \n Reminders`}
              isHide
            />
            <CircleView
              imageSrc={icons.warranty}
              title={`Warranty \n Expiring`}
              isHide
            />
            <CircleView
              imageSrc={icons.backjob}
              title={`Back Job \n Comeback`}
              isHide
            />
            <CircleView
              imageSrc={icons.shop_management}
              title={`Shop \n Management \n System`}
              isHide
            />
          </View>
        </ScrollView>
        <View style={{ paddingBottom: 30 }}></View>
      </View>
    </View>
  );
};

// define your styles
const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.blue_backgroud
  },
  header: {
    flex: 0.25
  },
  floating_content: {
    backgroundColor: "rgba(255,255,255,0.85)",
    position: "absolute",
    margin: 20,
    left: 0,
    right: 0,
    top: 0.14 * screen.height,
    bottom: 0,
    borderRadius: 15,
    shadowColor: "#000",
    shadowOffset: {
      width: 0,
      height: 2
    },
    shadowOpacity: 0.25,
    shadowRadius: 3.84,
    height: screen.height * 0.7
  },
  headerContent: {
    zIndex: 10,
    padding: 20,
    justifyContent: "center",
    alignItems: "center"
  },
  welcomeLbl: {
    fontFamily: "OpenSans-Regular",
    fontSize: 28,
    color: colors.blue_backgroud_secondary
  },
  secondaryHeaderLbl: {
    fontFamily: "OpenSans-Regular",
    fontSize: 16,
    paddingBottom: 8,
    color: colors.blue_backgroud_secondary
  },
  content: {
    flexDirection: "row",
    flexWrap: "wrap",
    justifyContent: "center"
  },
  lblHeaderView: {
    fontFamily: "OpenSans-Regular",
    color: "white",
    fontSize: 0.012 * screen.height
  }
});

//make this component available to the app
export default inject("store")(observer(index));
