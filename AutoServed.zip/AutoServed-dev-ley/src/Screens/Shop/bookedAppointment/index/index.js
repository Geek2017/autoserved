import React, { useEffect, useState } from "react";
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  ActivityIndicator,
  TouchableOpacity,
  RefreshControl,
  FlatList
} from "react-native";
import { inject, observer } from "mobx-react";
import {
  BookedAppointmentCardList,
  SubmitButton
} from "../../../../Components";
import { colors, mainStyle, screen } from "../../../../../constant";
import { v4 as uuidv4 } from "uuid";
import _ from "lodash";

const index = ({ navigation, store }) => {
  useEffect(() => {
    const unsubscribe = navigation.addListener("focus", () => {
      store.mqoutes = {};
      store.shopQoutesRecieve = [];
      store.qoutesStatusShop = [];
      store.allQoutesShopPrices = [];
      store.getBookedQoutesForShop();
    });
    return unsubscribe;
  }, [navigation]);

  const confirmQoute = (item) => {
    fetch(
      `https://lj2e11f6r1.execute-api.ap-southeast-1.amazonaws.com/autoserved/qoutes/${item.index}`,
      {
        method: "PATCH",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify({ ...item, sqr_state: 5 })
      }
    )
      .then((response) => {
        store.mqoutes = {};
        store.shopQoutesRecieve = [];
        store.qoutesStatusShop = [];
        store.allQoutesShopPrices = [];
        store.getBookedQoutesForShop();
        console.log("Sucess", response);
        // callback();
      })
      .catch((error) => {
        // callback("" + error);
        console.error("Error:", error);
      });
  };
  console.log(store.shopQoutesBooked.length);
  return (
    <View
      // refreshControl={
      //   <RefreshControl refreshing={refreshing} onRefresh={onRefresh} />
      // }
      style={{
        flex: 1,
        backgroundColor: colors.blue_backgroud
      }}>
      <View style={styles.container}>
        {store.fetching ? (
          <ActivityIndicator color="grey" size={30} />
        ) : store.shopQoutesBooked.length != 0 ? (
          <FlatList
            showsVerticalScrollIndicator={false}
            style={{ flex: 1 }}
            // refreshControl={
            //   <RefreshControl refreshing={refreshing} onRefresh={onRefresh} />
            // }
            data={store.shopQoutesBooked}
            renderItem={({ item, index }) => {
              let priceData = store.allQoutesShopPrices[0]
                ? store.allQoutesShopPrices[0].filter((e) => e.qid == item.id)
                : [];
              return (
                <View>
                  <BookedAppointmentCardList
                    arrData={item}
                    status={3}
                    priceData={priceData}
                    onPressDecline={() =>
                      navigation.navigate("ShopBookedQoutesDeclineScreen", {
                        item: item
                      })
                    }
                    onPressQuote={() => confirmQoute(item)}
                  />
                </View>
              );
            }}
            keyExtractor={(item) => uuidv4()}
          />
        ) : (
          <View style={{ height: screen.height / 2, justifyContent: "center" }}>
            <Text
              style={[
                mainStyle.main.Header3,
                {
                  width: screen.width * 0.9,
                  textAlign: "center",
                  fontSize: 40
                }
              ]}>
              YOU HAVE NO APPOINTMENT
            </Text>
          </View>
        )}
        <View style={{ marginBottom: 70 }}></View>
      </View>
    </View>
  );
};

// define your styles
const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: "center",
    backgroundColor: colors.blue_backgroud,
    paddingTop: 10
  }
});

export default inject("store")(observer(index));
