import React, { useEffect, useState } from "react";
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  ActivityIndicator,
  TouchableOpacity,
  RefreshControl,
  FlatList
} from "react-native";
import { inject, observer } from "mobx-react";
import {
  BookedAppointmentCardList,
  SubmitButton
} from "../../../../Components";
import { colors, screen } from "../../../../../constant";
import { v4 as uuidv4 } from "uuid";
import _ from "lodash";
import { CheckBox } from "react-native-elements";
import { TextInput } from "react-native";
import buttonStyle from "../../../../../constant/buttonStyle";
import { Calendar, CalendarList, Agenda } from "react-native-calendars";
function removeDuplicates(data, key) {
  return [...new Map(data.map((item) => [key(item), item])).values()];
}

function sortFunction(a, b) {
  var dateA = new Date(a.date).getTime();
  var dateB = new Date(b.date).getTime();
  return dateA > dateB ? 1 : -1;
}

const index = ({ store, route, navigation }) => {
  const [prefSched, setPrefSched] = useState([]);
  const [markedDates, setmarkedDates] = useState({});
  const { item } = route.params;
  const onDayPress = (day) => {
    let date = { date: day.dateString };

    let markedDatesObj = { ...markedDates };
    markedDatesObj[day.dateString] = {
      selected: true
    };
    if (Object.keys(markedDates).length < 3) {
      setmarkedDates(markedDatesObj);
      setPrefSched((prev) => [...prev, date]);
    } else {
      alert("You can only pick 3 dates");
    }
  };

  const reschedBtnHandler = () => {
    let dateSort = prefSched.sort(sortFunction);
    let dateRemoveDup = removeDuplicates(dateSort, (item) => item.date);
    let arrDate = [];

    dateRemoveDup.map((item) => {
      arrDate.push(item.date);
    });

    item.preferedschedules = arrDate.toString();

    if (arrDate.toString() == "") alert("Please select a reschedule date");

    fetch(
      `https://lj2e11f6r1.execute-api.ap-southeast-1.amazonaws.com/autoserved/qoutes/${item.index}`,
      {
        method: "PATCH",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify({ ...item, sqr_state: 4 })
      }
    )
      .then((response) => {
        navigation.navigate("ShopBookedQoutesScreen");
        console.log("Sucess", response);
        // callback();
      })
      .catch((error) => {
        // callback("" + error);
        console.error("Error:", error);
      });
  };

  const Checkboxes = ({ title }) => {
    const [isCheck, setCheck] = useState(false);
    const [titleLbl, setTitleLbl] = useState(title);
    return (
      <View>
        <CheckBox
          title={titleLbl}
          checked={isCheck}
          onPress={() => {
            setCheck(!isCheck), console.log(titleLbl);
          }}
          containerStyle={{
            borderWidth: 0,
            backgroundColor: "white",
            width: 0.8 * screen.width
          }}
          textStyle={{
            color: colors.font_text_color,
            fontSize: 18
          }}
        />
        {isCheck && titleLbl == "Others" ? (
          <View>
            <TextInput style={styles.textInputStyle} />
          </View>
        ) : (
          <View />
        )}
      </View>
    );
  };

  return (
    <ScrollView
      style={styles.container}
      contentContainerStyle={{ alignItems: "center" }}>
      <View style={styles.content}>
        <View style={styles.data_content}>
          <Text style={styles.headerLbl}>
            Can you tell us why you are rescheduling this appointment?
          </Text>
          <Checkboxes title="Scheduling conflict" />
          <Checkboxes title="Parts & materials unavailable" />
          <Checkboxes title="Technician not available" />
          <Checkboxes title="Others" />

          <Calendar
            current={new Date()}
            hideExtraDays={false}
            onDayPress={onDayPress}
            markedDates={markedDates}
            theme={{
              calendarBackground: colors.dark_blue,
              dayTextColor: "white",
              monthTextColor: "white",
              indicatorColor: "white",
              selectedDayTextColor: "#ffffff",
              textDayFontFamily: "OpenSans-Regular",
              textMonthFontFamily: "OpenSans-Regular",
              textDayHeaderFontFamily: "OpenSans-Regular",
              textMonthFontWeight: "bold",
              textDayHeaderFontWeight: "300",
              textDayFontSize: 20,
              textMonthFontSize: 20,
              textDayHeaderFontSize: 20,
              arrowColor: "white",
              selectedDayTextColor: "black",
              "stylesheet.day.basic": {
                selected: {
                  borderRadius: 25,
                  alignItems: "center",
                  backgroundColor: "white"
                }
              }
              // textDisabledColor: 'red',
            }}
          />
        </View>
      </View>
      <TouchableOpacity
        style={[buttonStyle.btn.btnDarkBlue, { top: -20, elevation: 5 }]}
        onPress={() => reschedBtnHandler()}>
        <Text style={buttonStyle.btn.lblBtnDarkBlue}>Reschedule</Text>
      </TouchableOpacity>
      <View style={{ marginBottom: 80 }}></View>
    </ScrollView>
  );
};

// define your styles
const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.blue_backgroud
  },
  content: {
    // marginLeft: 0.02 * screen.height,
    // marginRight: 0.02 * screen.height,
    width: 0.9 * screen.width,
    backgroundColor: "white",
    backgroundColor: "white",
    alignItems: "center",
    justifyContent: "center",
    paddingBottom: 40,
    borderRadius: 15,
    shadowColor: "#000",
    shadowOffset: {
      width: 0,
      height: 2
    },
    shadowOpacity: 0.25,
    shadowRadius: 3.84,
    elevation: 5
  },
  data_content: {
    padding: 20
  },
  headerLbl: {
    fontFamily: "OpenSans-Regular",
    fontSize: 0.03 * screen.height,
    color: colors.font_text_color,
    textAlign: "center",
    paddingBottom: 10
  },
  textInputStyle: {
    height: 68,
    backgroundColor: colors.font_text_color,
    borderRadius: 10,
    paddingHorizontal: 20,
    color: "white",
    fontFamily: "OpenSans-Regular"
  }
});

export default inject("store")(observer(index));
