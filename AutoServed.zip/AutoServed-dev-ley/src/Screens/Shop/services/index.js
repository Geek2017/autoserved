import React, { useEffect, useState } from "react";
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  ActivityIndicator,
  TouchableOpacity
} from "react-native";
import { inject, observer } from "mobx-react";
import { QuotesCardList, SubmitButton } from "../../../Components";
import { colors, mainStyle, screen } from "../../../../constant";
import CheckBox from "@react-native-community/checkbox";
import { PMS1, PMS2, PMS3 } from "../../../Components/Services";
// create a component

const index = ({ navigation, store }) => {
  const [page, setPage] = useState(1);

  return (
    <ScrollView
      style={{
        flex: 1,
        backgroundColor: colors.blue_backgroud
      }}>
      {page == 1 ? (
        <View style={{ alignItems: "center" }}>
          <Text
            style={[
              mainStyle.main.Header2,
              { textAlign: "center", fontSize: 20, paddingVertical: 8 }
            ]}>
            Preventive Maintenance Service (PMS)
          </Text>
          <PMS1 setPage={setPage} />
        </View>
      ) : page == 2 ? (
        <View style={{ alignItems: "center" }}>
          <Text
            style={[
              mainStyle.main.Header2,
              { textAlign: "center", fontSize: 20, paddingVertical: 8 }
            ]}>
            Preventive Maintenance Service (PMS)
          </Text>
          <PMS2 setPage={setPage} />
        </View>
      ) : page == 3 ? (
        <View style={{ alignItems: "center" }}>
          <Text
            style={[
              mainStyle.main.Header2,
              { textAlign: "center", fontSize: 20, paddingVertical: 8 }
            ]}>
            Change Oil
          </Text>
          <PMS3 setPage={setPage} navigation={navigation} />
        </View>
      ) : (
        <View />
      )}
    </ScrollView>
  );
};

// define your styles
const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: "center",
    backgroundColor: colors.blue_backgroud,
    paddingTop: 10
  }
});

export default inject("store")(observer(index));
