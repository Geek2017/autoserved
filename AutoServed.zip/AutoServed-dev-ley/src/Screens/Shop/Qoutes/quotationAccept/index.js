//import liraries
import React, { useState, useEffect } from "react";
import { View, Text, StyleSheet, TouchableOpacity } from "react-native";
import { capitalizeFirstLetter } from "../../../../Helper";
import TextInputMask from "react-native-text-input-mask";
import { inject, observer } from "mobx-react";
import {
  buttonStyle,
  colors,
  mainStyle,
  screen
} from "../../../../../constant";
import moment from "moment";
import { CheckBox, Button } from "react-native-elements";
import { ScrollView } from "react-native";
import _ from "lodash";

// create a component
function sum(obj) {
  var sum = 0;
  for (var el in obj) {
    if (obj.hasOwnProperty(el)) {
      sum += parseFloat(obj[el]);
    }
  }
  return sum;
}

// create a component
const index = ({ navigation, store, route }) => {
  const { arrData } = route.params;

  const [check, setSelection] = useState(false);
  const [totalMaterial, setTotalMaterial] = useState(0);
  const [grandTotal, setGrandTotal] = useState(0);
  const [individualInfo, setIndividualInfo] = useState({});

  const [OtherItem, setOtherItem] = useState([]);

  let arrDateLetter = ["1st", "2nd", "3rd"];

  let jsonReplacement = {};
  jsonReplacement["Engine Oil"] = "engineoil";
  jsonReplacement["Oil Filter"] = "oilfilter";
  jsonReplacement["Flushing"] = "flushing";
  jsonReplacement["Air Filter"] = "airfilter";
  jsonReplacement["Cabin Filter"] = "cabinfilter";
  jsonReplacement["Coolant"] = "coolant";
  jsonReplacement["Brake Fluid"] = "breakfluid";
  jsonReplacement["Spark plug"] = "sparkplug";
  jsonReplacement["Power Steering Fluid"] = "psf";
  jsonReplacement["Brake Cleaner"] = "bsf";
  jsonReplacement["Labor"] = "labor";

  useEffect(() => {
    fetch(
      `https://lj2e11f6r1.execute-api.ap-southeast-1.amazonaws.com/autoserved/users/${arrData.iqr_from}`
    )
      .then(fetch.throwErrors)
      .then((res) => res.json())
      .then((json) => {
        setIndividualInfo(json);
      })
      .catch();
    console.log(store.OtherItem);
  }, []);

  const onSubmitHandler = () => {
    if (check) {
      acceptQuotes(arrData, totalMaterial, grandTotal);
    } else {
      alert("Please agree to terms and condition");
    }
  };

  const acceptQuotes = (data, totalMaterial, grandTotal) => {
    store.mqoutes.qid = arrData.id;
    store.mqoutes.shopid = store.profile.mobileno;
    store.mqoutes.userid = arrData["iqr_from"];
    store.mqoutes.status = 0;

    fetch(
      `https://lj2e11f6r1.execute-api.ap-southeast-1.amazonaws.com/autoserved/qoutes/1`,
      {
        method: "PATCH",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify({
          ...data,
          sqr_by: data.sqr_by
            ? data.sqr_by + "," + store.profile.mobileno
            : store.profile.mobileno,
          sqr_state: data.sqr_state ? data.sqr_state + "," + 0 : 0
        })
      }
    )
      .then((response) => {
        setKey(Math.random());
        store.shopQoutesRecieve = [];
        store.createMqoutes();
        navigation.navigate("QuatationSummary", {
          arrData: data,
          totalMaterial: totalMaterial,
          grandTotal: grandTotal
        });
      })
      .catch((error) => {
        console.error("Error:", error);
      });
  };

  const AddOtherItem = () => {
    let lastIndex = store.OtherItem.pop() ? store.OtherItem.pop() : 0;
    // store.OtherItem = [...store.OtherItem, { item: "test", price: 222 }];
    setOtherItem((prev) => [...prev, 1]);
    console.log(OtherItem);
  };
  return (
    <View style={{ backgroundColor: colors.blue_backgroud }}>
      <ScrollView
        contentContainerStyle={{
          alignItems: "center"
        }}>
        <View style={styles.container_qouteAccept}>
          {/* Header */}
          <View style={styles.header}>
            <Text
              style={[
                mainStyle.main.Header2,
                { color: "white", fontSize: 16, width: "50%", paddingLeft: 16 }
              ]}>
              Name :{" "}
              {capitalizeFirstLetter(
                individualInfo.fullname
                  ? individualInfo.fullname.split(/(\s+)/)[0].replace(",", "")
                  : ""
              )}
            </Text>
            <View
              style={{
                borderWidth: 1,
                borderColor: "white",
                height: 25,
                marginHorizontal: 8
              }}></View>
            <Text
              style={[
                mainStyle.main.Header2,
                { color: "white", fontSize: 16, width: "50%", paddingRight: 16 }
              ]}>
              {individualInfo.mobileno}
            </Text>
          </View>

          {/* Horizontal Line */}
          <View
            style={{
              borderWidth: 1.5,
              borderColor: colors.another_blue,
              marginBottom: 16
            }}></View>
          <View
            style={{
              justifyContent: "center",
              alignItems: "center",
              flexDirection: "row"
            }}>
            <View style={styles.data_content}>
              <View style={{ flexDirection: "row" }}>
                <Text style={styles.lbl}>Plate Number : </Text>
                <Text style={styles.lbl}>{arrData.plateno}</Text>
              </View>
              <View style={{ flexDirection: "row" }}>
                <Text style={styles.lbl}>Year Model : </Text>
                <Text style={styles.lbl}>{arrData.yrmodel}</Text>
              </View>
              <View style={{ flexDirection: "row" }}>
                <Text style={styles.lbl}>Make : </Text>
                <Text style={styles.lbl}>{arrData.make}</Text>
              </View>
              <View style={{ flexDirection: "row" }}>
                <Text style={styles.lbl}>Model : </Text>
                <Text style={styles.lbl}>{arrData.model}</Text>
              </View>
              <View style={{ flexDirection: "row" }}>
                <Text style={styles.lbl}>Engine : </Text>
                <Text style={styles.lbl}>{arrData.engine}</Text>
              </View>
              <View style={{ flexDirection: "row" }}>
                <Text style={styles.lbl}>Transmission :</Text>
                <Text style={styles.lbl}>{arrData.transmission}</Text>
              </View>
              <View style={{ flexDirection: "row" }}>
                <Text style={styles.lbl}>DOP : </Text>
                <Text style={styles.lbl}>{arrData.purchasedate}</Text>
              </View>
              <View style={{ flexDirection: "row" }}>
                <Text style={styles.lbl}>Current Mileage: </Text>
                <Text style={styles.lbl}>{arrData.mileage} KM</Text>
              </View>
              {/* Second Page */}
              <View style={{ flexDirection: "row", paddingTop: 8 }}>
                <Text style={styles.lbl}>DATE OF REQUEST : </Text>
                <Text style={styles.lbl}>
                  {arrData.preferedschedules.split(",").map((item, index) => {
                    return `${arrDateLetter[index]} ${moment(item).format(
                      "MMMM DD, YYYY"
                    )} ${"\n"}`;
                  })}
                </Text>
              </View>
              {/* Horizontal Line */}
              <View
                style={{
                  borderWidth: 1.5,
                  borderColor: colors.another_blue,
                  marginBottom: 16
                }}></View>

              {/* Second */}
              <View
                style={{
                  flexDirection: "row",
                  justifyContent: "space-between"
                }}>
                <View style={{ flexDirection: "row", alignItems: "center" }}>
                  <Text
                    style={[
                      mainStyle.main.Bold,
                      { color: colors.another_blue, fontSize: 18 }
                    ]}>
                    Vehicle Type :{" "}
                  </Text>
                  <Text
                    style={[
                      mainStyle.main.subtleText,
                      { color: colors.another_blue, fontSize: 18 }
                    ]}>
                    {arrData.cartype}
                  </Text>
                </View>

                <View style={{ flexDirection: "row", alignItems: "center" }}>
                  <Text
                    style={[
                      mainStyle.main.Bold,
                      { color: colors.another_blue, fontSize: 18 }
                    ]}>
                    PMS Type :{" "}
                  </Text>
                  <Text
                    style={[
                      mainStyle.main.subtleText,
                      { color: colors.another_blue, fontSize: 18 }
                    ]}>
                    {capitalizeFirstLetter(arrData.pms)}
                  </Text>
                </View>
              </View>

              {/* End Second */}

              <View
                style={{
                  alignItems: "center",
                  justifyContent: "center",
                  paddingTop: 16,
                  width: "80%"
                }}>
                <View
                  style={{
                    flexDirection: "row",
                    alignItems: "center",
                    marginBottom: 8
                  }}>
                  <Text
                    style={[
                      mainStyle.main.Bold,
                      {
                        color: colors.another_blue,
                        fontSize: 18,
                        paddingHorizontal: 16,
                        width: "70%"
                      }
                    ]}>
                    Total Labor Cost
                  </Text>
                  <TextInputMask
                    // refInput={(ref) => {
                    //   this.input = ref;
                    // }}
                    placeholder="₱"
                    placeholderTextColor="white"
                    keyboardType="number-pad"
                    style={{
                      width: "30%",
                      height: 0.05 * screen.height,
                      backgroundColor: colors.font_text_color,
                      borderRadius: 15,
                      padding: 10,
                      color: "white"
                    }}
                    onChangeText={(formatted, extracted) => {
                      let newVal = extracted ? extracted : 0;
                      store.mqoutes.labor = newVal;
                      setGrandTotal(sum(store.mqoutes));
                    }}
                    mask={"₱ [0000000]"}
                  />
                </View>

                {/* Loop */}
                {arrData.for_replacement.split(",").map((item) => (
                  <View
                    style={{
                      flexDirection: "row",
                      marginBottom: 8,
                      alignItems: "center"
                    }}>
                    <Text
                      style={[
                        mainStyle.main.Bold,
                        {
                          color: colors.another_blue,
                          fontSize: 18,
                          paddingHorizontal: 16,
                          width: "70%"
                        }
                      ]}>
                      {item}
                    </Text>
                    <TextInputMask
                      // refInput={(ref) => {
                      //   this.input = ref;
                      // }}
                      placeholder="₱"
                      placeholderTextColor="white"
                      keyboardType="number-pad"
                      style={{
                        width: "30%",
                        height: 0.05 * screen.height,
                        backgroundColor: colors.font_text_color,
                        borderRadius: 15,
                        padding: 10,
                        color: "white"
                      }}
                      onChangeText={(formatted, extracted) => {
                        console.log(extracted);
                        let newVal = extracted ? extracted : 0;
                        store.mqoutes[jsonReplacement[item]] = newVal;
                        setTotalMaterial(sum(_.omit(store.mqoutes, "labor")));
                        setGrandTotal(sum(store.mqoutes));
                      }}
                      mask={"₱ [0000000]"}
                    />
                  </View>
                ))}
              </View>

              {/* Other ITEM */}

              <View
                style={{
                  width: "100%",
                  alignItems: "center",
                  paddingTop: 16
                }}>
                {OtherItem.length != 0 ? (
                  <Text
                    style={[
                      mainStyle.main.Header2,
                      {
                        color: colors.another_blue,
                        fontSize: 20,
                        paddingVertical: 16
                      }
                    ]}>
                    Total Parts & Materials
                  </Text>
                ) : (
                  <View />
                )}
                {OtherItem.map((item) => (
                  <View
                    style={{
                      flexDirection: "row",
                      marginBottom: 8,
                      alignItems: "center"
                    }}>
                    <TextInputMask
                      // refInput={(ref) => {
                      //   this.input = ref;
                      // }}
                      placeholder="Item"
                      placeholderTextColor="white"
                      keyboardType="default"
                      style={{
                        width: "30%",
                        height: 0.05 * screen.height,
                        backgroundColor: colors.font_text_color,
                        borderRadius: 15,
                        padding: 10,
                        color: "white",
                        marginHorizontal: 16
                      }}
                      onChangeText={(formatted, extracted) => {}}
                    />
                    <TextInputMask
                      // refInput={(ref) => {
                      //   this.input = ref;
                      // }}
                      keyboardType="number-pad"
                      placeholder="₱"
                      placeholderTextColor="white"
                      style={{
                        width: "30%",
                        height: 0.05 * screen.height,
                        backgroundColor: colors.font_text_color,
                        borderRadius: 15,
                        padding: 10,
                        color: "white",
                        marginHorizontal: 16
                      }}
                      onChangeText={(formatted, extracted) => {}}
                      mask={"₱ [0000000]"}
                    />
                  </View>
                ))}
                <TouchableOpacity
                  style={{
                    backgroundColor: colors.dark_blue,
                    width: 150,
                    height: 50,
                    borderRadius: 15,
                    flexDirection: "row",
                    alignItems: "center",
                    justifyContent: "center"
                  }}
                  onPress={AddOtherItem}>
                  <Text
                    style={[
                      mainStyle.main.PreTitle,
                      { color: "white", fontSize: 14 }
                    ]}>
                    Add Material Parts
                  </Text>
                </TouchableOpacity>
              </View>

              <View style={{ flexDirection: "row", paddingTop: 20 }}>
                <Text style={styles.lbl}> TOTAL PARTS & MATERIALS</Text>
                <Text style={styles.lbl}>
                  {" "}
                  PHP: {isNaN(totalMaterial) ? 0 : totalMaterial}
                </Text>
              </View>
              <View style={{ flexDirection: "row", paddingTop: 20 }}>
                <Text style={styles.lbl}> GRAND TOTAL</Text>
                <Text style={styles.lbl}>
                  {" "}
                  PHP: {isNaN(grandTotal) ? 0 : grandTotal}
                </Text>
              </View>

              <View style={{ flexDirection: "row", paddingTop: 20 }}>
                <CheckBox
                  title="I agree with the Terms & Conditions 
                and Warrant policy by AutoServed"
                  checked={check}
                  onIconPress={() => setSelection(!check)}
                  textStyle={{ color: colors.font_text_color }}
                  checkedColor="black"
                />
              </View>
            </View>
          </View>

          <TouchableOpacity
            style={[
              buttonStyle.btn.btnDarkBlue,
              { top: 15, alignSelf: "center" }
            ]}
            onPress={() => onSubmitHandler()}>
            <Text style={[buttonStyle.btn.lblBtnDarkBlue, { fontSize: 16 }]}>
              FINALIZE AND SEND QUOTE
            </Text>
          </TouchableOpacity>
        </View>
        <View style={{ marginBottom: 70 }}></View>
      </ScrollView>
    </View>
  );
};

// define your styles
const styles = StyleSheet.create({
  container_qouteAccept: {
    backgroundColor: "white",
    borderRadius: 15,
    shadowColor: "#000",
    shadowOffset: {
      width: 0,
      height: 2
    },
    shadowOpacity: 0.25,
    shadowRadius: 3.84,
    marginBottom: 30,
    width: screen.width * 0.9,
    paddingHorizontal: 16
  },
  data_content: {
    height: "100%",
    paddingHorizontal: 16
  },
  lbl: {
    fontFamily: "OpenSans-Regular",
    color: colors.another_blue,
    fontSize: 16,
    width: "50%",
    lineHeight: 16
  },
  header: {
    flexDirection: "row",
    backgroundColor: colors.another_blue,
    marginVertical: 16,
    height: 60,
    borderRadius: 15,
    alignItems: "center"
  }
});

//make this component available to the app
export default inject("store")(observer(index));
