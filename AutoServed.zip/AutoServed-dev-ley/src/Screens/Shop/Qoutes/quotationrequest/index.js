import React, { useEffect, useState } from "react";
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  ActivityIndicator,
  TouchableOpacity,
  RefreshControl,
  FlatList
} from "react-native";
import { inject, observer } from "mobx-react";
import { QuotesCardList, SubmitButton } from "../../../../Components";
import { colors, mainStyle, screen } from "../../../../../constant";
import _ from "lodash";

// create a component
function sum(obj) {
  var sum = 0;
  for (var el in obj) {
    if (obj.hasOwnProperty(el)) {
      sum += parseFloat(obj[el]);
    }
  }
  return sum;
}

function sumParts(obj) {
  var sum = 0;
  for (var el in obj) {
    if (obj.hasOwnProperty(el)) {
      sum += parseFloat(obj[el]);
    }
  }
  return sum;
}

const index = ({ navigation, store }) => {
  const [isKey, setKey] = useState(Math.random());
  const [isQouteAccepted, setQouteAccept] = useState(false);
  const [dataJson, setDataJson] = useState({});
  const [otherItemArr, setOtherItemArr] = useState([0]);

  const [refreshing, setRefreshing] = useState(false);
  useEffect(() => {
    const unsubscribe = navigation.addListener("focus", () => {
      setQouteAccept(false);
      store.mqoutes = {};
      store.shopQoutesRecieve = [];
      store.qoutesStatusShop = [];
      if (store.shops.approval == "approve") store.getUserCreatedQuotes();
    });
    return unsubscribe;
  }, [navigation]);

  // const QouteAccept = ({ arrData }) => {};

  return (
    <View
      style={{
        flex: 1,
        backgroundColor: colors.blue_backgroud
      }}>
      <View key={isKey} style={styles.container}>
        {store.fetching ? (
          <ActivityIndicator
            color="grey"
            size={60}
            style={{ flex: 1, alignSelf: "center" }}
          />
        ) : store.qoutesStatusShop.length != 0 ? (
          <FlatList
            showsVerticalScrollIndicator={false}
            style={{ flex: 1 }}
            data={store.shopQoutesRecieve}
            renderItem={({ item, index }) => {
              return (
                <View>
                  <QuotesCardList
                    arrData={item}
                    status={
                      store.qoutesStatusShop[index]
                        ? store.qoutesStatusShop[index]
                        : 2
                    }
                    onPressQuote={() => {
                      // setQouteAccept(true);
                      navigation.navigate("Quatation Accept", {
                        arrData: item
                      });
                      // setDataJson(item);
                    }}
                  />
                </View>
              );
            }}
            keyExtractor={(item) => item.Id}
          />
        ) : (
          <View style={{ height: screen.height / 2, justifyContent: "center" }}>
            <Text
              style={[
                mainStyle.main.Header3,
                {
                  width: screen.width * 0.9,
                  textAlign: "center",
                  fontSize: 40
                }
              ]}>
              NO QUOTES
            </Text>
          </View>
        )}
        <View style={{ marginBottom: 60 }}></View>
      </View>
    </View>
  );
};

// define your styles
const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: "center",
    backgroundColor: colors.blue_backgroud,
    paddingTop: 10
  },
  container_qouteAccept: {
    backgroundColor: "white",
    borderRadius: 15,
    shadowColor: "#000",
    shadowOffset: {
      width: 0,
      height: 2
    },
    shadowOpacity: 0.25,
    shadowRadius: 3.84,
    marginBottom: 30,
    width: screen.width * 0.9,
    paddingHorizontal: 16
  },
  data_content: {
    height: "100%",
    paddingHorizontal: 16
  },
  icons_content: {
    width: "15%",
    height: "100%",
    justifyContent: "space-evenly",
    alignItems: "center"
  },
  lbl: {
    fontFamily: "OpenSans-Regular",
    color: colors.another_blue,
    fontSize: 16,
    width: "50%",
    lineHeight: 16
  },
  edit: {
    width: 0.8 * screen.width,
    height: 0.06 * screen.height,
    backgroundColor: colors.dark_blue,
    borderRadius: 75,
    alignItems: "center",
    justifyContent: "center"
  },
  delete: {
    width: 0.35 * screen.width,
    height: 40,
    backgroundColor: "red",
    borderTopRightRadius: 20,
    borderBottomRightRadius: 20,
    alignItems: "center",
    justifyContent: "center"
  },
  lblEditDelete: {
    fontFamily: "OpenSans-Regular",
    fontSize: 0.025 * screen.height,
    color: "white"
  },
  header: {
    flexDirection: "row",
    backgroundColor: colors.another_blue,
    marginVertical: 16,
    height: 60,
    borderRadius: 15,
    alignItems: "center"
  }
});

export default inject("store")(observer(index));
