import React, { useEffect, useState } from "react";
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  ActivityIndicator,
  TouchableOpacity
} from "react-native";
import { inject, observer } from "mobx-react";
// import { QuotesCardList, SubmitButton } from "../../../Components";
import { colors, screen } from "../../../../../constant";
// import CheckBox from "@react-native-community/checkbox";
// create a component

const index = ({ navigation, store, route }) => {
  const { arrData, totalMaterial, grandTotal } = route.params;
  let minorOrmajor =
    arrData.pms == "minor" ? "pms_minor_price" : "pms_major_price";
  let jsonReplacement = {};
  jsonReplacement["Engine Oil"] = "engineoil";
  jsonReplacement["Oil Filter"] = "oilfilter";
  jsonReplacement["Flushing"] = "flushing";
  jsonReplacement["Air Filter"] = "airfilter";
  jsonReplacement["Cabin Filter"] = "cabinfilter";
  jsonReplacement["Coolant"] = "coolant";
  jsonReplacement["Brake Fluid"] = "breakfluid";
  jsonReplacement["Spark plug"] = "sparkplug";
  jsonReplacement["Power Steering Fluid"] = "psf";
  jsonReplacement["Brake Cleaner"] = "bsf";
  jsonReplacement["Labor"] = "labor";

  return (
    <ScrollView
      style={{
        flex: 1,
        backgroundColor: colors.blue_backgroud
      }}>
      <View style={styles.container}>
        <View style={styles.container_qouteAccept}>
          <Text
            style={{
              color: colors.font_text_color,
              fontFamily: "OpenSans-Regular",
              textAlign: "center",
              fontSize: 0.03 * screen.height
            }}>
            Your quotation has been sent!Here’s the summary
          </Text>
          <View
            style={{
              justifyContent: "center",
              alignItems: "center",
              flexDirection: "row"
            }}>
            <View style={styles.data_content}>
              <View style={{ flexDirection: "row" }}>
                <Text style={styles.lbl}>Plate Number : </Text>
                <Text style={styles.lbl}>{arrData.plateno}</Text>
              </View>
              <View style={{ flexDirection: "row" }}>
                <Text style={styles.lbl}>Year Model : </Text>
                <Text style={styles.lbl}>{arrData.yrmodel}</Text>
              </View>

              <View style={{ flexDirection: "row" }}>
                <Text style={styles.lbl}>Make : </Text>
                <Text style={styles.lbl}>{arrData.make}</Text>
              </View>

              <View style={{ flexDirection: "row" }}>
                <Text style={styles.lbl}>Model : </Text>
                <Text style={styles.lbl}>{arrData.model}</Text>
              </View>
              <View style={{ flexDirection: "row" }}>
                <Text style={styles.lbl}>Engine : </Text>
                <Text style={styles.lbl}>{arrData.engine}</Text>
              </View>
              <View style={{ flexDirection: "row" }}>
                <Text style={styles.lbl}>Transmission :</Text>
                <Text style={styles.lbl}>{arrData.transmission}</Text>
              </View>
              <View style={{ flexDirection: "row", flexWrap: "wrap" }}>
                <Text style={styles.lbl}>DATE OF Appointment: </Text>
                <Text style={styles.lbl}>{arrData.requestdate}</Text>
              </View>
              <View style={{ paddingTop: 20 }}>
                <Text style={styles.lbl}>Labor: </Text>
                <Text style={styles.lbl}>{arrData.pms} PMS</Text>
              </View>
              <View style={{ flexDirection: "row" }}>
                <Text style={styles.lbl}>{arrData.cartype} </Text>
                <Text style={styles.lbl}>₱ {store.mqoutes.labor}</Text>
              </View>
              <View style={{ flexDirection: "row" }}>
                <Text style={styles.lbl}>TOTAL LABOR: </Text>
                <Text style={styles.lbl}>₱ {store.mqoutes.labor}</Text>
              </View>
              <View style={{ flexDirection: "row", paddingTop: 20 }}>
                <Text style={styles.lbl}>PARTS & MATERIALS: </Text>
              </View>
              {arrData.for_replacement.split(",").map((item) => (
                <View style={{ flexDirection: "row" }}>
                  <Text style={styles.lbl}>{item}: </Text>
                  <Text style={styles.lbl}>
                    ₱ {store.mqoutes[jsonReplacement[item]]}
                  </Text>
                </View>
              ))}
              <View style={{ flexDirection: "row" }}>
                <Text style={styles.lbl}>TOTAL PARTS & MATERIALS : </Text>
                <Text style={styles.lbl}>₱ {totalMaterial}</Text>
              </View>
              <View style={{ flexDirection: "row" }}>
                <Text style={styles.lbl}>GRAND TOTAL : </Text>
                <Text style={styles.lbl}>₱ {grandTotal}</Text>
              </View>
            </View>
          </View>
        </View>
      </View>
      <View style={{ marginBottom: 80 }}></View>
    </ScrollView>
  );
};

// define your styles
const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: "center",
    backgroundColor: colors.blue_backgroud,
    paddingTop: 10
  },
  container_qouteAccept: {
    width: 0.9 * screen.width,
    backgroundColor: "white",
    marginBottom: 30
  },
  data_content: {
    width: "85%",
    height: "100%",
    paddingLeft: 20,
    paddingTop: 20,
    paddingRight: 10
  },
  icons_content: {
    width: "15%",
    height: "100%",
    justifyContent: "space-evenly",
    alignItems: "center"
  },
  lbl: {
    fontFamily: "OpenSans-Regular",
    color: colors.font_text_color,
    fontSize: 0.019 * screen.height,
    width: "50%"
  },
  edit: {
    width: 0.8 * screen.width,
    height: 0.06 * screen.height,
    backgroundColor: colors.dark_blue,
    borderRadius: 75,
    alignItems: "center",
    justifyContent: "center"
  },
  delete: {
    width: 0.35 * screen.width,
    height: 40,
    backgroundColor: "red",
    borderTopRightRadius: 20,
    borderBottomRightRadius: 20,
    alignItems: "center",
    justifyContent: "center"
  },
  lblEditDelete: {
    fontFamily: "OpenSans-Regular",
    fontSize: 0.025 * screen.height,
    color: "white"
  }
});

export default inject("store")(observer(index));
