//import liraries
import React, { useState } from "react";
import {
  View,
  Text,
  StyleSheet,
  Image,
  ScrollView,
  TouchableOpacity,
  TextInput
} from "react-native";
import { colors, images, screen, icons } from "../../../../constant";
import Icon from "react-native-vector-icons/Feather";
import {
  TextFieldRegular,
  SubmitButton,
  GoogleTextfieldShop,
  ImagePickerBtn,
  ModalSchedule
} from "../../../Components";
import { useNavigation } from "@react-navigation/native";
import CheckBox from "@react-native-community/checkbox";
import { launchCamera, launchImageLibrary } from "react-native-image-picker";
import { inject, observer } from "mobx-react";

const chooseFile = (uploadPhoto, setUploadPhoto) => {
  var options = {
    title: "Select Image",
    customButtons: [
      { name: "customOptionKey", title: "Choose Photo from Custom Option" }
    ],
    storageOptions: {
      skipBackup: true, // do not backup to iCloud
      path: "images" // store camera images under Pictures/images for android and Documents/images for iOS
    },
    includeBase64: true,
    maxWidth: 400,
    maxHeight: 400,
    quality: 0.5
  };

  launchImageLibrary(options, (response) => {
    if (response.didCancel) {
      // console.log("User cancelled image picker", storage());
    } else if (response.error) {
      console.log("ImagePicker Error: ", response.error);
    } else if (response.customButton) {
      console.log("User tapped custom button: ", response.customButton);
    } else {
      // uploadImageToStorage(response.uri, response.fileName);
      let source = response;
      let base64Img = response.base64;
      let name = { ...uploadPhoto, [store.text]: "true" };
      store.shops[store.text] = "data:image/jpeg;base64," + base64Img;
      setUploadPhoto(name);
    }
  });
};

const FirstPage = ({ setNum }) => {
  const validation = () => {
    if (Object.keys(store.shops).length > 8) {
      setNum(2);
    } else {
      alert("please fill up all the fields");
    }
  };
  return (
    <View
      style={{
        alignItems: "center",
        width: 0.9 * screen.width,
        height: "100%"
      }}>
      <TextFieldRegular
        placeholder="Shop Name"
        setData={(text) => (store.shops.shop_name = text)}
      />
      <TextFieldRegular
        placeholder="Business Name"
        setData={(text) => (store.shops.bizname = text)}
      />
      <TextFieldRegular
        placeholder="Street Address"
        setData={(text) => (store.shops.stadd = text)}
      />
      <TextFieldRegular
        placeholder="Barangay"
        setData={(text) => (store.shops.brgy = text)}
      />
      <TextFieldRegular
        placeholder="Province"
        setData={(text) => (store.shops.province = text)}
      />
      <TextFieldRegular
        placeholder="City"
        setData={(text) => (store.shops.city = text)}
      />
      <TextFieldRegular
        placeholder="Region"
        setData={(text) => (store.shops.region = text)}
      />
      <TextFieldRegular
        placeholder="Owner/Main Contact Person"
        setData={(text) => (store.shops.owner_contactperson = text)}
      />
      <TextFieldRegular
        placeholder="Phone No. of Main Contact Person"
        setData={(text) => (store.shops.owner_contactperson_no = text)}
      />
      <View style={{ paddingBottom: 100 }}>
        <SubmitButton
          title="NEXT"
          inProfile
          onPress={() => {
            validation();
          }}
        />
      </View>
      <View style={{ paddingBottom: 0.09 * screen.height }}></View>
    </View>
  );
};

const SecondPage = ({ setNum }) => {
  const [uploadPhoto, setUploadPhoto] = useState({});
  const validationSecond = () => {
    if (Object.keys(store.shops).length >= 16) {
      setNum(3);
      return;
    } else {
      alert("please fill up all the fields");
    }
  };
  console.log(uploadPhoto);
  return (
    <View
      style={{
        alignItems: "center",
        width: 0.9 * screen.width,
        height: "100%"
      }}>
      <TextFieldRegular
        placeholder="Business Phone No."
        isNumberPad
        defaultValue={store.shops.biz_no}
        setData={(text) => (store.shops.biz_no = text)}
      />
      <TextFieldRegular
        placeholder="Email"
        setData={(text) => (store.shops.email = text)}
      />
      <TextFieldRegular
        placeholder="Facebook Page"
        setData={(text) => (store.shops.fbpage = text)}
      />
      <TextFieldRegular
        placeholder="Facebook Messenger/What`s App"
        setData={(text) => (store.shops.fb_messenger = text)}
      />
      <TextFieldRegular
        placeholder="Website"
        setData={(text) => (store.shops.website = text)}
      />

      <ImagePickerBtn
        title="Upload Business Permit"
        // setData={(text) => (store.car.plateno = text)}
        onPress={() => {
          chooseFile(uploadPhoto, setUploadPhoto), (store.text = "bizpermit");
        }}
        isCheck={uploadPhoto.bizpermit ? true : false}
      />
      <ImagePickerBtn
        title="Upload BIR"
        onPress={() => {
          chooseFile(uploadPhoto, setUploadPhoto), (store.text = "bircert");
        }}
        isCheck={uploadPhoto.bircert ? true : false}
      />
      <View style={{ paddingBottom: 100 }}>
        <SubmitButton
          title="NEXT"
          inProfile
          onPress={() => validationSecond()}
        />
      </View>
      <View style={{ paddingBottom: 0.09 * screen.height }}></View>
    </View>
  );
};

const ThirdPage = () => {
  const navigation = useNavigation();
  const [isModal, setModalShow] = useState(false);
  const [isSelected, setSelection] = useState(false);
  const [uploadPhoto, setUploadPhoto] = useState({});

  const shopCreation = () => {
    if (!isSelected) {
      alert("Please agree to terms and condition.");
      return;
    }
    store.shops.approval = "pending";
    store.createOrUpdateShop();
    navigation.navigate("ShopSummaryScreen");
  };

  return (
    <View
      style={{
        alignItems: "center",
        width: 0.9 * screen.width,
        height: "100%"
      }}>
      <ModalSchedule modalShow={isModal} setModalShow={setModalShow} />
      <ImagePickerBtn
        title="Business Operating Days/Hours"
        onPress={() => setModalShow(true)}
      />
      <ImagePickerBtn
        title="Upload Logo"
        onPress={() => {
          chooseFile(uploadPhoto, setUploadPhoto), (store.text = "logo");
        }}
        isCheck={uploadPhoto.logo ? true : false}
      />
      <ImagePickerBtn
        title="Upload Shop Front Image"
        onPress={() => {
          chooseFile(uploadPhoto, setUploadPhoto),
            (store.text = "shop_frontimg");
        }}
        isCheck={uploadPhoto.shop_frontimg ? true : false}
      />
      {/* <TextFieldRegular
        title="Services Offered"
        onPress={() => {
          chooseFile(), (store.text = "bircert");
        }}
      /> */}
      {/* <TextFieldRegular
        placeholder="Tools Equipment"
        setData={(text) => (store.car.plateno = text)}
      />
      <TextFieldRegular
        placeholder="Tech Certifications"
        setData={(text) => (store.car.plateno = text)}
      /> */}
      <View style={styles.checkboxContainer}>
        <CheckBox
          style={styles.checkbox}
          tintColor="black"
          onCheckColor="white"
          tintColors={{ true: "white", false: "black" }}
          value={isSelected}
          onValueChange={setSelection}
        />
        <Text style={styles.label}>
          I agree with the Terms & Conditions and Privacy Policy
        </Text>
      </View>
      <View style={{ paddingBottom: 100 }}>
        <SubmitButton title="SUBMIT" inProfile onPress={() => shopCreation()} />
      </View>
      <View style={{ paddingBottom: 0.07 * screen.height }}></View>
    </View>
  );
};
const index = ({ store }) => {
  const [page, setPage] = useState(1);
  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity
          onPress={() => (page != 1 ? setPage(page - 1) : console.log())}
          style={{ position: "absolute", left: 10, top: 50, zIndex: 2 }}>
          <Icon name="chevron-left" size={50} color={colors.dark_blue} />
        </TouchableOpacity>
        <Image
          source={images.card_shop}
          style={{ width: screen.width, height: "100%" }}
        />
      </View>
      <View
        style={{
          flex: 0.75,
          zIndex: 5,
          height: "100%",
          position: "absolute",
          bottom: -0.15 * screen.height
        }}>
        <ScrollView
          showsVerticalScrollIndicator={false}
          style={styles.content}
          keyboardShouldPersistTaps="always"
          contentContainerStyle={{ alignItems: "center" }}>
          <View
            style={{ alignItems: "center", justifyContent: "space-evenly" }}>
            <Text style={styles.welcomeLbl}>
              Welcome lets make your shop busy !
            </Text>
            <Text style={styles.secondaryHeaderLbl}>
              I-set-up natin ang iyong shop dito
            </Text>
          </View>
          {page == 1 ? (
            <View style={{ alignItems: "center" }}>
              {/* <GoogleTextfieldShop
                onPress={(address) => (store.car.location = address)}
              /> */}
              <FirstPage setNum={setPage} />
            </View>
          ) : page == 2 ? (
            <SecondPage setNum={setPage} />
          ) : (
            <ThirdPage />
          )}
        </ScrollView>
        <View style={{ marginBottom: 100 }}></View>
      </View>
    </View>
  );
};

// define your styles
const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "white",
    alignItems: "center"
  },
  header: {
    flex: 0.25
  },
  content: {
    paddingTop: 40,
    backgroundColor: "rgba(14,133,230,0.7)",
    width: 0.9 * screen.width,
    height: "100%",
    zIndex: 10,
    borderRadius: 15,
    shadowColor: "#000",
    shadowOffset: {
      width: 0,
      height: 2
    },
    shadowOpacity: 0.25,
    shadowRadius: 3.84
  },
  welcomeLbl: {
    fontFamily: "OpenSans-Regular",
    fontSize: 24,
    color: "white",
    textAlign: "center"
  },
  secondaryHeaderLbl: {
    fontFamily: "OpenSans-Regular",
    fontSize: 0.016 * screen.height,
    color: "white",
    marginBottom: 10
  },
  checkboxContainer: {
    flexDirection: "row",
    marginBottom: 20,
    width: 0.9 * screen.width,
    paddingLeft: 10,
    paddingRight: 10,
    justifyContent: "space-evenly",
    alignItems: "center",
    flexWrap: "wrap"
  },
  checkbox: {
    alignSelf: "flex-start"
  },
  label: {
    fontFamily: "OpenSans-Regular",
    color: "white",
    paddingLeft: 10,
    width: "70%"
  }
});

//make this component available to the app
export default inject("store")(observer(index));
