//import liraries
import React, { useState } from "react";
import {
  View,
  Text,
  StyleSheet,
  Image,
  ScrollView,
  TouchableOpacity,
  TextInput
} from "react-native";
import { colors, images, screen, icons } from "../../../../../constant";
import { inject, observer } from "mobx-react";
import Icon from "react-native-vector-icons/Feather";
import {
  TextFieldRegular,
  SubmitButton,
  GoogleTextfieldShop
} from "../../../../Components";

const index = ({ navigation, store }) => {
  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity
          style={{ position: "absolute", left: 10, top: 50, zIndex: 2 }}
          onPress={() => navigation.navigate("ShopScreen")}>
          <Icon name="chevron-left" size={50} color={colors.dark_blue} />
        </TouchableOpacity>
        <Image
          source={images.card_shop}
          style={{ width: screen.width, height: "100%" }}
        />
      </View>
      <View
        style={{
          flex: 0.75,
          zIndex: 5,
          height: "100%",
          position: "absolute",
          bottom: -0.15 * screen.height,
          shadowColor: "#000",
          shadowOffset: {
            width: 0,
            height: 2
          },
          shadowOpacity: 0.25,
          shadowRadius: 3.84,

          elevation: 5
        }}>
        <ScrollView
          showsVerticalScrollIndicator={false}
          style={styles.content}
          keyboardShouldPersistTaps="always"
          contentContainerStyle={{ alignItems: "center" }}>
          <View
            style={{
              alignItems: "center",
              justifyContent: "space-evenly",
              paddingLeft: 20,
              paddingRight: 20
            }}>
            <Text style={styles.welcomeLbl}>
              Your application has been sent !
            </Text>
            <Text style={styles.secondaryHeaderLbl}>Here`s the summary</Text>
          </View>
          <View
            style={{
              alignSelf: "flex-start",
              paddingLeft: 30
            }}>
            {/* <Text style={styles.infoLbl}>Location: </Text> */}
            <Text style={styles.infoLbl}>
              Shop Name: {store.shops.shop_name}
            </Text>
            <Text style={styles.infoLbl}>
              Business Name: {store.shops.bizname}
            </Text>
            <Text style={styles.infoLbl}>
              Street Address: {store.shops.stadd}
            </Text>
            <Text style={styles.infoLbl}>Barangay: {store.shops.brgy}</Text>
            <Text style={styles.infoLbl}>City: {store.shops.city}</Text>
            <Text style={styles.infoLbl}>Region: {store.shops.region}</Text>
            <Text style={styles.infoLbl}>
              Owner/Main Cotact Person: {store.shops.owner_contactperson}
            </Text>
            <Text style={styles.infoLbl}>
              Business Phone No.: {store.shops.biz_no}
            </Text>
            <Text style={styles.infoLbl}>Email: {store.shops.email}</Text>
            <Text style={styles.infoLbl}>Fb Page: {store.shops.fbpage}</Text>
            <Text style={styles.infoLbl}>
              Fb Messenger/WhatsApp: {store.shops.fb_messenger}
            </Text>
            <Text style={styles.infoLbl}>Website: {store.shops.website}</Text>
            <Text style={styles.infoLbl}>
              Days Open: {store.shops.daysopen}
            </Text>
            <Text style={styles.infoLbl}>
              Hours Open: {store.shops.operationhrs}
            </Text>
            <Text style={styles.infoLbl}>Business Permit: [attachment]</Text>
            <Text style={styles.infoLbl}>BIR Certificate: [attachment]</Text>
            <Text style={styles.infoLbl}>Logo: [attachment]</Text>
            <Text style={styles.infoLbl}>Shop Frontage: [attachment]</Text>
            <Text style={styles.infoLbl}>
              {/* Service offered: {store.shops.stadd} */}
              Servece offered:
            </Text>
            <Text style={styles.infoLbl}>
              Tools and Equipment:
              {/* {store.shops.stadd} */}
            </Text>
            <Text style={styles.infoLbl}>
              Tech Certifications: [attachment]
            </Text>
          </View>

          <View style={{ padding: 20 }}>
            <Text style={styles.welcomeLbl}>
              We will be in touch with you shortly!
            </Text>
          </View>
          <View style={{ paddingBottom: 0.18 * screen.height }}></View>
        </ScrollView>
      </View>
    </View>
  );
};

// define your styles
const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#FFFFFF",
    alignItems: "center"
  },
  header: {
    flex: 0.25
  },
  content: {
    paddingTop: 40,
    backgroundColor: "rgba(255,255,255,0.9)",
    width: 0.9 * screen.width,
    height: "100%",
    zIndex: 10
  },
  welcomeLbl: {
    fontFamily: "OpenSans-Regular",
    fontWeight: "500",
    fontSize: 0.04 * screen.height,
    color: colors.font_text_color,
    textAlign: "center"
  },
  secondaryHeaderLbl: {
    fontFamily: "OpenSans-Regular",
    fontSize: 0.016 * screen.height,
    color: colors.font_text_color,
    marginBottom: 10
  },
  infoLbl: {
    fontFamily: "OpenSans-Regular",
    fontSize: 0.017 * screen.height,
    color: colors.font_text_color,
    textAlign: "left",
    margin: 5
  }
});

//make this component available to the app
export default inject("store")(observer(index));
