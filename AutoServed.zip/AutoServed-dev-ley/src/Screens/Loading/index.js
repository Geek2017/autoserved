//import liraries
import React, { useEffect, useRef, useState } from "react";
import { View, Text, StyleSheet, ActivityIndicator, Image } from "react-native";
import { colors, icons, mainStyle } from "../../../constant";
import { useNavigation } from "@react-navigation/native";
import { inject, observer } from "mobx-react";
import { CommonActions } from "@react-navigation/native";
import DeviceInfo from "react-native-device-info";
// create a component
function useInterval(callback, delay) {
  const savedCallback = useRef();

  // Remember the latest callback.
  useEffect(() => {
    savedCallback.current = callback;
  }, [callback]);

  // Set up the interval.
  useEffect(() => {
    function tick() {
      savedCallback.current();
    }
    if (delay !== null) {
      let id = setInterval(tick, delay);
      return () => clearInterval(id);
    }
  }, [delay]);
}

const index = ({ store }) => {
  const [progress, setProgress] = useState(0);
  const navigation = useNavigation();
  useInterval(() => {
    if (progress < 1) {
      setProgress(progress + 0.5);
    } else {
      store
        .retriveStorage("loginState")
        .then((response) => {
          let json = JSON.parse(response);
          store.profile.mobileno = json.mobileno;
          fetch(
            `https://lj2e11f6r1.execute-api.ap-southeast-1.amazonaws.com/autoserved/users/${json.mobileno}`
          )
            .then(fetch.throwErrors)
            .then((res) => res.json())
            .then((json) => {
              store.profile = json;
              let nameRoute =
                json.state != "approve"
                  ? "LoginStateScreen"
                  : json.usertype == "individual"
                  ? "Main"
                  : "ShopTabBarNav";
              navigation.dispatch(
                CommonActions.reset({
                  index: 0,
                  routes: [{ name: nameRoute }]
                })
              );
            });
        })
        .catch((e) => console.log(e));
    }
  }, 1000);
  return (
    <View style={styles.container}>
      {/* <ActivityIndicator color={colors.blue_backgroud} size={30} /> */}
      <View
        style={{ flex: 0.5, justifyContent: "flex-end", alignItems: "center" }}>
        <Image source={icons.loading_logo} />
      </View>
      <View
        style={{
          justifyContent: "flex-end",
          alignItems: "center",
          flex: 0.5
        }}>
        <Text
          style={[mainStyle.main.subtleText, { color: "white", fontSize: 16 }]}>
          All rights Reserved | Copyright 2021 | V {DeviceInfo.getVersion()}
        </Text>
      </View>
    </View>
  );
};

// define your styles
const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#258CE6"
  }
});

//make this component available to the app
export default inject("store")(observer(index));
