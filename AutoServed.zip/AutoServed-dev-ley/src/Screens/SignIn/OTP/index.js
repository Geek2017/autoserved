//import liraries
import React, { useState, useEffect } from "react";
import {
  View,
  Text,
  StyleSheet,
  Image,
  TouchableOpacity,
  Alert,
  ScrollView,
  Keyboard,
  TextInput
} from "react-native";
import { colors, icons, screen, images, mainStyle } from "../../../../constant";
import { TextFieldRegular, SubmitButton } from "../../../Components";
import FontAwesome from "react-native-vector-icons/FontAwesome5";
import { encode } from "../../../Services/Encrypt";
import { inject, observer } from "mobx-react";
import { CommonActions } from "@react-navigation/native";
// create a component
const index = ({ navigation, store }) => {
  const [otpText, setOTP] = useState(null);

  const checkOTP = () => {
    if (encode(otpText) == store.otp) {
      store.getUserData();

      navigation.dispatch(
        CommonActions.reset({
          index: 0,
          routes: [{ name: "LoadingScreen" }]
        })
      );
      // Alert.alert("Success");
      const loginCredential = {
        loginState: true,
        mobileno: store.profile.mobileno,
        userType: store.profile.usertype
      };
      store.insertStorage("loginState", loginCredential);
      return;
    }
    Alert.alert("OTP did not match");
  };

  // console.log(store.profile.mobileno);
  return (
    <ScrollView style={{ backgroundColor: "white" }}>
      <View style={styles.container} onPress={() => Keyboard.dismiss}>
        <View style={styles.first_content}>
          <TouchableOpacity
            style={{
              position: "absolute",
              left: 20,
              padding: 20,
              paddingTop: 40,
              zIndex: 10
            }}
            onPress={() => navigation.goBack()}>
            <FontAwesome
              name="chevron-left"
              size={20}
              color={colors.blue_backgroud_secondary}
            />
          </TouchableOpacity>

          <Image
            source={images.card_signin_one}
            style={styles.logo}
            resizeMode="cover"
          />
          <View style={{ marginTop: 0.2 * screen.height }}>
            <Text
              style={[
                mainStyle.main.Body,
                {
                  color: colors.font_text_color,
                  textAlign: "center",
                  paddingVertical: 8
                }
              ]}>
              {`Please enter the OTP \n sent to your verified mobile number`}
            </Text>
            <TextInput
              style={styles.inputStyle}
              placeholder="Enter OTP Number"
              placeholderTextColor={colors.font_text_color}
              keyboardType="number-pad"
              onChangeText={(num) => setOTP(num)}
            />
          </View>
          <View style={{ marginTop: 50 }}>
            <SubmitButton title="Submit" onPress={checkOTP} />
          </View>
        </View>
      </View>
      <View style={styles.second_content}></View>
    </ScrollView>
  );
};

// define your styles
const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    backgroundColor: "white"
  },
  first_content: {
    flex: 0.6,
    alignItems: "center",
    width: "100%"
    // backgroundColor: "cyan"
  },
  logo: {
    width: "100%",
    height: 150
  },
  second_content: {
    flex: 0.4
  },
  inputStyle: {
    backgroundColor: "white",
    paddingLeft: 20,
    paddingRight: 20,
    width: 0.85 * screen.width,
    height: 50,
    borderRadius: 70,
    borderWidth: 1,
    borderColor: colors.font_text_color,
    // borderWidth: 1,
    // borderColor: colors.blue_backgroud_secondary,
    fontSize: 18,
    color: colors.font_text_color,
    marginBottom: 20
  }
});

//make this component available to the app
export default inject("store")(observer(index));
