//import liraries
import React, { Component, useState } from "react";
import {
  View,
  Text,
  StyleSheet,
  Image,
  TouchableOpacity,
  Alert,
  ScrollView
} from "react-native";
import { colors, icons, screen } from "../../../../constant";
import { TextFieldNumberSignIn, SubmitButton } from "../../../Components";
import { inject, observer } from "mobx-react";
// create a component
const index = ({ navigation, store }) => {
  const callBackHandler = (result) => {
    if (result.message) {
      store.generateOTP();
      navigation.navigate("OTPScreen", { fromLogin: true });
    } else {
      alert("Mobile number not yet registered , Kindly register first ");
    }
  };

  const onHandleOtp = () => {
    store.profile.mobileno =
      "+63" +
      store.profile?.mobileno
        ?.match(/^(0|\+63)\d{10}|^(9)\d{9}$/gm)?.[0]
        ?.replace(/^(0|\+63)/gm, "");
    if (store.profile.mobileno?.length == 13) {
      store.checkUserIfExist(callBackHandler);
      return;
    }
    alert("Invalid PH number!");
  };

  return (
    <ScrollView style={{ backgroundColor: "white" }}>
      <View style={styles.container}>
        <View style={styles.first_content}>
          <Image
            source={icons.logo_with_text}
            style={styles.logo}
            resizeMode="cover"
            style={{ marginTop: 0.09 * screen.height }}
          />
          <View style={{ marginTop: 0.09 * screen.height }}>
            <TextFieldNumberSignIn
              setMobileNumber={(text) => (store.profile.mobileno = text)}
            />
          </View>
          <View style={{ marginTop: 0.04 * screen.height }}>
            <SubmitButton title="SIGN IN" onPress={onHandleOtp} />
          </View>
        </View>
        <View style={styles.second_content}>
          {/* <TouchableOpacity style={styles.viewStyle}>
            <View style={{ left: 10 }}>
              <Text style={styles.lbl}>SIGN UP WITH</Text>
            </View>
            <View style={{ right: 20 }}>
              <Image source={icons.google} />
            </View>
          </TouchableOpacity>
          <TouchableOpacity style={styles.viewStyle}>
            <View style={{ right: 20 }}>
              <Text style={styles.lbl}>SIGN UP WITH</Text>
            </View>

            <View style={{ right: 20 }}>
              <Image source={icons.facebook} />
            </View>
          </TouchableOpacity> */}
          <SubmitButton
            title="SIGN UP"
            onPress={() => navigation.navigate("SignUpScreen")}
          />
        </View>
      </View>
    </ScrollView>
  );
};

// define your styles
const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    backgroundColor: colors.blue_backgroud_secondary
  },
  first_content: {
    // paddingTop: 100,
    width: "100%",
    alignItems: "center",
    height: 0.6 * screen.height
    // backgroundColor: "cyan"
  },
  logo: {
    width: 171.51,
    height: 93
  },
  second_content: {
    height: 0.3 * screen.height,
    backgroundColor: "white",
    width: "100%",
    alignItems: "center",
    paddingTop: 0.05 * screen.height
  },
  viewStyle: {
    backgroundColor: "white",
    borderWidth: 1,
    borderColor: colors.blue_backgroud_secondary,
    width: 0.85 * screen.width,
    height: 50,
    borderRadius: 70,
    fontSize: 18,
    color: colors.font_text_color,
    alignItems: "center",
    justifyContent: "space-around",
    margin: 10,
    flexDirection: "row"
  },
  lbl: {
    fontFamily: "OpenSans-Regular",
    fontSize: 0.04 * screen.height,
    color: colors.blue_backgroud_secondary
  }
});

//make this component available to the app
export default inject("store")(observer(index));
