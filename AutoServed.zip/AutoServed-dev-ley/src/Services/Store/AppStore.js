import { configure, makeObservable, observable, action, computed } from "mobx";
import { Alert } from "react-native";
import { persist } from "mobx-persist";
import { encode } from "../../Services/Encrypt";
import { decode, encode as btoa } from "base-64";
import { call } from "react-native-reanimated";
import AsyncStorage from "@react-native-community/async-storage";
import { getDistance } from "geolib";
import Geocoder from "react-native-geocoding";
import _ from "lodash";

configure({
  enforceActions: "never"
});

class AppStore {
  @persist("object") @observable.deep profile = {
    bizname: null,
    shopname: null,
    usertype: "individual",
    name: "",
    email: "",
    mobileno: "",
    password: "",
    balance: null,
    points: null
  };
  @observable allPrices = [];
  @persist("list") @observable cars = [];
  @observable car = {};
  @observable shops = {};
  @observable mqoutes = {};
  @observable qoutes = {};
  @observable allShops = [];
  @observable allQoutes = [];
  @observable allQoutesShopPrices = [];
  @observable allQoutesIndividual = [];
  @observable shopConfirmedQoutes = [];
  @observable shopQoutesRecieve = [];
  @observable shopQoutesConfirmed = [];
  @observable shopQoutesBooked = [];
  @observable qoutesStatusShop = [];
  @observable allservices = [];
  @observable multiplePrices = [];
  @persist @observable tempArrPrices = [];
  @observable tempObjPrices = {};
  @observable carType = [];
  // @observable operationhrs = [];
  // @observable hydrated = false;
  @persist @observable OtherItem = [];

  @observable fetching;
  @persist @observable text = "";
  @observable major = [
    "Oil Filter",
    "Flushing",
    "Air Filter",
    "Cabin Filter",
    "Coolant",
    "Brake Fluid",
    "Power Steering Fluid",
    "Brake Cleaner"
  ];
  @observable minor = ["Oil Filter", "Flushing"];
  @observable indexForPrice = 0;
  @persist("object") @observable calendarData = {};
  @observable otp = null;

  @persist @observable isCarListExist = false;
  constructor() {
    makeObservable(this);
  }

  @action getUserData() {
    fetch(
      `https://lj2e11f6r1.execute-api.ap-southeast-1.amazonaws.com/autoserved/users/${this.profile.mobileno}`
    )
      .then(fetch.throwErrors)
      .then((res) => res.json())
      .then((json) => {
        this.profile = json;
      })
      .catch();
  }

  @action async getAllPrices() {
    fetch(
      `https://lj2e11f6r1.execute-api.ap-southeast-1.amazonaws.com/autoserved/allprices`
    )
      .then(fetch.throwErrors)
      .then((res) => res.json())
      .then((json) => {
        this.allPrices = json;
      })
      .catch();
  }
  @action async getAllPricesByShop() {
    fetch(
      `https://lj2e11f6r1.execute-api.ap-southeast-1.amazonaws.com/autoserved/allprices`
    )
      .then(fetch.throwErrors)
      .then((res) => res.json())
      .then((json) => {
        let filteredJsonPrices = json.filter(
          (e) => e.shopid == this.profile.mobileno
        );
        this.allPrices = filteredJsonPrices;
        this.tempArrPrices = filteredJsonPrices;
      })
      .catch();
  }

  @action checkUserIfExist(callback) {
    fetch(
      `https://lj2e11f6r1.execute-api.ap-southeast-1.amazonaws.com/autoserved/users/${this.profile.mobileno}`
    )
      .then(fetch.throwErrors)
      .then((res) => res.json())
      .then((json) => {
        if (json.email != "") {
          callback({ message: true });
        } else {
          callback({ message: false });
        }
      })
      .catch();
  }

  @action createOrUpdateCar(callback) {
    // this.fetching = true;
    fetch(
      `https://lj2e11f6r1.execute-api.ap-southeast-1.amazonaws.com/autoserved/profile/${this.car.plateno}`,
      {
        method: "POST",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify({ ...this.car, mobileno: this.profile.mobileno })
      }
    )
      .then((response) => {
        console.log("Sucess", response);
        this.car = {};
        // this.fetching = false;
        this.getCarProfiles();
        callback();
      })
      .catch((error) => {
        callback("" + error);
        console.error("Error:", error);
      });
  }

  @action getCarProfiles() {
    this.fetching = true;
    fetch(
      `https://lj2e11f6r1.execute-api.ap-southeast-1.amazonaws.com/autoserved/allprofile?mobileno=${encodeURIComponent(
        this.profile.mobileno
      )}`
    )
      .then(fetch.throwErrors)
      .then((res) => res.json())
      .then((json) => {
        this.cars = json;
        this.fetching = false;
      })
      .catch((error) => {
        console.error("Error:", error);
      });
  }

  @action checkUserCar() {
    fetch(
      `https://lj2e11f6r1.execute-api.ap-southeast-1.amazonaws.com/autoserved/allprofile?mobileno=${encodeURIComponent(
        this.profile.mobileno
      )}`
    )
      .then(fetch.throwErrors)
      .then((res) => res.json())
      .then((json) => {
        if (json.length != 0) {
          this.cars = json;
          this.isCarListExist = true;
        }
      })
      .catch((error) => {
        console.error("Error:", error);
      });
  }

  @action deleteCarProfile(plateno) {
    // console.log("plate no", plateno);
    fetch(
      `https://lj2e11f6r1.execute-api.ap-southeast-1.amazonaws.com/autoserved/profile/${plateno}`,
      {
        method: "DELETE",
        headers: {
          "Content-Type": "application/json"
        }
      }
    )
      .then((res) => {
        this.getCarProfiles();
        alert("Delete Successfully");
      })
      .catch((err) => {
        alert(err);
      });
  }

  @action checkUserShop(callback) {
    fetch(
      `https://lj2e11f6r1.execute-api.ap-southeast-1.amazonaws.com/autoserved/shops/${this.profile.mobileno}`
    )
      .then(fetch.throwErrors)
      .then((res) => res.json())
      .then((json) => {
        if (json.mobileno != "") {
          callback({ isShopExist: true });
          this.shops = json;
        } else {
          callback({ isShopExist: false });
        }
      })
      .catch((error) => {
        console.error("Error:", error);
      });
  }

  @action register(callback) {
    this.fetching = true;
    fetch(
      `https://lj2e11f6r1.execute-api.ap-southeast-1.amazonaws.com/autoserved/users/${this.profile.mobileno}`,
      {
        method: "POST",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify(this.profile)
      }
    )
      .then((response) => {
        console.log("Sucess", response);
        this.fetching = false;

        callback(response);
      })
      .catch((error) => {
        console.error("Error:", error);
      });
  }

  @action generateOTP() {
    let otp = Math.random().toString().substr(2, 7);
    var form_data = new FormData();
    item = {
      From: "+14157924897",
      To: this.profile.mobileno,
      Body: "Hi, Here's your AutoServed OTP " + otp
    };
    for (var key in item) {
      form_data.append(key, item[key]);
    }
    console.log(form_data);
    fetch(
      `https://api.twilio.com/2010-04-01/Accounts/AC616dd219c8bea3811d0c502f573af681/Messages.json`,
      {
        method: "POST",
        headers: {
          "Content-Type": "multipart/form-data",
          Authorization: `Basic QUM2MTZkZDIxOWM4YmVhMzgxMWQwYzUwMmY1NzNhZjY4MTpiNThlNTYwNGRjNzE5MDlhODYwNDgzZjljZmZiZDU0Mg==`
        },
        body: form_data
      }
    )
      .then((response) => {
        this.otp = encode(otp);
        this.fetching = false;
        console.log("otp:", this.otp, response);
      })
      .catch((error) => {
        console.error("Error:", error);
      });
  }

  @action createOrUpdateShop(callback) {
    // this.fetching = true;
    fetch(
      `https://lj2e11f6r1.execute-api.ap-southeast-1.amazonaws.com/autoserved/shops/${this.profile.mobileno}`,
      {
        method: "POST",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify({ ...this.shops, mobileno: this.profile.mobileno })
      }
    )
      .then((response) => {
        console.log("Sucess", response);
        console.log(this.shops);
        // this.car = {};
        // // this.fetching = false;
        // this.getCarProfiles();
        // callback();
      })
      .catch((error) => {
        // callback("" + error);
        console.error("Error:", error);
      });
  }

  @action getShopData() {
    this.fetching = true;
    fetch(
      `https://lj2e11f6r1.execute-api.ap-southeast-1.amazonaws.com/autoserved/shops/${this.profile.mobileno}`
    )
      .then(fetch.throwErrors)
      .then((res) => res.json())
      .then((json) => {
        this.shops = json;
        this.fetching = false;
      })
      .catch((error) => {
        console.error("Error:", error);
      });
  }

  @action createQoutes(callback) {
    fetch(
      `https://lj2e11f6r1.execute-api.ap-southeast-1.amazonaws.com/autoserved/qoutes/2`,
      {
        method: "POST",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify({ ...this.qoutes })
      }
    )
      .then((response) => {
        console.log("Sucess", response);
        callback();
      })
      .catch((error) => {
        callback("" + error);
        console.error("Error:", error);
      });
    // fetch(
    //   `https://lj2e11f6r1.execute-api.ap-southeast-1.amazonaws.com/autoserved/allqoutes`
    // )
    //   .then(fetch.throwErrors)
    //   .then((res) => res.json())
    //   .then((json) => {
    //     // let filtered = json.filter(
    //     //   (e) => e.plateno.split(",").indexOf(this.car.plateno) != -1
    //     // );
    //   })
    //   .catch((error) => {
    //     console.error("Error:", error);
    //   });
  }

  @action getUserCreatedQuotes() {
    this.fetching = true;
    fetch(
      `https://lj2e11f6r1.execute-api.ap-southeast-1.amazonaws.com/autoserved/allqoutes`
    )
      .then(fetch.throwErrors)
      .then((res) => res.json())
      .then((json) => {
        this.allQoutes = json;
        this.getAllQoutesWithinDistance();
      })
      .catch((error) => {
        console.error("Error:", error);
      });
  }

  @action getBookedQoutesForShop() {
    this.fetching = true;
    this.shopQoutesBooked = [];
    fetch(
      `https://lj2e11f6r1.execute-api.ap-southeast-1.amazonaws.com/autoserved/allqoutes`
    )
      .then(fetch.throwErrors)
      .then((res) => res.json())
      .then((json) => {
        let lengthArr = json.length;
        json.map((item, index) => {
          let index_sqr_state = item.sqr_state.split(",").indexOf("3");
          let sqrArr = item.sqr_by.split(",")[index_sqr_state];

          if (
            (sqrArr == this.profile.mobileno &&
              item.sqr_state.split(",").indexOf("3") != -1) ||
            item.sqr_state.split(",").indexOf("4") != -1 ||
            item.sqr_state.split(",").indexOf("5") != -1
          )
            this.shopQoutesBooked = [...this.shopQoutesBooked, item];

          if (lengthArr == index + 1)
            this.getBookedQoutesPricesForShop(this.shopQoutesBooked);
        });
        // console.log(filtered);
        // this.fetching = false;
      })
      .catch((error) => {
        console.error("Error:", error);
      });
  }

  @action async getBookedQoutesPricesForShop(data) {
    const arrPromises = data.map((item) =>
      fetch(
        `https://lj2e11f6r1.execute-api.ap-southeast-1.amazonaws.com/autoserved/allmqoutes`
      )
        .then((res) => res.json())
        .then((json) => {
          let filteredJsonPrices = json.filter(
            (e) =>
              e.userid == item.iqr_from &&
              e.shopid == this.profile.mobileno &&
              e.status == 1
          );

          this.allQoutesShopPrices = [
            ...this.allQoutesShopPrices,
            filteredJsonPrices
          ];
        })
    );

    Promise.all(arrPromises).then((json) => {
      this.fetching = false;
    });
  }

  @action async getQuotesConfirmedShops() {
    this.fetching = true;
    fetch(
      `https://lj2e11f6r1.execute-api.ap-southeast-1.amazonaws.com/autoserved/allqoutes`
    )
      .then(fetch.throwErrors)
      .then((res) => res.json())
      .then((json) => {
        let filtered = json.filter(
          (e) => e.sqr_by.split(",").indexOf(this.profile.mobileno) != -1
        );

        Promise.all(filtered).then(() => {
          this.shopQoutesConfirmed = filtered;
          this.fetching = false;
        });
        // this.getAllQoutesWithinDistance();
      })
      .catch((error) => {
        console.error("Error:", error);
      });
  }

  @action async getAllQoutesWithinDistance() {
    var shopLocation = {};
    let shopLocationString =
      this.shops.city +
      ", " +
      this.shops.brgy +
      ", " +
      this.shops.region +
      ", ";
    this.allQoutes.map((item) => {
      // console.log("lat", item.lat);
    });

    if (this.allQoutes == []) {
      this.fetching = false;
    }

    Geocoder.init("AIzaSyAuYmZ6xFjgvREwx9az-NPrlglHgDIPkN0");
    Geocoder.from(shopLocationString)
      .then((item) => {
        shopLocation = item.results[0].geometry.location;
        let lengthArr = this.allQoutes.length;
        this.allQoutes.map((data, index) => {
          if (data.lat != "" && data.lng != "") {
            var distance = getDistance(
              { latitude: shopLocation.lat, longitude: shopLocation.lng },
              { latitude: data.lat, longitude: data.long }
            );

            let checkShopNumberArr = data.sqr_by.split(",");
            let sqr_staterArr = data.sqr_state.split(",");
            let findIndex = checkShopNumberArr.findIndex(
              (element) => element === this.profile.mobileno
            );
            // m to km
            let mTkm = distance * 0.001;
            let km = data.shopsvecinity.replace("KM", "");

            if (mTkm <= parseInt(km)) {
              if (
                data.sqr_state.split(",").indexOf("3") == -1 &&
                data.stats == "1"
              ) {
                this.shopQoutesRecieve = [...this.shopQoutesRecieve, data];
                this.qoutesStatusShop = [
                  ...this.qoutesStatusShop,
                  sqr_staterArr[findIndex]
                ];
              }
            }

            if (lengthArr == index + 1) {
              this.fetching = false;
            }
          }
        });
      })
      .catch((error) => console.log(error));
  }

  @action async getIndividualQoutes(callback) {
    this.fetching = true;
    fetch(
      `https://lj2e11f6r1.execute-api.ap-southeast-1.amazonaws.com/autoserved/allqoutes?iqr_from=${encodeURIComponent(
        this.profile.mobileno
      )}`
    )
      .then(fetch.throwErrors)
      .then((res) => res.json())
      .then((json) => {
        let mobile = this.profile.mobileno;
        let plateno = this.car.plateno;
        var filteredQoutesForIndividual = json.filter(function (result) {
          return (
            result.iqr_from === mobile &&
            result.plateno === plateno &&
            result.stats == 1
          );
        });
        this.getShopsInfoWhoAcceptedTheQoutes(filteredQoutesForIndividual);

        this.allQoutesIndividual = filteredQoutesForIndividual;
        callback("done");
      })
      .catch((error) => {
        console.error("Error:", error);
      });
  }

  @action async getConfirmQoutesForIndividual() {
    this.fetching = true;

    fetch(
      `https://lj2e11f6r1.execute-api.ap-southeast-1.amazonaws.com/autoserved/allqoutes?iqr_from=${encodeURIComponent(
        this.profile.mobileno
      )}`
    )
      .then(fetch.throwErrors)
      .then((res) => res.json())
      .then((json) => {
        let mobile = this.profile.mobileno;
        var filteredQoutesForIndividual = json.filter(function (result) {
          return result.iqr_from === mobile && result.stats == 0;
        });
        this.allQoutesIndividual = filteredQoutesForIndividual;
        this.getShopDetailIndividualQoutes(filteredQoutesForIndividual);
      })
      .catch((error) => {
        console.error("Error:", error);
      });
  }

  @action async getShopDetailIndividualQoutes(quotes) {
    let sqrArr = [];
    let index_sqr_state;
    this.allShops = [];
    let arrLength = quotes.length;

    if (arrLength == 0) this.fetching = false;

    quotes.map((item, index) => {
      index_sqr_state = item.sqr_state.split(",").indexOf("3");
      sqrArr = item.sqr_by.split(",")[index_sqr_state];

      fetch(
        `https://lj2e11f6r1.execute-api.ap-southeast-1.amazonaws.com/autoserved/shops/${sqrArr}`
      )
        .then(fetch.throwErrors)
        .then((res) => res.json())
        .then((json) => {
          if (!json.message) {
            this.allShops = [...this.allShops, json];

            fetch(
              `https://lj2e11f6r1.execute-api.ap-southeast-1.amazonaws.com/autoserved/allmqoutes`
            )
              .then((res) => res.json())
              .then((json) => {
                let newObj = json.filter(
                  (e) => e.qid == item.id && e.status == 1
                );
                this.allQoutesShopPrices = [
                  ...this.allQoutesShopPrices,
                  newObj
                ];
              });
          }

          if (arrLength === index + 1) {
            this.fetching = false;
          }
        });
    });
  }

  @action async getShopsInfoWhoAcceptedTheQoutes(data) {
    let sqrArr = [];
    let tempArr = [];
    var tempArrPrice = [];
    this.allShops = [];
    data.map((item) => {
      sqrArr = item.sqr_by.split(",");
    });

    const arrPromises = sqrArr.map((item) =>
      fetch(
        `https://lj2e11f6r1.execute-api.ap-southeast-1.amazonaws.com/autoserved/shops/${item}`
      )
        .then(fetch.throwErrors)
        .then((res) => res.json())
        .then((json) => {
          if (!json.message) {
            tempArr = [...tempArr, json];
          }
        })
    );

    Promise.all(arrPromises).then((json) => {
      this.allShops = tempArr;

      fetch(
        `https://lj2e11f6r1.execute-api.ap-southeast-1.amazonaws.com/autoserved/allmqoutes`
      )
        .then((res) => res.json())
        .then((json) => {
          let newObj = json.filter((e) => e.qid == data[0].id && e.status == 0);
          // json.filter((e) => console.log(e.qid, data[0].id));
          this.allQoutesShopPrices = [...this.allQoutesShopPrices, newObj];
          this.fetching = false;
        });
    });
  }

  @action getAllServices() {
    fetch(
      `https://lj2e11f6r1.execute-api.ap-southeast-1.amazonaws.com/autoserved/allservices?1`
    )
      .then(fetch.throwErrors)
      .then((res) => res.json())
      .then((json) => {
        let newJson = json.map((item) => {
          return {
            id: item.id,
            service: item.service
          };
        });

        let filteredJson = newJson.filter(function (el) {
          return el.service != "";
        });

        let newJson2 = json.map((item) => {
          return {
            value: item.id,
            label: item.service
          };
        });

        let filteredJson2 = newJson2.filter(function (el) {
          return el.label != "";
        });

        this.allservices = filteredJson;
        this.carType = filteredJson2;
      })
      .catch((error) => {
        console.error("Error:", error);
      });
  }

  @action async createMultiplePrices() {
    let tempArr = [];
    const promise = this.allPrices.map((item) => {
      let arr = this.multiplePrices.filter(
        (element) =>
          element.shopid == item.shopid && element.serviceid == item.serviceid
      );
      tempArr = [...tempArr, arr];
    });

    Promise.all(promise).then((json) => {
      const newArr = this.multiplePrices.filter(function (val) {
        return tempArr.flat().indexOf(val) == -1;
      });
      this.multiplePrices = newArr;
      // newArr.map((data) => {
      this.multiplePrices.map((data) => {
        fetch(
          `https://lj2e11f6r1.execute-api.ap-southeast-1.amazonaws.com/autoserved/prices/2`,
          {
            method: "POST",
            headers: {
              "Content-Type": "application/json"
            },
            body: JSON.stringify(data)
          }
        )
          .then((response) => {
            this.multiplePrices = [];
            console.log("Sucess", response);
          })
          .catch((error) => {
            console.error("Error:", error);
          });
      });
    });
  }

  @action createMqoutes() {
    // this.fetching = true;

    fetch(
      `https://lj2e11f6r1.execute-api.ap-southeast-1.amazonaws.com/autoserved/mqoutes/1`,
      {
        method: "POST",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify({ ...this.mqoutes })
      }
    )
      .then((response) => {
        console.log("Sucess", response);
      })
      .catch((error) => {
        // callback("" + error);
        console.error("Error:", error);
      });
  }

  @computed get getBMI() {
    return this.profile;
  }

  @computed get strExercise() {
    return this.exercise.exercise.replace(/[ \-]/g, "");
  }

  @action updateExercise = (val) => {
    this.exercise = val;
  };

  @action saveEmail = (val) => {
    this.userEmail = val;
  };

  @action savePassword = (val) => {
    this.userPassword = val;
  };

  @action async uploadData() {
    let calendarData = Object.entries(this.calendarData);
    let maccies = this.userEmail;
    if (calendarData.length) {
      calendarData.map((item) => {
        payload = item[1];
        payload["Date"] = item[0];
        payload["macAddress"] = maccies;
        payload["Id"] = item[0] + maccies;

        fetch(
          `https://4uxahzuqzc.execute-api.eu-west-2.amazonaws.com/vts/calendar`,
          {
            method: "POST",
            headers: {
              "Content-Type": "application/json"
            },
            body: JSON.stringify(payload)
          }
        )
          .then((response) => {
            console.log("Sucess", response, payload);
          })
          .catch((error) => {
            console.error("Error:", error);
          });
      });
    }
  }

  @action async login() {
    this.fetching = true;
    return fetch(
      `https://4uxahzuqzc.execute-api.eu-west-2.amazonaws.com/vts/forms/${this.userEmail}`
    )
      .then(fetch.throwErrors)
      .then((res) => res.json())
      .then((json) => {
        if (
          !json.email ||
          !(
            json.email.toLowerCase() == this.userEmail.toLowerCase() &&
            json.password == this.encode(this.userPassword)
          )
        ) {
          Alert.alert(
            "Credentials not match",
            "Sorry, seems that your credentials doesn't match, Please try again"
          );
        } else {
          this.loginState = true;
          this.macAddress = json.macAddress;
          this.profile = json.profile;
        }
      })
      .catch((err) =>
        console.log(
          "ERROR hello world",
          Alert.alert("Network failure", "Please make sure you've internet")
        )
      );
    this.fetching = false;
  }

  @action async logout() {
    this.profile = {};
    this.allservices = [];
    this.carType = [];
    this.cars = [];
    this.car = {};
    this.shops = {};
    const keys = await AsyncStorage.getAllKeys();
    await AsyncStorage.multiRemove(keys);
  }

  @action async insertStorage(key, value) {
    try {
      await AsyncStorage.setItem(key, JSON.stringify(value));
    } catch (error) {
      console.log(error);
    }
  }

  @action async retriveStorage(key) {
    try {
      var retrievedItem = await AsyncStorage.getItem(key);
      // const item = JSON.parse(retrievedItem);
      return retrievedItem;
    } catch (error) {
      console.log(error.message);
    }
  }

  @action fetchStats(days = 6, dayCalendar = null) {
    let startDate =
      dayCalendar ?? new Date(new Date().toDateString()).getTime() - 86400000;
    let endDate = startDate - 86400000 * days;

    return fetch(
      `https://4uxahzuqzc.execute-api.eu-west-2.amazonaws.com/vts/calendar?mac=${this.userEmail}&date1=${endDate}&date2=${startDate}&type=${this.exerciseType}&exercise=${this.strExercise}`
    )
      .then(fetch.throwErrors)
      .then((res) => res.json())
      .then((json) => {
        if (dayCalendar) return json[this.strExercise];
        this.stats = json[this.strExercise];
        console.log("fetched");
      })
      .catch((err) =>
        console.log(
          "ERROR hello world",
          Alert.alert("Network failure", "Please make sure you've internet")
        )
      );
  }

  @action encode = (pwd) => encode(pwd);
}
export default AppStore;
