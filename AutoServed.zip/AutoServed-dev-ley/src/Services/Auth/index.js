import React from "react";
import { encode } from "../Encrypt";
import { insertItem, retrieveItem } from "../API";
export const generateOTP = (mobileNumber, callback) => {
  let otp = Math.random().toString().substr(2, 7);
  var form_data = new FormData();
  let item = {
    From: "+14157924897",
    To: mobileNumber,
    Body: "Hi, Here's your AutoServed OTP " + otp
  };
  for (var key in item) {
    form_data.append(key, item[key]);
  }

  console.log(form_data);

  fetch(
    `https://api.twilio.com/2010-04-01/Accounts/AC616dd219c8bea3811d0c502f573af681/Messages.json`,
    {
      method: "POST",
      headers: {
        "Content-Type": "multipart/form-data",
        Authorization: `Basic QUM2MTZkZDIxOWM4YmVhMzgxMWQwYzUwMmY1NzNhZjY4MTpiNThlNTYwNGRjNzE5MDlhODYwNDgzZjljZmZiZDU0Mg==`
      },
      body: form_data
    }
  )
    .then((response) => {
      let otpnew = encode(otp);
      insertItem("OTP", otpnew);
      callback(response);
      // console.log("otp:", otp, response);
    })
    .catch((error) => {
      // callback("" + error);
      console.error("Error:", error);
    });
};

export const registration = (data, callback) => {
  fetch(
    `https://lj2e11f6r1.execute-api.ap-southeast-1.amazonaws.com/autoserved/users/${data.mobileno}`,
    {
      method: "POST",
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify(data)
    }
  )
    .then((response) => {
      console.log("Sucess", response);
      response.mobileNumber = data.mobileno;
      callback(response);
      // generateOTP(data.mobileno);
    })
    .catch((error) => {
      console.error("Error:", error);
    });
};
