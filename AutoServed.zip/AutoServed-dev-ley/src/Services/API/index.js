import React from "react";
import AsyncStorage from "@react-native-community/async-storage";
export const retrieveItem = async (key) => {
  //   try {
  //     var retrievedItem = await AsyncStorage.getItem(key);
  //     // const item = JSON.parse(retrievedItem);
  //     DATA_ITEM.otp = retrievedItem;
  //   } catch (error) {
  //     console.log(error.message);
  //   }
  return await AsyncStorage.getItem(key);
};

export const insertItem = async (key, value) => {
  try {
    await AsyncStorage.setItem(key, value);
    // alert("Data successfully saved");
  } catch (e) {
    alert("Failed to save the data to the storage");
  }
};

export var DATA_ITEM = {};
