const capitalizeFirstLetter = (string) => {
  return string ? string.charAt(0).toUpperCase() + string.slice(1) : "";
};

const capitalizeAllLetters = (string) => {
  return string.toUpperCase();
};
const titleCase = (str) => {
  if (!str) return "";
  str = str.toLowerCase().split(" ");
  for (var i = 0; i < str.length; i++) {
    str[i] = str[i].charAt(0).toUpperCase() + str[i].slice(1);
  }
  return str.join(" ");
};

const thousands_separators = (num) => {
  if (!num) {
    return "";
  }
  var newNstr = num.toString().replace(",", "");
  var num_parts = newNstr.toString().split(".");
  num_parts[0] = num_parts[0].replace(/\B(?=(\d{3})+(?!\d))/g, ",");
  return num_parts.join(".");
};
export {
  capitalizeFirstLetter,
  capitalizeAllLetters,
  titleCase,
  thousands_separators
};
