angular.module('newApp').controller('logsCtrl', function($scope, $http, $filter) {

    pageSetUp();

})